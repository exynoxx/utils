namespace Cicd.Infrastructure.DependencyInjection;

/// <summary>
/// Infrastructure configuration bound from the <c>Cicd</c> configuration section.
/// </summary>
public sealed class CicdOptions
{
    public const string SectionName = "Cicd";

    /// <summary>Number of in-process worker loops the server should spawn.</summary>
    public int WorkerCount { get; set; } = 2;

    /// <summary>Root data directory as seen by the server process.</summary>
    public string DataRoot { get; set; } = "./data";

    /// <summary>
    /// Root data directory as seen by the Docker daemon (for bind mounts). Defaults to
    /// <see cref="DataRoot"/> when the server and daemon share a filesystem view.
    /// </summary>
    public string? HostDataRoot { get; set; }

    /// <summary>Docker daemon endpoint. Defaults per-OS when null.</summary>
    public string? DockerSocket { get; set; }

    public int GitPollIntervalSeconds { get; set; } = 30;

    /// <summary>Keep the workspace volume around after a failed job for debugging.</summary>
    public bool RetainWorkspaceOnFailure { get; set; }

    public string DefaultHelperImage { get; set; } = "alpine:3.20";

    public string GitImage { get; set; } = "alpine/git:v2.45.2";

    /// <summary>
    /// Master key for secret encryption. SHA-256 is applied to produce the 32-byte AES key.
    /// Falls back to the <c>CICD_MASTER_KEY</c> environment variable when unset.
    /// </summary>
    public string? MasterKey { get; set; }

    /// <summary>Optional explicit override for the log root. Defaults to <c>&lt;DataRoot&gt;/logs</c>.</summary>
    public string? LogRoot { get; set; }

    /// <summary>Optional explicit override for the cache root. Defaults to <c>&lt;DataRoot&gt;/cache</c>.</summary>
    public string? CacheRoot { get; set; }

    /// <summary>Optional explicit override for the artifact root. Defaults to <c>&lt;DataRoot&gt;/artifacts</c>.</summary>
    public string? ArtifactRoot { get; set; }

    /// <summary>Optional explicit override for the git mirror root. Defaults to <c>&lt;DataRoot&gt;/mirrors</c>.</summary>
    public string? MirrorRoot { get; set; }

    // Roots are normalized to absolute paths: bind mounts handed to the Docker daemon
    // must be absolute, and a relative DataRoot like "./data" would otherwise leak through.
    public string EffectiveHostDataRoot =>
        Path.GetFullPath(string.IsNullOrWhiteSpace(HostDataRoot) ? DataRoot : HostDataRoot);

    public string EffectiveLogRoot =>
        Path.GetFullPath(string.IsNullOrWhiteSpace(LogRoot) ? Path.Combine(DataRoot, "logs") : LogRoot);

    public string EffectiveCacheRoot =>
        Path.GetFullPath(string.IsNullOrWhiteSpace(CacheRoot) ? Path.Combine(DataRoot, "cache") : CacheRoot);

    public string EffectiveArtifactRoot =>
        Path.GetFullPath(string.IsNullOrWhiteSpace(ArtifactRoot) ? Path.Combine(DataRoot, "artifacts") : ArtifactRoot);

    public string EffectiveMirrorRoot =>
        Path.GetFullPath(string.IsNullOrWhiteSpace(MirrorRoot) ? Path.Combine(DataRoot, "mirrors") : MirrorRoot);

    /// <summary>Cache root as seen by the Docker daemon (for bind mounts in helper containers).</summary>
    public string HostCacheRoot => Path.Combine(EffectiveHostDataRoot, "cache");

    /// <summary>Artifact root as seen by the Docker daemon (for bind mounts in helper containers).</summary>
    public string HostArtifactRoot => Path.Combine(EffectiveHostDataRoot, "artifacts");
}
