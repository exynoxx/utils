using System.Security.Cryptography;
using System.Text;
using Cicd.Core.Definition;
using Cicd.Core.Execution;
using Cicd.Core.Secrets;
using Cicd.Core.Storage;
using Cicd.Core.Triggers;
using Cicd.Infrastructure.Docker;
using Cicd.Infrastructure.Glue;
using Cicd.Infrastructure.Persistence;
using Cicd.Infrastructure.Stores;
using Docker.DotNet;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Cicd.Infrastructure.DependencyInjection;

/// <summary>
/// Wires up the Infrastructure services: persistence, queue, stores, secrets, the Docker executor
/// and the Core glue (pipeline definition source, catalog, job context factory).
/// </summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddCicdInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<CicdOptions>(configuration.GetSection(CicdOptions.SectionName));

        var connectionString = configuration.GetConnectionString("Db")
            ?? throw new InvalidOperationException("Connection string 'Db' is required.");

        services.AddDbContextFactory<CicdDbContext>(options => options.UseNpgsql(connectionString));

        // Persistence: repositories + queue.
        services.AddSingleton<IPipelineRepository, PipelineRepository>();
        services.AddSingleton<IRunRepository, RunRepository>();
        services.AddSingleton<IJobRepository, JobRepository>();
        services.AddSingleton<IStepRepository, StepRepository>();
        services.AddSingleton<IArtifactRepository, ArtifactRepository>();
        services.AddSingleton<IRepoBranchStateStore, RepoBranchStateStore>();
        services.AddSingleton<IJobQueue, PostgresJobQueue>();
        services.AddSingleton<IApiTokenStore, ApiTokenStore>();
        services.AddSingleton<DatabaseInitializer>();
        services.AddSingleton<LeaseReaper>();

        // Secrets: cipher + store.
        services.AddSingleton(sp =>
        {
            var options = sp.GetRequiredService<IOptions<CicdOptions>>().Value;
            var key = ResolveMasterKey(options);
            return new SecretCipher(key);
        });
        services.AddSingleton<ISecretStore, PostgresSecretStore>();

        // Logs.
        services.AddSingleton<ILogBroker, LogBroker>();
        services.AddSingleton<FileSystemLogStore>(sp =>
        {
            var options = sp.GetRequiredService<IOptions<CicdOptions>>().Value;
            var broker = sp.GetRequiredService<ILogBroker>();
            return new FileSystemLogStore(options.EffectiveLogRoot, broker);
        });
        services.AddSingleton<ILogStore>(sp => sp.GetRequiredService<FileSystemLogStore>());
        services.AddSingleton<ILogWriter>(sp => sp.GetRequiredService<FileSystemLogStore>());

        // Cache + artifact stores.
        services.AddSingleton<ICacheStore>(sp =>
        {
            var options = sp.GetRequiredService<IOptions<CicdOptions>>().Value;
            return new FileSystemCacheStore(options.EffectiveCacheRoot);
        });
        services.AddSingleton<IArtifactStore>(sp =>
        {
            var options = sp.GetRequiredService<IOptions<CicdOptions>>().Value;
            return new FileSystemArtifactStore(options.EffectiveArtifactRoot);
        });

        // Docker runtime.
        services.AddSingleton(sp =>
        {
            var options = sp.GetRequiredService<IOptions<CicdOptions>>().Value;
            return CreateDockerClient(options);
        });
        services.AddSingleton<DockerVolumeHelper>();
        services.AddSingleton<IJobExecutor, DockerJobExecutor>();
        services.AddSingleton<IJobExecutorRegistry, JobExecutorRegistry>();

        // Git tooling.
        services.AddSingleton<GitCli>();
        services.AddSingleton(sp =>
        {
            var options = sp.GetRequiredService<IOptions<CicdOptions>>().Value;
            var git = sp.GetRequiredService<GitCli>();
            return new GitMirror(options.EffectiveMirrorRoot, git);
        });

        // Core glue.
        services.AddSingleton<IPipelineParser>(_ => new PipelineParser());
        services.AddSingleton<IPipelineDefinitionSource, PipelineDefinitionSource>();
        services.AddSingleton<IPipelineCatalog, PipelineCatalog>();
        services.AddSingleton<IJobContextFactory, JobContextFactory>();

        return services;
    }

    private static byte[] ResolveMasterKey(CicdOptions options)
    {
        var raw = options.MasterKey;
        if (string.IsNullOrWhiteSpace(raw))
        {
            raw = Environment.GetEnvironmentVariable("CICD_MASTER_KEY");
        }

        if (string.IsNullOrWhiteSpace(raw))
        {
            throw new InvalidOperationException(
                "A master key is required: set Cicd:MasterKey or the CICD_MASTER_KEY environment variable.");
        }

        // Derive a 256-bit AES key from the configured string.
        return SHA256.HashData(Encoding.UTF8.GetBytes(raw));
    }

    private static DockerClient CreateDockerClient(CicdOptions options)
    {
        var socket = options.DockerSocket;
        if (string.IsNullOrWhiteSpace(socket))
        {
            // Honor DOCKER_HOST (Docker Desktop / rootless daemons expose non-default sockets).
            socket = Environment.GetEnvironmentVariable("DOCKER_HOST");
        }

        Uri endpoint;
        if (!string.IsNullOrWhiteSpace(socket))
        {
            endpoint = new Uri(socket);
        }
        else if (OperatingSystem.IsWindows())
        {
            endpoint = new Uri("npipe://./pipe/docker_engine");
        }
        else
        {
            endpoint = new Uri("unix:///var/run/docker.sock");
        }

        return new DockerClientConfiguration(endpoint).CreateClient();
    }
}
