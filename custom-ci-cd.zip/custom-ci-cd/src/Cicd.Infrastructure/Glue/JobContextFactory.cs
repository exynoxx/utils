using System.Security.Cryptography;
using System.Text;
using Cicd.Core.Common;
using Cicd.Core.Definition;
using Cicd.Core.Definition.Expressions;
using Cicd.Core.Domain;
using Cicd.Core.Execution;
using Cicd.Core.Secrets;
using Cicd.Core.Storage;
using Cicd.Core.Triggers;

namespace Cicd.Infrastructure.Glue;

/// <summary>
/// Builds the <see cref="JobExecutionContext"/> for a claimed job: loads the run, job and pipeline
/// definition; selects the job's definition slice (by matrix base name); resolves the pipeline's
/// secrets; assembles the base env (variables + job env + built-in <c>CICD_*</c>); wires the
/// <c>hash()</c> hook; and determines the workspace source.
/// </summary>
public sealed class JobContextFactory : IJobContextFactory
{
    private const string Workspace = "/workspace";

    private readonly IRunRepository _runs;
    private readonly IJobRepository _jobs;
    private readonly IPipelineRepository _pipelines;
    private readonly IPipelineDefinitionSource _definitionSource;
    private readonly ISecretStore _secretStore;
    private readonly GitMirror _mirror;

    public JobContextFactory(
        IRunRepository runs,
        IJobRepository jobs,
        IPipelineRepository pipelines,
        IPipelineDefinitionSource definitionSource,
        ISecretStore secretStore,
        GitMirror mirror)
    {
        _runs = runs;
        _jobs = jobs;
        _pipelines = pipelines;
        _definitionSource = definitionSource;
        _secretStore = secretStore;
        _mirror = mirror;
    }

    public async Task<JobExecutionContext> CreateAsync(ClaimedJob claimedJob, CancellationToken ct)
    {
        var job = await _jobs.GetAsync(claimedJob.JobId, ct)
            ?? throw new InvalidOperationException($"Job '{claimedJob.JobId}' not found.");
        var run = await _runs.GetAsync(job.RunId, ct)
            ?? throw new InvalidOperationException($"Run '{job.RunId}' not found.");
        var pipeline = await _pipelines.GetAsync(run.PipelineId, ct)
            ?? throw new InvalidOperationException($"Pipeline '{run.PipelineId}' not found.");

        var definition = await _definitionSource.GetDefinitionAsync(run.PipelineId, run.CommitSha, ct);

        var baseName = BaseName(job.Name);
        if (!definition.Jobs.TryGetValue(baseName, out var jobDef))
        {
            throw new InvalidOperationException($"Job '{baseName}' is not present in the pipeline definition.");
        }

        var resolved = jobDef.Resolve(definition.Defaults);

        var secretValues = await _secretStore.GetForPipelineAsync(run.PipelineId, ct);
        var matrix = job.MatrixValues ?? new Dictionary<string, string>();

        var workspaceSource = BuildWorkspaceSource(pipeline, run);
        var hashFiles = BuildHashFilesHook(pipeline, run);

        var expressionContext = new ExpressionContext
        {
            Branch = run.Branch,
            Event = run.TriggerOn,
            JobStatuses = new Dictionary<string, string>(),
            Vars = definition.Variables,
            Inputs = run.Inputs,
            Matrix = matrix,
            SecretNames = secretValues.Keys.ToHashSet(StringComparer.Ordinal),
            SecretValues = secretValues,
            HashFiles = hashFiles
        };

        var env = BuildEnv(definition, resolved, run, job, matrix, expressionContext);

        return new JobExecutionContext
        {
            RunId = run.Id,
            JobId = job.Id,
            JobName = job.Name,
            Image = resolved.Image,
            Executor = resolved.Executor,
            Steps = resolved.Steps,
            ExpressionContext = expressionContext,
            Env = env,
            SecretValues = secretValues,
            WorkspaceSource = workspaceSource,
            Caches = resolved.Caches,
            Artifacts = resolved.Artifacts,
            Needs = resolved.Needs,
            Timeout = resolved.Timeout
        };
    }

    private WorkspaceSource BuildWorkspaceSource(Pipeline pipeline, Run run)
    {
        if (PipelineDefinitionSource.TryGetLocalPath(pipeline, out var localPath))
        {
            return new LocalDirSource(localPath);
        }

        if (pipeline.RepoUrl is not null)
        {
            return new GitSource(pipeline.RepoUrl, run.CommitSha);
        }

        // Pure standalone pipeline with no source: the workspace volume starts empty.
        return new EmptySource();
    }

    private Func<string[], string> BuildHashFilesHook(Pipeline pipeline, Run run)
    {
        // For local-path pipelines, hash files directly from the local directory.
        if (PipelineDefinitionSource.TryGetLocalPath(pipeline, out var localPath))
        {
            var hasher = new FileHasher(localPath);
            return globs => hasher.Hash(globs);
        }

        // For repo-backed pipelines, hash the matching files at the commit from the bare mirror.
        if (pipeline.RepoUrl is not null)
        {
            var repoUrl = pipeline.RepoUrl;
            var sha = run.CommitSha;
            return globs => HashFromGit(repoUrl, sha, globs);
        }

        // Pure standalone: no files to hash.
        return _ => EmptyHash();
    }

    private string HashFromGit(string repoUrl, string sha, string[] globs)
    {
        var mirrorPath = _mirror.MirrorPath(repoUrl);
        var git = new GitCli();

        var listing = git
            .RunAsync(mirrorPath, CancellationToken.None, "ls-tree", "-r", "--name-only", sha)
            .GetAwaiter()
            .GetResult();

        if (!listing.Success)
        {
            return EmptyHash();
        }

        var matched = listing.StdOut
            .Split('\n', StringSplitOptions.RemoveEmptyEntries)
            .Select(p => p.Trim())
            .Where(p => p.Length > 0 && GlobMatcher.IsMatchAny(globs, p))
            .OrderBy(p => p, StringComparer.Ordinal)
            .ToList();

        using var stream = new MemoryStream();
        foreach (var path in matched)
        {
            var header = Encoding.UTF8.GetBytes(path + "\0");
            stream.Write(header, 0, header.Length);

            var content = git
                .RunAsync(mirrorPath, CancellationToken.None, "show", $"{sha}:{path}")
                .GetAwaiter()
                .GetResult();
            if (content.Success)
            {
                var bytes = Encoding.UTF8.GetBytes(content.StdOut);
                stream.Write(bytes, 0, bytes.Length);
            }
        }

        stream.Position = 0;
        return Convert.ToHexStringLower(SHA256.HashData(stream));
    }

    private static IReadOnlyDictionary<string, string> BuildEnv(
        PipelineDefinition definition,
        ResolvedJobDefinition resolved,
        Run run,
        Job job,
        IReadOnlyDictionary<string, string> matrix,
        ExpressionContext expressionContext)
    {
        var env = new Dictionary<string, string>(StringComparer.Ordinal);

        foreach (var (key, value) in definition.Variables)
        {
            env[key] = ExpressionEvaluator.Interpolate(value, expressionContext);
        }

        foreach (var (key, value) in resolved.Env)
        {
            env[key] = ExpressionEvaluator.Interpolate(value, expressionContext);
        }

        var shortSha = run.CommitSha.Length >= 7 ? run.CommitSha[..7] : run.CommitSha;
        env["CICD_RUN_ID"] = run.Id.Value.ToString();
        env["CICD_JOB_ID"] = job.Id.Value.ToString();
        env["CICD_PIPELINE"] = definition.Name;
        env["CICD_BRANCH"] = run.Branch;
        env["CICD_SHA"] = run.CommitSha;
        env["CICD_SHORT_SHA"] = shortSha;
        env["CICD_EVENT"] = run.TriggerOn;
        env["CICD_WORKSPACE"] = Workspace;

        return env;
    }

    private static string BaseName(string jobName)
    {
        var index = jobName.IndexOf(" (", StringComparison.Ordinal);
        return index < 0 ? jobName : jobName[..index];
    }

    private static string EmptyHash()
    {
        return Convert.ToHexStringLower(SHA256.HashData(ReadOnlySpan<byte>.Empty));
    }
}
