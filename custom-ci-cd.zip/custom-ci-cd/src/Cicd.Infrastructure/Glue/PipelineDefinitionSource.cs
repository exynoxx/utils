using Cicd.Core.Definition;
using Cicd.Core.Definition.Templates;
using Cicd.Core.Domain;
using Cicd.Core.Execution;
using Cicd.Core.Storage;

namespace Cicd.Infrastructure.Glue;

/// <summary>
/// Loads and parses a pipeline definition for a commit.
///
/// <list type="bullet">
/// <item>Repo-backed pipelines (RepoUrl is an http(s)/ssh URL): the <c>.pipeline.yml</c> is read at
/// the SHA from the bare mirror via <c>git show &lt;sha&gt;:.pipeline.yml</c>, and template
/// references resolve via <c>git show &lt;sha&gt;:&lt;path&gt;</c>.</item>
/// <item>Local-path pipelines (RepoUrl uses the <c>file://&lt;abs path&gt;</c> convention, used for
/// fileWatch/standalone pipelines registered with a directory): the <c>.pipeline.yml</c> and
/// templates are read from that local directory.</item>
/// <item>Pure standalone pipelines (RepoUrl null): the stored <c>RawYaml</c> is parsed; templates
/// are not available.</item>
/// </list>
/// </summary>
public sealed class PipelineDefinitionSource : IPipelineDefinitionSource
{
    private const string PipelineFile = ".pipeline.yml";

    private readonly IPipelineRepository _pipelines;
    private readonly GitMirror _mirror;

    public PipelineDefinitionSource(IPipelineRepository pipelines, GitMirror mirror)
    {
        _pipelines = pipelines;
        _mirror = mirror;
    }

    public async Task<PipelineDefinition> GetDefinitionAsync(PipelineId pipelineId, string commitSha, CancellationToken ct)
    {
        var pipeline = await _pipelines.GetAsync(pipelineId, ct)
            ?? throw new InvalidOperationException($"Pipeline '{pipelineId}' not found.");

        var (yaml, resolver) = await LoadAsync(pipeline, commitSha, ct);

        var parser = new PipelineParser(resolver);
        var result = parser.Parse(yaml);
        if (!result.Success || result.Definition is null)
        {
            var messages = string.Join("; ", result.Errors.Select(e => e.Message));
            throw new InvalidOperationException($"Pipeline '{pipeline.Name}' failed to parse: {messages}");
        }

        return result.Definition;
    }

    private async Task<(string Yaml, ITemplateResolver? Resolver)> LoadAsync(
        Pipeline pipeline,
        string commitSha,
        CancellationToken ct)
    {
        if (TryGetLocalPath(pipeline, out var localPath))
        {
            var pipelinePath = Path.Combine(localPath, PipelineFile);
            if (!File.Exists(pipelinePath) && pipeline.RawYaml is not null)
            {
                return (pipeline.RawYaml, new FileSystemTemplateResolver(localPath));
            }

            var yaml = await File.ReadAllTextAsync(pipelinePath, ct);
            return (yaml, new FileSystemTemplateResolver(localPath));
        }

        if (pipeline.RepoUrl is not null)
        {
            var repoUrl = pipeline.RepoUrl;
            var yaml = await _mirror.ShowFileAsync(repoUrl, commitSha, PipelineFile, ct)
                ?? throw new InvalidOperationException(
                    $"'{PipelineFile}' not found at {commitSha} in {repoUrl}.");

            var resolver = new DelegateTemplateResolver(reference =>
            {
                var relative = reference.TrimStart('.', '/');
                var content = _mirror.ShowFileAsync(repoUrl, commitSha, relative, ct).GetAwaiter().GetResult();
                return content is null ? null : new TemplateDocument(relative, content);
            });

            return (yaml, resolver);
        }

        // Pure standalone: stored YAML, no template resolution available.
        var raw = pipeline.RawYaml
            ?? throw new InvalidOperationException($"Pipeline '{pipeline.Name}' has neither a repo URL nor stored YAML.");
        return (raw, null);
    }

    /// <summary>Local-path pipelines use the <c>file://&lt;abs path&gt;</c> convention in RepoUrl.</summary>
    public static bool TryGetLocalPath(Pipeline pipeline, out string localPath)
    {
        localPath = string.Empty;
        if (pipeline.RepoUrl is null ||
            !pipeline.RepoUrl.StartsWith("file://", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        localPath = pipeline.RepoUrl["file://".Length..];
        return true;
    }
}
