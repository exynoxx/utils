using System.Security.Cryptography;
using System.Text;
using Cicd.Core.Triggers;

namespace Cicd.Infrastructure.Glue;

/// <summary>
/// Resolves and reads from the bare git mirrors maintained by the push trigger under the mirror
/// root. The naming convention (sha256(repoUrl)[..16] + ".git") mirrors
/// <see cref="PushTriggerSource"/> so both subsystems share the same on-disk mirror.
/// </summary>
public sealed class GitMirror
{
    private readonly string _mirrorRoot;
    private readonly GitCli _git;

    public GitMirror(string mirrorRoot, GitCli git)
    {
        _mirrorRoot = mirrorRoot;
        _git = git;
    }

    public string MirrorPath(string repoUrl)
    {
        return Path.Combine(_mirrorRoot, RepoHash(repoUrl) + ".git");
    }

    /// <summary>Ensures the mirror exists locally, cloning it if the push trigger has not yet.</summary>
    public async Task EnsureMirrorAsync(string repoUrl, CancellationToken ct)
    {
        Directory.CreateDirectory(_mirrorRoot);
        var path = MirrorPath(repoUrl);
        if (!Directory.Exists(path))
        {
            var clone = await _git.RunAsync(null, ct, "clone", "--mirror", repoUrl, path);
            if (!clone.Success)
            {
                throw new InvalidOperationException($"git clone --mirror failed: {clone.StdErr}");
            }
        }
    }

    /// <summary>Reads a file at a specific commit via <c>git show &lt;sha&gt;:&lt;path&gt;</c>; null when absent.</summary>
    public async Task<string?> ShowFileAsync(string repoUrl, string sha, string path, CancellationToken ct)
    {
        await EnsureMirrorAsync(repoUrl, ct);
        var mirrorPath = MirrorPath(repoUrl);

        var result = await _git.RunAsync(mirrorPath, ct, "show", $"{sha}:{path}");
        if (!result.Success)
        {
            // Try fetching the SHA in case the mirror is stale, then retry once.
            await _git.RunAsync(mirrorPath, ct, "fetch", "--prune", "origin");
            result = await _git.RunAsync(mirrorPath, ct, "show", $"{sha}:{path}");
            if (!result.Success)
            {
                return null;
            }
        }

        return result.StdOut;
    }

    private static string RepoHash(string repoUrl)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(repoUrl));
        return Convert.ToHexStringLower(bytes)[..16];
    }
}
