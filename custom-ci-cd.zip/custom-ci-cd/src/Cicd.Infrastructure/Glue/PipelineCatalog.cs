using Cicd.Core.Definition;
using Cicd.Core.Storage;
using Cicd.Core.Triggers;
using Microsoft.Extensions.Logging;

namespace Cicd.Infrastructure.Glue;

/// <summary>
/// Lists registered pipelines with their parsed trigger definitions for the trigger sources to
/// watch. Triggers are parsed from the pipeline's stored <c>RawYaml</c> snapshot (registered
/// alongside repo URL or as a standalone definition). Pipelines whose YAML cannot be parsed are
/// surfaced with an empty trigger list rather than failing the whole catalog.
/// </summary>
public sealed class PipelineCatalog : IPipelineCatalog
{
    private const string DefaultBranch = "main";

    private readonly IPipelineRepository _pipelines;
    private readonly IPipelineParser _parser;
    private readonly ILogger<PipelineCatalog> _logger;

    public PipelineCatalog(IPipelineRepository pipelines, IPipelineParser parser, ILogger<PipelineCatalog> logger)
    {
        _pipelines = pipelines;
        _parser = parser;
        _logger = logger;
    }

    public async Task<IReadOnlyList<CatalogEntry>> ListAsync(CancellationToken ct)
    {
        var page = await _pipelines.ListAsync(0, int.MaxValue, ct);
        var entries = new List<CatalogEntry>();

        foreach (var pipeline in page.Items)
        {
            IReadOnlyList<TriggerDefinition> triggers = [];
            if (pipeline.RawYaml is not null)
            {
                var result = _parser.Parse(pipeline.RawYaml);
                if (result.Success && result.Definition is not null)
                {
                    triggers = result.Definition.Triggers;
                }
                else
                {
                    _logger.LogWarning("Pipeline {Name} YAML did not parse for catalog; no triggers", pipeline.Name);
                }
            }

            entries.Add(new CatalogEntry(pipeline.Id, pipeline.RepoUrl, DefaultBranch, triggers));
        }

        return entries;
    }
}
