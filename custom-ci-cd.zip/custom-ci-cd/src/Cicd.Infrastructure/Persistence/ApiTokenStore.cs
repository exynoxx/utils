using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace Cicd.Infrastructure.Persistence;

/// <summary>An API token's metadata (never the raw token, which is only shown once at creation).</summary>
public sealed record ApiTokenInfo(Guid Id, string Name, DateTimeOffset CreatedAt, DateTimeOffset? LastUsedAt);

/// <summary>
/// Stores per-user API tokens, hashed at rest (SHA-256). Defined in Infrastructure so the Server
/// can guard endpoints by validating a presented bearer token against the stored hashes.
/// </summary>
public interface IApiTokenStore
{
    /// <summary>Creates a token, returns its id and the raw token value (shown once).</summary>
    Task<(Guid Id, string RawToken)> CreateAsync(string name, CancellationToken ct);

    /// <summary>
    /// Creates a token with a caller-supplied raw value (used for a configured bootstrap token).
    /// Only the hash is stored, as with <see cref="CreateAsync"/>.
    /// </summary>
    Task<Guid> CreateBootstrapAsync(string name, string rawToken, CancellationToken ct);

    Task<IReadOnlyList<ApiTokenInfo>> ListAsync(CancellationToken ct);

    Task DeleteAsync(Guid id, CancellationToken ct);

    /// <summary>Validates a presented raw token by hash, updating last-used. Returns the token name when valid.</summary>
    Task<string?> ValidateAsync(string rawToken, CancellationToken ct);
}

public sealed class ApiTokenStore : IApiTokenStore
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public ApiTokenStore(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<(Guid Id, string RawToken)> CreateAsync(string name, CancellationToken ct)
    {
        var rawToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
            .Replace('+', '-')
            .Replace('/', '_')
            .TrimEnd('=');

        var entity = new ApiTokenEntity
        {
            Id = Guid.CreateVersion7(),
            Name = name,
            TokenHash = HashToken(rawToken),
            CreatedAt = DateTimeOffset.UtcNow
        };

        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        db.ApiTokens.Add(entity);
        await db.SaveChangesAsync(ct);
        return (entity.Id, rawToken);
    }

    public async Task<Guid> CreateBootstrapAsync(string name, string rawToken, CancellationToken ct)
    {
        var entity = new ApiTokenEntity
        {
            Id = Guid.CreateVersion7(),
            Name = name,
            TokenHash = HashToken(rawToken),
            CreatedAt = DateTimeOffset.UtcNow
        };

        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        db.ApiTokens.Add(entity);
        await db.SaveChangesAsync(ct);
        return entity.Id;
    }

    public async Task<IReadOnlyList<ApiTokenInfo>> ListAsync(CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.ApiTokens
            .AsNoTracking()
            .OrderByDescending(t => t.CreatedAt)
            .ToListAsync(ct);
        return entities
            .Select(t => new ApiTokenInfo(t.Id, t.Name, t.CreatedAt, t.LastUsedAt))
            .ToList();
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.ApiTokens.Where(t => t.Id == id).ExecuteDeleteAsync(ct);
    }

    public async Task<string?> ValidateAsync(string rawToken, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(rawToken))
        {
            return null;
        }

        var hash = HashToken(rawToken);
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.ApiTokens.FirstOrDefaultAsync(t => t.TokenHash == hash, ct);
        if (entity is null)
        {
            return null;
        }

        entity.LastUsedAt = DateTimeOffset.UtcNow;
        await db.SaveChangesAsync(ct);
        return entity.Name;
    }

    private static byte[] HashToken(string rawToken)
    {
        return SHA256.HashData(Encoding.UTF8.GetBytes(rawToken));
    }
}
