using Cicd.Core.Domain;
using Cicd.Core.Secrets;
using Microsoft.EntityFrameworkCore;

namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// Postgres-backed secret store. Values are encrypted at rest with AES-256-GCM via
/// <see cref="SecretCipher"/>; ciphertext, nonce and auth tag are stored in separate columns.
/// Resolution for a pipeline layers per-pipeline secrets over global ones.
/// </summary>
public sealed class PostgresSecretStore : ISecretStore
{
    private const string GlobalScope = "global";
    private const string PipelineScope = "pipeline";

    private readonly IDbContextFactory<CicdDbContext> _contextFactory;
    private readonly SecretCipher _cipher;

    public PostgresSecretStore(IDbContextFactory<CicdDbContext> contextFactory, SecretCipher cipher)
    {
        _contextFactory = contextFactory;
        _cipher = cipher;
    }

    public async Task<IReadOnlyDictionary<string, string>> GetForPipelineAsync(PipelineId pipelineId, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.Secrets
            .AsNoTracking()
            .Where(s => s.Scope == GlobalScope || (s.Scope == PipelineScope && s.PipelineId == pipelineId.Value))
            .ToListAsync(ct);

        var result = new Dictionary<string, string>(StringComparer.Ordinal);

        // Apply globals first, then let per-pipeline secrets override by name.
        foreach (var entity in entities.Where(e => e.Scope == GlobalScope))
        {
            result[entity.Name] = Decrypt(entity);
        }

        foreach (var entity in entities.Where(e => e.Scope == PipelineScope))
        {
            result[entity.Name] = Decrypt(entity);
        }

        return result;
    }

    public async Task SetAsync(string name, string scope, PipelineId? pipelineId, string value, CancellationToken ct)
    {
        var pipelineKey = pipelineId?.Value;
        var encrypted = _cipher.Encrypt(value);

        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Secrets
            .FirstOrDefaultAsync(s => s.Name == name && s.Scope == scope && s.PipelineId == pipelineKey, ct);

        if (entity is null)
        {
            db.Secrets.Add(new SecretEntity
            {
                Id = Guid.CreateVersion7(),
                Name = name,
                Scope = scope,
                PipelineId = pipelineKey,
                Ciphertext = encrypted.Ciphertext,
                Nonce = encrypted.Nonce,
                Tag = encrypted.Tag,
                CreatedAt = DateTimeOffset.UtcNow
            });
        }
        else
        {
            entity.Ciphertext = encrypted.Ciphertext;
            entity.Nonce = encrypted.Nonce;
            entity.Tag = encrypted.Tag;
        }

        await db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(string name, string scope, PipelineId? pipelineId, CancellationToken ct)
    {
        var pipelineKey = pipelineId?.Value;
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.Secrets
            .Where(s => s.Name == name && s.Scope == scope && s.PipelineId == pipelineKey)
            .ExecuteDeleteAsync(ct);
    }

    public async Task<IReadOnlyList<SecretInfo>> ListAsync(CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.Secrets
            .AsNoTracking()
            .OrderBy(s => s.Name)
            .ToListAsync(ct);
        return entities
            .Select(s => new SecretInfo(
                s.Name,
                s.Scope,
                s.PipelineId is null ? null : new PipelineId(s.PipelineId.Value)))
            .ToList();
    }

    private string Decrypt(SecretEntity entity)
    {
        return _cipher.Decrypt(new EncryptedSecret(entity.Ciphertext, entity.Nonce, entity.Tag));
    }
}
