using System.Text.Json;
using Cicd.Core.Domain;

namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// Maps between the immutable Core domain records and the mutable EF entities.
/// </summary>
internal static class EntityMapping
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    public static string SerializeStringList(IReadOnlyList<string> value)
    {
        return JsonSerializer.Serialize(value, JsonOptions);
    }

    public static IReadOnlyList<string> DeserializeStringList(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return [];
        }

        return JsonSerializer.Deserialize<List<string>>(json, JsonOptions) ?? [];
    }

    public static string? SerializeStringMap(IReadOnlyDictionary<string, string>? value)
    {
        if (value is null)
        {
            return null;
        }

        return JsonSerializer.Serialize(value, JsonOptions);
    }

    public static IReadOnlyDictionary<string, string> DeserializeStringMap(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return new Dictionary<string, string>();
        }

        return JsonSerializer.Deserialize<Dictionary<string, string>>(json, JsonOptions)
            ?? new Dictionary<string, string>();
    }

    public static IReadOnlyDictionary<string, string>? DeserializeNullableStringMap(string? json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return null;
        }

        return JsonSerializer.Deserialize<Dictionary<string, string>>(json, JsonOptions);
    }

    public static PipelineEntity ToEntity(Pipeline pipeline)
    {
        return new PipelineEntity
        {
            Id = pipeline.Id.Value,
            Name = pipeline.Name,
            RepoUrl = pipeline.RepoUrl,
            RawYaml = pipeline.RawYaml,
            CreatedAt = pipeline.CreatedAt
        };
    }

    public static Pipeline ToDomain(PipelineEntity entity)
    {
        return new Pipeline
        {
            Id = new PipelineId(entity.Id),
            Name = entity.Name,
            RepoUrl = entity.RepoUrl,
            RawYaml = entity.RawYaml,
            CreatedAt = entity.CreatedAt
        };
    }

    public static RunEntity ToEntity(Run run)
    {
        return new RunEntity
        {
            Id = run.Id.Value,
            PipelineId = run.PipelineId.Value,
            TriggerOn = run.TriggerOn,
            Branch = run.Branch,
            CommitSha = run.CommitSha,
            Inputs = SerializeStringMap(run.Inputs),
            Status = run.Status.ToString(),
            CreatedAt = run.CreatedAt,
            StartedAt = run.StartedAt,
            FinishedAt = run.FinishedAt
        };
    }

    public static Run ToDomain(RunEntity entity)
    {
        return new Run
        {
            Id = new RunId(entity.Id),
            PipelineId = new PipelineId(entity.PipelineId),
            TriggerOn = entity.TriggerOn,
            Branch = entity.Branch,
            CommitSha = entity.CommitSha,
            Inputs = DeserializeStringMap(entity.Inputs),
            Status = Enum.Parse<RunStatus>(entity.Status),
            CreatedAt = entity.CreatedAt,
            StartedAt = entity.StartedAt,
            FinishedAt = entity.FinishedAt
        };
    }

    public static JobEntity ToEntity(Job job)
    {
        return new JobEntity
        {
            Id = job.Id.Value,
            RunId = job.RunId.Value,
            Name = job.Name,
            Executor = job.Executor,
            Image = job.Image,
            Needs = SerializeStringList(job.Needs),
            If = job.If,
            Matrix = SerializeStringMap(job.MatrixValues),
            Status = job.Status.ToString(),
            Attempt = job.Attempt,
            MaxRetries = job.MaxRetries,
            TimeoutSeconds = (int)job.Timeout.TotalSeconds,
            ClaimedBy = job.ClaimedBy?.Value,
            LeaseExpiresAt = job.LeaseExpiresAt,
            LogSize = job.LogSize,
            CreatedAt = DateTimeOffset.UtcNow,
            StartedAt = job.StartedAt,
            FinishedAt = job.FinishedAt
        };
    }

    public static Job ToDomain(JobEntity entity)
    {
        return new Job
        {
            Id = new JobId(entity.Id),
            RunId = new RunId(entity.RunId),
            Name = entity.Name,
            Executor = entity.Executor,
            Image = entity.Image,
            Needs = DeserializeStringList(entity.Needs),
            If = entity.If,
            MatrixValues = DeserializeNullableStringMap(entity.Matrix),
            Status = Enum.Parse<JobStatus>(entity.Status),
            Attempt = entity.Attempt,
            MaxRetries = entity.MaxRetries,
            Timeout = TimeSpan.FromSeconds(entity.TimeoutSeconds),
            ClaimedBy = entity.ClaimedBy is null ? null : new WorkerId(entity.ClaimedBy.Value),
            LeaseExpiresAt = entity.LeaseExpiresAt,
            LogSize = entity.LogSize,
            StartedAt = entity.StartedAt,
            FinishedAt = entity.FinishedAt
        };
    }

    public static StepEntity ToEntity(StepRecord step)
    {
        return new StepEntity
        {
            Id = step.Id.Value,
            JobId = step.JobId.Value,
            Ordinal = step.Ordinal,
            Name = step.Name,
            Status = step.Status.ToString(),
            ExitCode = step.ExitCode,
            StartedAt = step.StartedAt,
            FinishedAt = step.FinishedAt
        };
    }

    public static StepRecord ToDomain(StepEntity entity)
    {
        return new StepRecord
        {
            Id = new StepId(entity.Id),
            JobId = new JobId(entity.JobId),
            Ordinal = entity.Ordinal,
            Name = entity.Name,
            Status = Enum.Parse<StepStatus>(entity.Status),
            ExitCode = entity.ExitCode,
            StartedAt = entity.StartedAt,
            FinishedAt = entity.FinishedAt
        };
    }
}
