namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// EF Core persistence entities. These are deliberately separate from the Core domain records
/// (which are immutable); repositories map between the two. Status columns store enum names as text.
/// </summary>
public sealed class PipelineEntity
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? RepoUrl { get; set; }
    public string? RawYaml { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class RunEntity
{
    public Guid Id { get; set; }
    public Guid PipelineId { get; set; }
    public string TriggerOn { get; set; } = string.Empty;
    public string Branch { get; set; } = string.Empty;
    public string CommitSha { get; set; } = string.Empty;

    /// <summary>JSON-serialized string→string map.</summary>
    public string? Inputs { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? FinishedAt { get; set; }
}

public sealed class JobEntity
{
    public Guid Id { get; set; }
    public Guid RunId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Executor { get; set; } = string.Empty;
    public string? Image { get; set; }

    /// <summary>JSON-serialized list of needed job names.</summary>
    public string Needs { get; set; } = "[]";

    public string? If { get; set; }

    /// <summary>JSON-serialized matrix axis values (string→string), or null.</summary>
    public string? Matrix { get; set; }

    public string Status { get; set; } = string.Empty;
    public int Attempt { get; set; }
    public int MaxRetries { get; set; }
    public int TimeoutSeconds { get; set; }
    public Guid? ClaimedBy { get; set; }
    public DateTimeOffset? ClaimedAt { get; set; }
    public DateTimeOffset? LeaseExpiresAt { get; set; }
    public long LogSize { get; set; }

    /// <summary>Persistence-only ordering column for the queue (Core's Job has no created_at).</summary>
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? FinishedAt { get; set; }
}

public sealed class StepEntity
{
    public Guid Id { get; set; }
    public Guid JobId { get; set; }
    public int Ordinal { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public int? ExitCode { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? FinishedAt { get; set; }
}

public sealed class SecretEntity
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Scope { get; set; } = string.Empty;
    public Guid? PipelineId { get; set; }
    public byte[] Ciphertext { get; set; } = [];
    public byte[] Nonce { get; set; } = [];

    /// <summary>AES-GCM authentication tag, stored alongside ciphertext/nonce.</summary>
    public byte[] Tag { get; set; } = [];
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class ArtifactEntity
{
    public Guid Id { get; set; }
    public Guid RunId { get; set; }
    public Guid JobId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public long SizeBytes { get; set; }
    public DateTimeOffset? ExpiresAt { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
}

public sealed class CacheEntryEntity
{
    public Guid Id { get; set; }
    public string Key { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public long SizeBytes { get; set; }
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset LastUsedAt { get; set; }
}

public sealed class RepoBranchStateEntity
{
    public string RepoUrl { get; set; } = string.Empty;
    public string Branch { get; set; } = string.Empty;
    public string LastSha { get; set; } = string.Empty;
}

public sealed class ApiTokenEntity
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public byte[] TokenHash { get; set; } = [];
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset? LastUsedAt { get; set; }
}
