using Cicd.Core.Domain;
using Cicd.Core.Storage;
using Microsoft.EntityFrameworkCore;

namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// Each repository takes an <see cref="IDbContextFactory{TContext}"/> and creates a fresh context
/// per operation; worker loops are concurrent and a shared scoped context is not thread-safe.
/// </summary>
public sealed class PipelineRepository : IPipelineRepository
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public PipelineRepository(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<Pipeline> CreateAsync(Pipeline pipeline, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = EntityMapping.ToEntity(pipeline);
        db.Pipelines.Add(entity);
        await db.SaveChangesAsync(ct);
        return EntityMapping.ToDomain(entity);
    }

    public async Task<Pipeline?> GetAsync(PipelineId id, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Pipelines.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id.Value, ct);
        return entity is null ? null : EntityMapping.ToDomain(entity);
    }

    public async Task<Pipeline?> GetByNameAsync(string name, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Pipelines.AsNoTracking().FirstOrDefaultAsync(p => p.Name == name, ct);
        return entity is null ? null : EntityMapping.ToDomain(entity);
    }

    public async Task<Page<Pipeline>> ListAsync(int skip, int take, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var total = await db.Pipelines.CountAsync(ct);
        var entities = await db.Pipelines
            .AsNoTracking()
            .OrderByDescending(p => p.CreatedAt)
            .Skip(skip)
            .Take(take)
            .ToListAsync(ct);
        return new Page<Pipeline>(entities.Select(EntityMapping.ToDomain).ToList(), total);
    }

    public async Task<Pipeline> UpdateAsync(Pipeline pipeline, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Pipelines.FirstOrDefaultAsync(p => p.Id == pipeline.Id.Value, ct)
            ?? throw new InvalidOperationException($"Pipeline '{pipeline.Id}' not found.");

        entity.Name = pipeline.Name;
        entity.RepoUrl = pipeline.RepoUrl;
        entity.RawYaml = pipeline.RawYaml;
        await db.SaveChangesAsync(ct);
        return EntityMapping.ToDomain(entity);
    }

    public async Task DeleteAsync(PipelineId id, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.Pipelines.Where(p => p.Id == id.Value).ExecuteDeleteAsync(ct);
    }
}

public sealed class RunRepository : IRunRepository
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public RunRepository(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<Run> CreateAsync(Run run, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = EntityMapping.ToEntity(run);
        db.Runs.Add(entity);
        await db.SaveChangesAsync(ct);
        return EntityMapping.ToDomain(entity);
    }

    public async Task<Run?> GetAsync(RunId id, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Runs.AsNoTracking().FirstOrDefaultAsync(r => r.Id == id.Value, ct);
        return entity is null ? null : EntityMapping.ToDomain(entity);
    }

    public async Task<Page<Run>> ListByPipelineAsync(PipelineId pipelineId, int skip, int take, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var query = db.Runs.AsNoTracking().Where(r => r.PipelineId == pipelineId.Value);
        var total = await query.CountAsync(ct);
        var entities = await query
            .OrderByDescending(r => r.CreatedAt)
            .Skip(skip)
            .Take(take)
            .ToListAsync(ct);
        return new Page<Run>(entities.Select(EntityMapping.ToDomain).ToList(), total);
    }

    public async Task UpdateStatusAsync(
        RunId id,
        RunStatus status,
        DateTimeOffset? startedAt,
        DateTimeOffset? finishedAt,
        CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Runs.FirstOrDefaultAsync(r => r.Id == id.Value, ct);
        if (entity is null)
        {
            return;
        }

        entity.Status = status.ToString();
        if (startedAt is not null)
        {
            entity.StartedAt = startedAt;
        }

        if (finishedAt is not null)
        {
            entity.FinishedAt = finishedAt;
        }

        await db.SaveChangesAsync(ct);
    }
}

public sealed class JobRepository : IJobRepository
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public JobRepository(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<Job> CreateAsync(Job job, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = EntityMapping.ToEntity(job);
        db.Jobs.Add(entity);
        await db.SaveChangesAsync(ct);
        return EntityMapping.ToDomain(entity);
    }

    public async Task<Job?> GetAsync(JobId id, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Jobs.AsNoTracking().FirstOrDefaultAsync(j => j.Id == id.Value, ct);
        return entity is null ? null : EntityMapping.ToDomain(entity);
    }

    public async Task<IReadOnlyList<Job>> ListByRunAsync(RunId runId, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.Jobs
            .AsNoTracking()
            .Where(j => j.RunId == runId.Value)
            .OrderBy(j => j.CreatedAt)
            .ToListAsync(ct);
        return entities.Select(EntityMapping.ToDomain).ToList();
    }

    public async Task UpdateStatusAsync(
        JobId id,
        JobStatus status,
        DateTimeOffset? startedAt,
        DateTimeOffset? finishedAt,
        CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Jobs.FirstOrDefaultAsync(j => j.Id == id.Value, ct);
        if (entity is null)
        {
            return;
        }

        entity.Status = status.ToString();
        if (startedAt is not null)
        {
            entity.StartedAt = startedAt;
        }

        if (finishedAt is not null)
        {
            entity.FinishedAt = finishedAt;
        }

        await db.SaveChangesAsync(ct);
    }

    public async Task UpdateAttemptAsync(JobId id, int attempt, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.Jobs
            .Where(j => j.Id == id.Value)
            .ExecuteUpdateAsync(s => s.SetProperty(j => j.Attempt, attempt), ct);
    }

    public async Task UpdateLogSizeAsync(JobId id, long logSize, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.Jobs
            .Where(j => j.Id == id.Value)
            .ExecuteUpdateAsync(s => s.SetProperty(j => j.LogSize, logSize), ct);
    }
}

public sealed class StepRepository : IStepRepository
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public StepRepository(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task CreateManyAsync(IReadOnlyList<StepRecord> steps, CancellationToken ct)
    {
        if (steps.Count == 0)
        {
            return;
        }

        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        db.Steps.AddRange(steps.Select(EntityMapping.ToEntity));
        await db.SaveChangesAsync(ct);
    }

    public async Task<IReadOnlyList<StepRecord>> ListByJobAsync(JobId jobId, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.Steps
            .AsNoTracking()
            .Where(s => s.JobId == jobId.Value)
            .OrderBy(s => s.Ordinal)
            .ToListAsync(ct);
        return entities.Select(EntityMapping.ToDomain).ToList();
    }

    public async Task UpdateStatusAsync(
        StepId id,
        StepStatus status,
        int? exitCode,
        DateTimeOffset? startedAt,
        DateTimeOffset? finishedAt,
        CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Steps.FirstOrDefaultAsync(s => s.Id == id.Value, ct);
        if (entity is null)
        {
            return;
        }

        entity.Status = status.ToString();
        if (exitCode is not null)
        {
            entity.ExitCode = exitCode;
        }

        if (startedAt is not null)
        {
            entity.StartedAt = startedAt;
        }

        if (finishedAt is not null)
        {
            entity.FinishedAt = finishedAt;
        }

        await db.SaveChangesAsync(ct);
    }
}

public sealed class ArtifactRepository : IArtifactRepository
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public ArtifactRepository(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<ArtifactRecord> CreateAsync(ArtifactRecord artifact, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = ToEntity(artifact);
        db.Artifacts.Add(entity);
        await db.SaveChangesAsync(ct);
        return ToDomain(entity);
    }

    public async Task<ArtifactRecord?> GetAsync(ArtifactId id, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.Artifacts.AsNoTracking().FirstOrDefaultAsync(a => a.Id == id.Value, ct);
        return entity is null ? null : ToDomain(entity);
    }

    public async Task<IReadOnlyList<ArtifactRecord>> ListByRunAsync(RunId runId, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.Artifacts
            .AsNoTracking()
            .Where(a => a.RunId == runId.Value)
            .ToListAsync(ct);
        return entities.Select(ToDomain).ToList();
    }

    public async Task<IReadOnlyList<ArtifactRecord>> ListByJobAsync(JobId jobId, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.Artifacts
            .AsNoTracking()
            .Where(a => a.JobId == jobId.Value)
            .ToListAsync(ct);
        return entities.Select(ToDomain).ToList();
    }

    public async Task<IReadOnlyList<ArtifactRecord>> ListExpiredAsync(DateTimeOffset now, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entities = await db.Artifacts
            .AsNoTracking()
            .Where(a => a.ExpiresAt != null && a.ExpiresAt < now)
            .ToListAsync(ct);
        return entities.Select(ToDomain).ToList();
    }

    public async Task DeleteAsync(ArtifactId id, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.Artifacts.Where(a => a.Id == id.Value).ExecuteDeleteAsync(ct);
    }

    private static ArtifactEntity ToEntity(ArtifactRecord record)
    {
        return new ArtifactEntity
        {
            Id = record.Id.Value,
            RunId = record.RunId.Value,
            JobId = record.JobId.Value,
            Name = record.Name,
            Path = record.Path,
            SizeBytes = record.SizeBytes,
            ExpiresAt = record.ExpiresAt,
            CreatedAt = record.CreatedAt
        };
    }

    private static ArtifactRecord ToDomain(ArtifactEntity entity)
    {
        return new ArtifactRecord
        {
            Id = new ArtifactId(entity.Id),
            RunId = new RunId(entity.RunId),
            JobId = new JobId(entity.JobId),
            Name = entity.Name,
            Path = entity.Path,
            SizeBytes = entity.SizeBytes,
            ExpiresAt = entity.ExpiresAt,
            CreatedAt = entity.CreatedAt
        };
    }
}

public sealed class RepoBranchStateStore : IRepoBranchStateStore
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public RepoBranchStateStore(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<string?> GetLastShaAsync(string repoUrl, string branch, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.RepoBranchStates
            .AsNoTracking()
            .FirstOrDefaultAsync(s => s.RepoUrl == repoUrl && s.Branch == branch, ct);
        return entity?.LastSha;
    }

    public async Task SetLastShaAsync(string repoUrl, string branch, string sha, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var entity = await db.RepoBranchStates
            .FirstOrDefaultAsync(s => s.RepoUrl == repoUrl && s.Branch == branch, ct);
        if (entity is null)
        {
            db.RepoBranchStates.Add(new RepoBranchStateEntity
            {
                RepoUrl = repoUrl,
                Branch = branch,
                LastSha = sha
            });
        }
        else
        {
            entity.LastSha = sha;
        }

        await db.SaveChangesAsync(ct);
    }
}
