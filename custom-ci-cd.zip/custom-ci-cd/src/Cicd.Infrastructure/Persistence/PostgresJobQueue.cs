using Cicd.Core.Domain;
using Cicd.Core.Execution;
using Microsoft.EntityFrameworkCore;

namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// Postgres-backed job queue. Claiming uses <c>FOR UPDATE SKIP LOCKED</c> inside a transaction so
/// concurrent workers never claim the same job.
/// </summary>
public sealed class PostgresJobQueue : IJobQueue
{
    private static readonly TimeSpan LeaseDuration = TimeSpan.FromMinutes(2);

    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public PostgresJobQueue(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task EnqueueAsync(JobId jobId, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.Jobs
            .Where(j => j.Id == jobId.Value)
            .ExecuteUpdateAsync(
                s => s
                    .SetProperty(j => j.Status, JobStatus.Queued.ToString())
                    .SetProperty(j => j.ClaimedBy, (Guid?)null)
                    .SetProperty(j => j.ClaimedAt, (DateTimeOffset?)null)
                    .SetProperty(j => j.LeaseExpiresAt, (DateTimeOffset?)null),
                ct);
    }

    public async Task<ClaimedJob?> ClaimNextAsync(WorkerId worker, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await using var tx = await db.Database.BeginTransactionAsync(ct);

        var queued = JobStatus.Queued.ToString();
        var candidate = await db.Jobs
            .FromSqlRaw(
                "SELECT * FROM jobs WHERE status = {0} ORDER BY created_at LIMIT 1 FOR UPDATE SKIP LOCKED",
                queued)
            .FirstOrDefaultAsync(ct);

        if (candidate is null)
        {
            await tx.RollbackAsync(ct);
            return null;
        }

        var now = DateTimeOffset.UtcNow;
        var leaseExpiresAt = now.Add(LeaseDuration);

        candidate.Status = JobStatus.Running.ToString();
        candidate.ClaimedBy = worker.Value;
        candidate.ClaimedAt = now;
        candidate.LeaseExpiresAt = leaseExpiresAt;
        if (candidate.StartedAt is null)
        {
            candidate.StartedAt = now;
        }

        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);

        return new ClaimedJob(
            new JobId(candidate.Id),
            new RunId(candidate.RunId),
            candidate.Attempt,
            leaseExpiresAt);
    }

    public async Task CompleteAsync(JobId jobId, JobStatus status, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var now = DateTimeOffset.UtcNow;
        await db.Jobs
            .Where(j => j.Id == jobId.Value)
            .ExecuteUpdateAsync(
                s => s
                    .SetProperty(j => j.Status, status.ToString())
                    .SetProperty(j => j.FinishedAt, now)
                    .SetProperty(j => j.ClaimedBy, (Guid?)null)
                    .SetProperty(j => j.LeaseExpiresAt, (DateTimeOffset?)null),
                ct);
    }

    public async Task<bool> RenewLeaseAsync(JobId jobId, WorkerId worker, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var running = JobStatus.Running.ToString();
        var leaseExpiresAt = DateTimeOffset.UtcNow.Add(LeaseDuration);
        var updated = await db.Jobs
            .Where(j => j.Id == jobId.Value
                && j.ClaimedBy == worker.Value
                && j.Status == running)
            .ExecuteUpdateAsync(s => s.SetProperty(j => j.LeaseExpiresAt, leaseExpiresAt), ct);
        return updated > 0;
    }
}
