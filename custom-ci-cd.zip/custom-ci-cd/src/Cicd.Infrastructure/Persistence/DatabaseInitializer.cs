using Microsoft.EntityFrameworkCore;

namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// Creates the database schema at startup. Pragmatic v1: uses
/// <see cref="DatabaseFacade.EnsureCreatedAsync"/> rather than migrations.
/// </summary>
public sealed class DatabaseInitializer
{
    private readonly IDbContextFactory<CicdDbContext> _contextFactory;

    public DatabaseInitializer(IDbContextFactory<CicdDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task InitializeDatabaseAsync(CancellationToken ct = default)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.Database.EnsureCreatedAsync(ct);
    }
}
