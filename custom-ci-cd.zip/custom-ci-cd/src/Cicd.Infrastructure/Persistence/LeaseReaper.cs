using Cicd.Core.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// Requeues jobs whose worker lease has expired (the worker likely crashed). Running jobs whose
/// <c>lease_expires_at</c> is in the past are reset to Queued so another worker can claim them.
/// The attempt count is left unchanged — a lost lease is not a job failure.
/// </summary>
public sealed class LeaseReaper
{
    private static readonly TimeSpan SweepInterval = TimeSpan.FromSeconds(30);

    private readonly IDbContextFactory<CicdDbContext> _contextFactory;
    private readonly ILogger<LeaseReaper> _logger;

    public LeaseReaper(IDbContextFactory<CicdDbContext> contextFactory, ILogger<LeaseReaper> logger)
    {
        _contextFactory = contextFactory;
        _logger = logger;
    }

    public async Task RunAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                await ReapAsync(ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                return;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Lease reaper sweep failed");
            }

            try
            {
                await Task.Delay(SweepInterval, ct);
            }
            catch (OperationCanceledException)
            {
                return;
            }
        }
    }

    public async Task<int> ReapAsync(CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var running = JobStatus.Running.ToString();
        var queued = JobStatus.Queued.ToString();
        var now = DateTimeOffset.UtcNow;

        var requeued = await db.Jobs
            .Where(j => j.Status == running && j.LeaseExpiresAt != null && j.LeaseExpiresAt < now)
            .ExecuteUpdateAsync(
                s => s
                    .SetProperty(j => j.Status, queued)
                    .SetProperty(j => j.ClaimedBy, (Guid?)null)
                    .SetProperty(j => j.ClaimedAt, (DateTimeOffset?)null)
                    .SetProperty(j => j.LeaseExpiresAt, (DateTimeOffset?)null),
                ct);

        if (requeued > 0)
        {
            _logger.LogWarning("Lease reaper requeued {Count} abandoned job(s)", requeued);
        }

        return requeued;
    }
}
