using Microsoft.EntityFrameworkCore;

namespace Cicd.Infrastructure.Persistence;

/// <summary>
/// EF Core context mapping the persistence entities to the snake_case Postgres schema
/// described in DESIGN section 9. Column/table names are configured explicitly.
/// </summary>
public sealed class CicdDbContext : DbContext
{
    public CicdDbContext(DbContextOptions<CicdDbContext> options) : base(options)
    {
    }

    public DbSet<PipelineEntity> Pipelines => Set<PipelineEntity>();
    public DbSet<RunEntity> Runs => Set<RunEntity>();
    public DbSet<JobEntity> Jobs => Set<JobEntity>();
    public DbSet<StepEntity> Steps => Set<StepEntity>();
    public DbSet<SecretEntity> Secrets => Set<SecretEntity>();
    public DbSet<ArtifactEntity> Artifacts => Set<ArtifactEntity>();
    public DbSet<CacheEntryEntity> CacheEntries => Set<CacheEntryEntity>();
    public DbSet<RepoBranchStateEntity> RepoBranchStates => Set<RepoBranchStateEntity>();
    public DbSet<ApiTokenEntity> ApiTokens => Set<ApiTokenEntity>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PipelineEntity>(e =>
        {
            e.ToTable("pipelines");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Name).HasColumnName("name");
            e.Property(x => x.RepoUrl).HasColumnName("repo_url");
            e.Property(x => x.RawYaml).HasColumnName("raw_yaml");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
        });

        modelBuilder.Entity<RunEntity>(e =>
        {
            e.ToTable("runs");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.PipelineId).HasColumnName("pipeline_id");
            e.Property(x => x.TriggerOn).HasColumnName("trigger_on");
            e.Property(x => x.Branch).HasColumnName("branch");
            e.Property(x => x.CommitSha).HasColumnName("commit_sha");
            e.Property(x => x.Inputs).HasColumnName("inputs").HasColumnType("jsonb");
            e.Property(x => x.Status).HasColumnName("status");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.StartedAt).HasColumnName("started_at");
            e.Property(x => x.FinishedAt).HasColumnName("finished_at");
            e.HasIndex(x => x.PipelineId);
        });

        modelBuilder.Entity<JobEntity>(e =>
        {
            e.ToTable("jobs");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.RunId).HasColumnName("run_id");
            e.Property(x => x.Name).HasColumnName("name");
            e.Property(x => x.Executor).HasColumnName("executor");
            e.Property(x => x.Image).HasColumnName("image");
            e.Property(x => x.Needs).HasColumnName("needs").HasColumnType("jsonb");
            e.Property(x => x.If).HasColumnName("if_expr");
            e.Property(x => x.Matrix).HasColumnName("matrix").HasColumnType("jsonb");
            e.Property(x => x.Status).HasColumnName("status");
            e.Property(x => x.Attempt).HasColumnName("attempt");
            e.Property(x => x.MaxRetries).HasColumnName("max_retries");
            e.Property(x => x.TimeoutSeconds).HasColumnName("timeout_seconds");
            e.Property(x => x.ClaimedBy).HasColumnName("claimed_by");
            e.Property(x => x.ClaimedAt).HasColumnName("claimed_at");
            e.Property(x => x.LeaseExpiresAt).HasColumnName("lease_expires_at");
            e.Property(x => x.LogSize).HasColumnName("log_size").HasDefaultValue(0L);
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.StartedAt).HasColumnName("started_at");
            e.Property(x => x.FinishedAt).HasColumnName("finished_at");
            e.HasIndex(x => x.Status);
            e.HasIndex(x => x.RunId);
        });

        modelBuilder.Entity<StepEntity>(e =>
        {
            e.ToTable("steps");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.JobId).HasColumnName("job_id");
            e.Property(x => x.Ordinal).HasColumnName("ordinal");
            e.Property(x => x.Name).HasColumnName("name");
            e.Property(x => x.Status).HasColumnName("status");
            e.Property(x => x.ExitCode).HasColumnName("exit_code");
            e.Property(x => x.StartedAt).HasColumnName("started_at");
            e.Property(x => x.FinishedAt).HasColumnName("finished_at");
            e.HasIndex(x => x.JobId);
        });

        modelBuilder.Entity<SecretEntity>(e =>
        {
            e.ToTable("secrets");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Name).HasColumnName("name");
            e.Property(x => x.Scope).HasColumnName("scope");
            e.Property(x => x.PipelineId).HasColumnName("pipeline_id");
            e.Property(x => x.Ciphertext).HasColumnName("ciphertext");
            e.Property(x => x.Nonce).HasColumnName("nonce");
            e.Property(x => x.Tag).HasColumnName("tag");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.HasIndex(x => new { x.Name, x.Scope, x.PipelineId }).IsUnique();
        });

        modelBuilder.Entity<ArtifactEntity>(e =>
        {
            e.ToTable("artifacts");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.RunId).HasColumnName("run_id");
            e.Property(x => x.JobId).HasColumnName("job_id");
            e.Property(x => x.Name).HasColumnName("name");
            e.Property(x => x.Path).HasColumnName("path");
            e.Property(x => x.SizeBytes).HasColumnName("size_bytes");
            e.Property(x => x.ExpiresAt).HasColumnName("expires_at");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.HasIndex(x => x.RunId);
            e.HasIndex(x => x.JobId);
        });

        modelBuilder.Entity<CacheEntryEntity>(e =>
        {
            e.ToTable("cache_entries");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Key).HasColumnName("key");
            e.Property(x => x.Path).HasColumnName("path");
            e.Property(x => x.SizeBytes).HasColumnName("size_bytes");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.LastUsedAt).HasColumnName("last_used_at");
            e.HasIndex(x => x.Key);
        });

        modelBuilder.Entity<RepoBranchStateEntity>(e =>
        {
            e.ToTable("repo_branch_state");
            e.HasKey(x => new { x.RepoUrl, x.Branch });
            e.Property(x => x.RepoUrl).HasColumnName("repo_url");
            e.Property(x => x.Branch).HasColumnName("branch");
            e.Property(x => x.LastSha).HasColumnName("last_sha");
        });

        modelBuilder.Entity<ApiTokenEntity>(e =>
        {
            e.ToTable("api_tokens");
            e.HasKey(x => x.Id);
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Name).HasColumnName("name");
            e.Property(x => x.TokenHash).HasColumnName("token_hash");
            e.Property(x => x.CreatedAt).HasColumnName("created_at");
            e.Property(x => x.LastUsedAt).HasColumnName("last_used_at");
            e.HasIndex(x => x.TokenHash).IsUnique();
        });
    }
}
