using System.Text;
using Cicd.Core.Definition;
using Cicd.Core.Definition.Expressions;
using Cicd.Core.Domain;
using Cicd.Core.Execution;
using Cicd.Core.Storage;
using Cicd.Infrastructure.DependencyInjection;
using Cicd.Infrastructure.Stores;
using Docker.DotNet;
using Docker.DotNet.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using JobStatus = Cicd.Core.Domain.JobStatus;
using StepStatus = Cicd.Core.Domain.StepStatus;

namespace Cicd.Infrastructure.Docker;

/// <summary>
/// The Docker executor. Materializes a per-job workspace volume, runs the job's steps sequentially
/// in containers sharing that volume, handles built-in <c>uses:</c> steps, restores/saves caches
/// and artifacts, and tears everything down. Implements <see cref="IJobExecutor"/> for the
/// <c>docker</c> executor type.
/// </summary>
public sealed class DockerJobExecutor : IJobExecutor
{
    private const string WorkspaceMount = "/workspace";

    private readonly DockerVolumeHelper _helper;
    private readonly ICacheStore _cacheStore;
    private readonly IArtifactStore _artifactStore;
    private readonly IArtifactRepository _artifactRepository;
    private readonly IStepRepository _stepRepository;
    private readonly FileSystemLogStore _logStore;
    private readonly IJobRepository _jobRepository;
    private readonly CicdOptions _options;
    private readonly ILogger<DockerJobExecutor> _logger;

    public DockerJobExecutor(
        DockerVolumeHelper helper,
        ICacheStore cacheStore,
        IArtifactStore artifactStore,
        IArtifactRepository artifactRepository,
        IStepRepository stepRepository,
        FileSystemLogStore logStore,
        IJobRepository jobRepository,
        IOptions<CicdOptions> options,
        ILogger<DockerJobExecutor> logger)
    {
        _helper = helper;
        _cacheStore = cacheStore;
        _artifactStore = artifactStore;
        _artifactRepository = artifactRepository;
        _stepRepository = stepRepository;
        _logStore = logStore;
        _jobRepository = jobRepository;
        _options = options.Value;
        _logger = logger;
    }

    public string Type => "docker";

    public async Task<JobResult> ExecuteAsync(JobExecutionContext context, CancellationToken ct)
    {
        var volumeName = $"cicd-ws-{context.JobId.Value.ToString("N")[..12]}";

        var labels = new Dictionary<string, string>
        {
            ["cicd.run"] = context.RunId.Value.ToString(),
            ["cicd.job"] = context.JobId.Value.ToString()
        };

        _logStore.Register(context.JobId, context.RunId);
        await using var writer = _logStore.CreateWriter(context.JobId, context.SecretValues.Values);
        var stepRecords = await _stepRepository.ListByJobAsync(context.JobId, ct);
        var stepResults = new List<StepResult>();
        var failed = false;
        string? failureReason = null;

        try
        {
            await _helper.Client.Volumes.CreateAsync(new VolumesCreateParameters { Name = volumeName, Labels = labels }, ct);

            await MaterializeWorkspaceAsync(context, volumeName, labels, writer, ct);
            await RestoreCachesAsync(context, volumeName, labels, writer, ct);
            await RestoreNeedsArtifactsAsync(context, volumeName, labels, writer, ct);

            var ordinal = 0;
            foreach (var step in context.Steps)
            {
                // Step records are persisted with a 0-based ordinal; display uses 1-based numbering.
                var stepRecord = stepRecords.FirstOrDefault(s => s.Ordinal == ordinal);
                ordinal++;
                var result = await RunStepAsync(context, step, ordinal, stepRecord, volumeName, labels, writer, ct);
                stepResults.Add(result);

                if (result.Status == StepStatus.Failed)
                {
                    failed = true;
                    failureReason = $"Step {ordinal} ('{result.Name}') failed with exit code {result.ExitCode}.";
                    break;
                }
            }

            if (!failed)
            {
                await SaveCachesAsync(context, volumeName, labels, writer, ct);
                await UploadDeclaredArtifactsAsync(context, volumeName, labels, writer, ct);
            }
        }
        catch (OperationCanceledException)
        {
            failed = true;
            failureReason = "Job was canceled.";
            await TeardownAsync(volumeName, removeVolume: true, ct: CancellationToken.None);
            await PersistLogSizeAsync(context.JobId, writer.Offset);
            return new JobResult(JobStatus.Canceled, failureReason, stepResults);
        }
        catch (Exception ex)
        {
            failed = true;
            failureReason = ex.Message;
            _logger.LogError(ex, "Docker job {JobId} failed unexpectedly", context.JobId);
            await SafeWriteAsync(writer, $"\n[executor] job failed: {ex.Message}\n");
        }

        var retainVolume = failed && _options.RetainWorkspaceOnFailure;
        await TeardownAsync(volumeName, removeVolume: !retainVolume, ct: CancellationToken.None);
        await PersistLogSizeAsync(context.JobId, writer.Offset);

        var status = failed ? JobStatus.Failed : JobStatus.Succeeded;
        return new JobResult(status, failureReason, stepResults);
    }

    private async Task<StepResult> RunStepAsync(
        JobExecutionContext context,
        StepDefinition step,
        int ordinal,
        StepRecord? stepRecord,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        var stepName = step.Name ?? step.Uses ?? $"step-{ordinal}";

        if (step.If is not null && !ExpressionEvaluator.EvaluateBool(step.If, context.ExpressionContext))
        {
            await writer.WriteAsync($"\n=== Step {ordinal}: {stepName} (skipped) ===\n", ct);
            await SetStepStatusAsync(stepRecord, StepStatus.Skipped, null, ct);
            return new StepResult(ordinal, stepName, StepStatus.Skipped, null);
        }

        await writer.WriteAsync($"\n=== Step {ordinal}: {stepName} ===\n", ct);
        await SetStepStatusAsync(stepRecord, StepStatus.Running, null, ct, setStarted: true);

        try
        {
            int exitCode;
            if (step.Uses is not null)
            {
                exitCode = await RunBuiltInStepAsync(context, step, volumeName, labels, writer, ct);
            }
            else
            {
                exitCode = await RunShellStepAsync(context, step, volumeName, labels, writer, ct);
            }

            var status = exitCode == 0 ? StepStatus.Succeeded : StepStatus.Failed;
            await SetStepStatusAsync(stepRecord, status, exitCode, ct, setFinished: true);
            return new StepResult(ordinal, stepName, status, exitCode);
        }
        catch (OperationCanceledException)
        {
            await SetStepStatusAsync(stepRecord, StepStatus.Failed, null, ct: CancellationToken.None, setFinished: true);
            throw;
        }
        catch (Exception ex)
        {
            await writer.WriteAsync($"[executor] step error: {ex.Message}\n", CancellationToken.None);
            await SetStepStatusAsync(stepRecord, StepStatus.Failed, null, ct: CancellationToken.None, setFinished: true);
            return new StepResult(ordinal, stepName, StepStatus.Failed, null);
        }
    }

    private async Task<int> RunShellStepAsync(
        JobExecutionContext context,
        StepDefinition step,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        var expr = context.ExpressionContext;
        var image = ExpressionEvaluator.Interpolate(step.Image ?? context.Image
            ?? throw new InvalidOperationException("No image available for shell step."), expr);
        var script = ExpressionEvaluator.Interpolate(step.Run ?? string.Empty, expr);
        var workdir = step.Workdir is null ? WorkspaceMount : ExpressionEvaluator.Interpolate(step.Workdir, expr);

        var env = BuildStepEnv(context, step);

        return await RunContainerAsync(image, script, env, workdir, volumeName, labels, writer, ct);
    }

    private async Task<int> RunBuiltInStepAsync(
        JobExecutionContext context,
        StepDefinition step,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        var expr = context.ExpressionContext;
        var with = step.With.ToDictionary(
            kv => kv.Key,
            kv => ExpressionEvaluator.Interpolate(kv.Value, expr),
            StringComparer.Ordinal);

        switch (step.Uses)
        {
            case BuiltInSteps.Checkout:
                await CheckoutAsync(context, volumeName, labels, writer, with, ct);
                return 0;

            case BuiltInSteps.CacheRestore:
                await CacheRestoreStepAsync(volumeName, labels, writer, with, ct);
                return 0;

            case BuiltInSteps.CacheSave:
                await CacheSaveStepAsync(volumeName, labels, writer, with, ct);
                return 0;

            case BuiltInSteps.ArtifactUpload:
                await ArtifactUploadStepAsync(context, volumeName, labels, writer, with, ct);
                return 0;

            case BuiltInSteps.ArtifactDownload:
                await ArtifactDownloadStepAsync(context, volumeName, labels, writer, with, ct);
                return 0;

            case BuiltInSteps.NugetAuth:
                return await WriteFileStepAsync(context, step, volumeName, labels, writer, BuildNugetConfig(with), "NuGet.Config", ct);

            case BuiltInSteps.NpmAuth:
                return await WriteFileStepAsync(context, step, volumeName, labels, writer, BuildNpmrc(with), ".npmrc", ct);

            default:
                await writer.WriteAsync($"[executor] unknown built-in step '{step.Uses}'.\n", ct);
                return 1;
        }
    }

    private async Task<int> RunContainerAsync(
        string image,
        string script,
        IReadOnlyDictionary<string, string> env,
        string workingDir,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        await _helper.EnsureImageAsync(image, ct);

        var create = await _helper.Client.Containers.CreateContainerAsync(
            new CreateContainerParameters
            {
                Image = image,
                Cmd = ["/bin/sh", "-lc", script],
                WorkingDir = workingDir,
                Env = env.Select(kv => $"{kv.Key}={kv.Value}").ToList(),
                Labels = labels,
                AttachStdout = true,
                AttachStderr = true,
                HostConfig = new HostConfig
                {
                    Mounts =
                    [
                        new Mount { Type = "volume", Source = volumeName, Target = WorkspaceMount }
                    ]
                }
            },
            ct);

        var containerId = create.ID;

        try
        {
            await _helper.Client.Containers.StartContainerAsync(containerId, new ContainerStartParameters(), ct);

            // Attach after start: the daemon replays retained history, so nothing is missed.
            // Attaching to a created-but-not-started container yields an immediate EOF instead.
            using var logs = await _helper.Client.Containers.GetContainerLogsAsync(
                containerId,
                tty: false,
                new ContainerLogsParameters { ShowStdout = true, ShowStderr = true, Follow = true },
                ct);

            await StreamLogsAsync(logs, writer, ct);

            var wait = await _helper.Client.Containers.WaitContainerAsync(containerId, ct);
            return (int)wait.StatusCode;
        }
        catch (OperationCanceledException)
        {
            await KillAsync(containerId);
            throw;
        }
        finally
        {
            await SafeRemoveContainerAsync(containerId);
        }
    }

    private async Task StreamLogsAsync(MultiplexedStream logs, JobLogWriter writer, CancellationToken ct)
    {
        var buffer = new byte[8192];
        while (true)
        {
            var read = await logs.ReadOutputAsync(buffer, 0, buffer.Length, ct);
            if (read.EOF || read.Count == 0)
            {
                break;
            }

            await writer.WriteAsync(Encoding.UTF8.GetString(buffer, 0, read.Count), ct);
        }
    }

    private async Task MaterializeWorkspaceAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        switch (context.WorkspaceSource)
        {
            case GitSource git:
                await CheckoutGitAsync(git.RepoUrl, git.Sha, volumeName, labels, writer, ct);
                break;

            case LocalDirSource local:
                await CopyLocalDirAsync(local.Path, volumeName, labels, writer, ct);
                break;

            case EmptySource:
                // Nothing to materialize — the fresh volume is the workspace.
                break;

            default:
                throw new InvalidOperationException($"Unsupported workspace source '{context.WorkspaceSource.GetType().Name}'.");
        }
    }

    private async Task CheckoutGitAsync(
        string repoUrl,
        string sha,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        await writer.WriteAsync($"\n=== Checkout {repoUrl} @ {sha} ===\n", ct);

        var script =
            "set -e; " +
            $"git init -q {WorkspaceMount}; cd {WorkspaceMount}; " +
            $"git remote add origin \"$REPO_URL\" 2>/dev/null || git remote set-url origin \"$REPO_URL\"; " +
            "git fetch --depth 50 origin \"$SHA\"; " +
            "git checkout -q \"$SHA\"";

        var result = await _helper.RunAsync(
            _options.GitImage,
            script,
            [new HelperMount(volumeName, WorkspaceMount, ReadOnly: false, IsVolume: true)],
            new Dictionary<string, string> { ["REPO_URL"] = repoUrl, ["SHA"] = sha },
            WorkspaceMount,
            labels,
            ct);

        await writer.WriteAsync(result.Output, ct);
        if (!result.Success)
        {
            throw new InvalidOperationException($"git checkout failed (exit {result.ExitCode}).");
        }
    }

    private async Task CopyLocalDirAsync(
        string localPath,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        await writer.WriteAsync($"\n=== Copy local dir {localPath} ===\n", ct);

        // Bind the source read-only at /src, copy its contents into the workspace volume.
        var result = await _helper.RunAsync(
            _options.DefaultHelperImage,
            $"set -e; cp -a /src/. {WorkspaceMount}/",
            [
                new HelperMount(localPath, "/src", ReadOnly: true, IsVolume: false),
                new HelperMount(volumeName, WorkspaceMount, ReadOnly: false, IsVolume: true)
            ],
            null,
            WorkspaceMount,
            labels,
            ct);

        await writer.WriteAsync(result.Output, ct);
        if (!result.Success)
        {
            throw new InvalidOperationException($"local dir copy failed (exit {result.ExitCode}).");
        }
    }

    private async Task CheckoutAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        IReadOnlyDictionary<string, string> with,
        CancellationToken ct)
    {
        // For git pipelines the workspace was already checked out during materialization.
        // An explicit `checkout` with a `ref` override re-checks-out that ref.
        if (context.WorkspaceSource is GitSource git)
        {
            var reference = with.TryGetValue("ref", out var r) && !string.IsNullOrWhiteSpace(r) ? r : git.Sha;
            await CheckoutGitAsync(git.RepoUrl, reference, volumeName, labels, writer, ct);
        }
        else
        {
            await writer.WriteAsync("[executor] checkout: no git source; workspace already populated.\n", ct);
        }
    }

    private async Task RestoreCachesAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        foreach (var cache in context.Caches)
        {
            var key = ExpressionEvaluator.Interpolate(cache.Key, context.ExpressionContext);
            await RestoreCacheAsync(key, cache.RestoreKeys, cache.Paths, volumeName, labels, writer, ct);
        }
    }

    private async Task SaveCachesAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        foreach (var cache in context.Caches)
        {
            var key = ExpressionEvaluator.Interpolate(cache.Key, context.ExpressionContext);
            await SaveCacheAsync(key, cache.Paths, volumeName, labels, writer, ct);
        }
    }

    private async Task CacheRestoreStepAsync(
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        IReadOnlyDictionary<string, string> with,
        CancellationToken ct)
    {
        var key = with.GetValueOrDefault("key", string.Empty);
        var restoreKeys = SplitList(with.GetValueOrDefault("restoreKeys"));
        var paths = SplitList(with.GetValueOrDefault("paths"));
        await RestoreCacheAsync(key, restoreKeys, paths, volumeName, labels, writer, ct);
    }

    private async Task CacheSaveStepAsync(
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        IReadOnlyDictionary<string, string> with,
        CancellationToken ct)
    {
        var key = with.GetValueOrDefault("key", string.Empty);
        var paths = SplitList(with.GetValueOrDefault("paths"));
        await SaveCacheAsync(key, paths, volumeName, labels, writer, ct);
    }

    private async Task RestoreCacheAsync(
        string key,
        IReadOnlyList<string> restoreKeys,
        IReadOnlyList<string> paths,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            return;
        }

        var staging = CreateStagingFile("cache-restore", ".tar.gz");
        try
        {
            bool hit;
            await using (var dest = new FileStream(staging.HostPath, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                hit = await _cacheStore.RestoreAsync(key, restoreKeys, dest, ct);
            }

            if (!hit)
            {
                await writer.WriteAsync($"[cache] miss for key '{key}'.\n", ct);
                return;
            }

            await writer.WriteAsync($"[cache] restoring key '{key}'.\n", ct);
            var result = await _helper.RunAsync(
                _options.DefaultHelperImage,
                $"set -e; tar -xzf /staging/{staging.FileName} -C {WorkspaceMount}",
                [
                    new HelperMount(volumeName, WorkspaceMount, ReadOnly: false, IsVolume: true),
                    new HelperMount(staging.HostDir, "/staging", ReadOnly: true, IsVolume: false)
                ],
                null,
                WorkspaceMount,
                labels,
                ct);

            await writer.WriteAsync(result.Output, ct);
        }
        finally
        {
            DeleteStaging(staging);
        }
    }

    private async Task SaveCacheAsync(
        string key,
        IReadOnlyList<string> paths,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(key) || paths.Count == 0)
        {
            return;
        }

        var staging = CreateStagingFile("cache-save", ".tar.gz");
        try
        {
            var targets = string.Join(' ', paths.Select(GlobForShell));
            var result = await _helper.RunAsync(
                _options.DefaultHelperImage,
                $"set -e; tar -czf /staging/{staging.FileName} {targets}",
                [
                    new HelperMount(volumeName, WorkspaceMount, ReadOnly: false, IsVolume: true),
                    new HelperMount(staging.HostDir, "/staging", ReadOnly: false, IsVolume: false)
                ],
                null,
                WorkspaceMount,
                labels,
                ct);

            await writer.WriteAsync(result.Output, ct);
            if (!result.Success || !File.Exists(staging.HostPath))
            {
                await writer.WriteAsync($"[cache] save failed for key '{key}'.\n", ct);
                return;
            }

            await using var src = new FileStream(staging.HostPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            await _cacheStore.SaveAsync(key, src, ct);
            await writer.WriteAsync($"[cache] saved key '{key}'.\n", ct);
        }
        finally
        {
            DeleteStaging(staging);
        }
    }

    private async Task RestoreNeedsArtifactsAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        if (context.Needs.Count == 0)
        {
            return;
        }

        var needsSet = context.Needs.ToHashSet(StringComparer.Ordinal);

        // Map run jobs to their base names so we only restore artifacts produced by needed jobs.
        var runJobs = await _jobRepository.ListByRunAsync(context.RunId, ct);
        var neededJobIds = runJobs
            .Where(j => needsSet.Contains(BaseName(j.Name)))
            .Select(j => j.Id.Value)
            .ToHashSet();

        var runArtifacts = await _artifactRepository.ListByRunAsync(context.RunId, ct);
        foreach (var artifact in runArtifacts.Where(a => neededJobIds.Contains(a.JobId.Value)))
        {
            await RestoreArtifactArchiveAsync(artifact.Path, volumeName, labels, writer, ct);
        }
    }

    private async Task ArtifactDownloadStepAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        IReadOnlyDictionary<string, string> with,
        CancellationToken ct)
    {
        var name = with.GetValueOrDefault("name", string.Empty);
        var runArtifacts = await _artifactRepository.ListByRunAsync(context.RunId, ct);
        var matches = runArtifacts.Where(a => string.Equals(a.Name, name, StringComparison.Ordinal)).ToList();

        if (matches.Count == 0)
        {
            await writer.WriteAsync($"[artifact] no artifact named '{name}' found in run.\n", ct);
            return;
        }

        foreach (var artifact in matches)
        {
            await RestoreArtifactArchiveAsync(artifact.Path, volumeName, labels, writer, ct);
        }
    }

    private async Task RestoreArtifactArchiveAsync(
        string artifactPath,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        var staging = CreateStagingFile("artifact-restore", ".tar.gz");
        try
        {
            await using (var dest = new FileStream(staging.HostPath, FileMode.Create, FileAccess.Write, FileShare.None))
            await using (var src = _artifactStore.OpenRead(artifactPath))
            {
                await src.CopyToAsync(dest, ct);
            }

            var result = await _helper.RunAsync(
                _options.DefaultHelperImage,
                $"set -e; tar -xzf /staging/{staging.FileName} -C {WorkspaceMount}",
                [
                    new HelperMount(volumeName, WorkspaceMount, ReadOnly: false, IsVolume: true),
                    new HelperMount(staging.HostDir, "/staging", ReadOnly: true, IsVolume: false)
                ],
                null,
                WorkspaceMount,
                labels,
                ct);

            await writer.WriteAsync(result.Output, ct);
        }
        finally
        {
            DeleteStaging(staging);
        }
    }

    private async Task UploadDeclaredArtifactsAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        if (context.Artifacts is null || context.Artifacts.Paths.Count == 0)
        {
            return;
        }

        var expire = context.Artifacts.Expire;
        await UploadArtifactAsync(context, context.JobName, context.Artifacts.Paths, expire, volumeName, labels, writer, ct);
    }

    private async Task ArtifactUploadStepAsync(
        JobExecutionContext context,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        IReadOnlyDictionary<string, string> with,
        CancellationToken ct)
    {
        var name = with.GetValueOrDefault("name", context.JobName);
        var paths = SplitList(with.GetValueOrDefault("paths"));
        TimeSpan? expire = null;
        if (with.TryGetValue("expire", out var expireText) &&
            DurationParser.TryParse(expireText, out var parsed, out _))
        {
            expire = parsed;
        }

        await UploadArtifactAsync(context, name, paths, expire, volumeName, labels, writer, ct);
    }

    private async Task UploadArtifactAsync(
        JobExecutionContext context,
        string name,
        IReadOnlyList<string> paths,
        TimeSpan? expire,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        CancellationToken ct)
    {
        if (paths.Count == 0)
        {
            return;
        }

        var staging = CreateStagingFile("artifact-upload", ".tar.gz");
        try
        {
            var targets = string.Join(' ', paths.Select(GlobForShell));
            var result = await _helper.RunAsync(
                _options.DefaultHelperImage,
                $"set -e; tar -czf /staging/{staging.FileName} {targets}",
                [
                    new HelperMount(volumeName, WorkspaceMount, ReadOnly: false, IsVolume: true),
                    new HelperMount(staging.HostDir, "/staging", ReadOnly: false, IsVolume: false)
                ],
                null,
                WorkspaceMount,
                labels,
                ct);

            await writer.WriteAsync(result.Output, ct);
            if (!result.Success || !File.Exists(staging.HostPath))
            {
                await writer.WriteAsync($"[artifact] upload failed for '{name}'.\n", ct);
                return;
            }

            (string Path, long SizeBytes) saved;
            await using (var src = new FileStream(staging.HostPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                saved = await _artifactStore.SaveAsync(
                    context.RunId.Value.ToString(),
                    context.JobId.Value.ToString(),
                    name,
                    src,
                    ct);
            }

            await _artifactRepository.CreateAsync(
                new ArtifactRecord
                {
                    Id = ArtifactId.New(),
                    RunId = context.RunId,
                    JobId = context.JobId,
                    Name = name,
                    Path = saved.Path,
                    SizeBytes = saved.SizeBytes,
                    ExpiresAt = expire is null ? null : DateTimeOffset.UtcNow.Add(expire.Value),
                    CreatedAt = DateTimeOffset.UtcNow
                },
                ct);

            await writer.WriteAsync($"[artifact] uploaded '{name}' ({saved.SizeBytes} bytes).\n", ct);
        }
        finally
        {
            DeleteStaging(staging);
        }
    }

    private async Task<int> WriteFileStepAsync(
        JobExecutionContext context,
        StepDefinition step,
        string volumeName,
        IDictionary<string, string> labels,
        JobLogWriter writer,
        string content,
        string fileName,
        CancellationToken ct)
    {
        var image = context.Image ?? _options.DefaultHelperImage;
        var encoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(content));
        var script = $"set -e; echo \"$CICD_FILE_B64\" | base64 -d > {WorkspaceMount}/{fileName}";
        var env = BuildStepEnv(context, step);
        env["CICD_FILE_B64"] = encoded;

        await writer.WriteAsync($"[executor] writing {fileName}.\n", ct);
        return await RunContainerAsync(image, script, env, WorkspaceMount, volumeName, labels, writer, ct);
    }

    private Dictionary<string, string> BuildStepEnv(JobExecutionContext context, StepDefinition step)
    {
        var env = new Dictionary<string, string>(context.Env, StringComparer.Ordinal);
        foreach (var (key, value) in step.Env)
        {
            env[key] = ExpressionEvaluator.Interpolate(value, context.ExpressionContext);
        }

        return env;
    }

    private async Task SetStepStatusAsync(
        StepRecord? stepRecord,
        StepStatus status,
        int? exitCode,
        CancellationToken ct,
        bool setStarted = false,
        bool setFinished = false)
    {
        if (stepRecord is null)
        {
            return;
        }

        var now = DateTimeOffset.UtcNow;
        await _stepRepository.UpdateStatusAsync(
            stepRecord.Id,
            status,
            exitCode,
            setStarted ? now : null,
            setFinished ? now : null,
            ct);
    }

    private async Task PersistLogSizeAsync(JobId jobId, long offset)
    {
        try
        {
            await _jobRepository.UpdateLogSizeAsync(jobId, offset, CancellationToken.None);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to persist log size for job {JobId}", jobId);
        }
    }

    private async Task TeardownAsync(string volumeName, bool removeVolume, CancellationToken ct)
    {
        try
        {
            if (removeVolume)
            {
                await _helper.Client.Volumes.RemoveAsync(volumeName, force: true, ct);
            }
        }
        catch (DockerApiException ex)
        {
            _logger.LogWarning(ex, "Teardown failed for volume {Volume}", volumeName);
        }
    }

    private async Task KillAsync(string containerId)
    {
        try
        {
            await _helper.Client.Containers.KillContainerAsync(containerId, new ContainerKillParameters(), CancellationToken.None);
        }
        catch (DockerApiException)
        {
            // Already stopped.
        }
    }

    private async Task SafeRemoveContainerAsync(string containerId)
    {
        try
        {
            await _helper.Client.Containers.RemoveContainerAsync(
                containerId,
                new ContainerRemoveParameters { Force = true },
                CancellationToken.None);
        }
        catch (DockerApiException)
        {
            // Already removed.
        }
    }

    private static async Task SafeWriteAsync(JobLogWriter writer, string text)
    {
        try
        {
            await writer.WriteAsync(text, CancellationToken.None);
        }
        catch
        {
            // Best-effort logging.
        }
    }

    private static string BuildNugetConfig(IReadOnlyDictionary<string, string> with)
    {
        var feedUrl = with.GetValueOrDefault("feedUrl", string.Empty);
        var username = with.GetValueOrDefault("username", "user");
        var password = with.GetValueOrDefault("password", string.Empty);

        return
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
            "<configuration><packageSources>\n" +
            $"  <add key=\"Private\" value=\"{feedUrl}\"/>\n" +
            "</packageSources><packageSourceCredentials><Private>\n" +
            $"  <add key=\"Username\" value=\"{username}\"/>\n" +
            $"  <add key=\"ClearTextPassword\" value=\"{password}\"/>\n" +
            "</Private></packageSourceCredentials></configuration>\n";
    }

    private static string BuildNpmrc(IReadOnlyDictionary<string, string> with)
    {
        var registry = with.GetValueOrDefault("registry", string.Empty);
        var token = with.GetValueOrDefault("token", string.Empty);
        var host = registry.Replace("https:", string.Empty).Replace("http:", string.Empty);

        return
            $"registry={registry}\n" +
            $"{host}:_authToken={token}\n";
    }

    private static IReadOnlyList<string> SplitList(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return [];
        }

        var trimmed = value.Trim().Trim('[', ']');
        return trimmed
            .Split([',', '\n'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(item => item.Trim('"', '\''))
            .Where(item => item.Length > 0)
            .ToList();
    }

    private static string QuoteForShell(string path)
    {
        return "'" + path.Replace("'", "'\\''") + "'";
    }

    private static string GlobForShell(string path)
    {
        // Cache/artifact paths are globs by design — they must stay unquoted so the container
        // shell expands them. Escape only whitespace and quote characters.
        return path
            .Replace("\\", "\\\\")
            .Replace(" ", "\\ ")
            .Replace("'", "\\'")
            .Replace("\"", "\\\"");
    }

    private static string BaseName(string jobName)
    {
        var index = jobName.IndexOf(" (", StringComparison.Ordinal);
        return index < 0 ? jobName : jobName[..index];
    }

    private StagingFile CreateStagingFile(string prefix, string extension)
    {
        var hostDir = Path.Combine(_options.EffectiveCacheRoot, "staging");
        Directory.CreateDirectory(hostDir);
        var fileName = $"{prefix}-{Guid.NewGuid():N}{extension}";

        // The path the Docker daemon sees may differ from the server's view.
        var daemonDir = Path.Combine(_options.HostCacheRoot, "staging");
        return new StagingFile(
            HostPath: Path.Combine(hostDir, fileName),
            HostDir: daemonDir,
            FileName: fileName);
    }

    private static void DeleteStaging(StagingFile staging)
    {
        try
        {
            if (File.Exists(staging.HostPath))
            {
                File.Delete(staging.HostPath);
            }
        }
        catch
        {
            // Best-effort cleanup.
        }
    }

    private sealed record StagingFile(string HostPath, string HostDir, string FileName);
}
