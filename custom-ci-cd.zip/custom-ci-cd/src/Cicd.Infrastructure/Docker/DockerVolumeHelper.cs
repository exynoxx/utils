using System.Text;
using Docker.DotNet;
using Docker.DotNet.Models;

namespace Cicd.Infrastructure.Docker;

/// <summary>A mount for a helper container: either a named volume or a host bind path.</summary>
public sealed record HelperMount(string Source, string Target, bool ReadOnly, bool IsVolume);

/// <summary>The captured output of a helper container run.</summary>
public sealed record HelperResult(long ExitCode, string Output)
{
    public bool Success => ExitCode == 0;
}

/// <summary>
/// Encapsulates the recurring "run a short-lived helper container with some mounts and a shell
/// script, wait for it, capture output" pattern used by checkout, cache, artifacts and local-dir
/// copy. Centralizes image pulling and container teardown.
/// </summary>
public sealed class DockerVolumeHelper
{
    private readonly DockerClient _client;

    public DockerVolumeHelper(DockerClient client)
    {
        _client = client;
    }

    public DockerClient Client => _client;

    /// <summary>Pulls <paramref name="image"/> if it is not already present locally.</summary>
    public async Task EnsureImageAsync(string image, CancellationToken ct)
    {
        var (repo, tag) = SplitImage(image);

        var existing = await _client.Images.ListImagesAsync(
            new ImagesListParameters { All = true },
            ct);

        var present = existing.Any(i =>
            i.RepoTags is not null &&
            i.RepoTags.Any(t => string.Equals(t, $"{repo}:{tag}", StringComparison.Ordinal)));

        if (present)
        {
            return;
        }

        await _client.Images.CreateImageAsync(
            new ImagesCreateParameters { FromImage = repo, Tag = tag },
            authConfig: null,
            new Progress<JSONMessage>(),
            ct);
    }

    /// <summary>
    /// Runs a one-shot helper container executing <paramref name="script"/> via <c>/bin/sh -c</c>
    /// with the supplied mounts, waits for exit, and returns the combined stdout/stderr.
    /// </summary>
    public async Task<HelperResult> RunAsync(
        string image,
        string script,
        IReadOnlyList<HelperMount> mounts,
        IReadOnlyDictionary<string, string>? env,
        string workingDir,
        IDictionary<string, string>? labels,
        CancellationToken ct)
    {
        await EnsureImageAsync(image, ct);

        var dockerMounts = mounts
            .Select(m => new Mount
            {
                Type = m.IsVolume ? "volume" : "bind",
                Source = m.Source,
                Target = m.Target,
                ReadOnly = m.ReadOnly
            })
            .ToList();

        var create = await _client.Containers.CreateContainerAsync(
            new CreateContainerParameters
            {
                Image = image,
                Cmd = ["/bin/sh", "-c", script],
                WorkingDir = workingDir,
                Env = env?.Select(kv => $"{kv.Key}={kv.Value}").ToList() ?? [],
                Labels = labels,
                AttachStdout = true,
                AttachStderr = true,
                HostConfig = new HostConfig { Mounts = dockerMounts }
            },
            ct);

        var containerId = create.ID;
        try
        {
            await _client.Containers.StartContainerAsync(containerId, new ContainerStartParameters(), ct);

            // Attach after start: attaching to a created-but-not-started container yields an
            // immediate EOF; the daemon replays retained history so nothing is missed.
            using var logs = await _client.Containers.GetContainerLogsAsync(
                containerId,
                tty: false,
                new ContainerLogsParameters { ShowStdout = true, ShowStderr = true, Follow = true },
                ct);

            var output = await ReadMultiplexedToStringAsync(logs, ct);
            var wait = await _client.Containers.WaitContainerAsync(containerId, ct);
            return new HelperResult(wait.StatusCode, output);
        }
        finally
        {
            await SafeRemoveAsync(containerId);
        }
    }

    private async Task SafeRemoveAsync(string containerId)
    {
        try
        {
            await _client.Containers.RemoveContainerAsync(
                containerId,
                new ContainerRemoveParameters { Force = true, RemoveVolumes = false },
                CancellationToken.None);
        }
        catch (DockerApiException)
        {
            // Already gone.
        }
    }

    internal static async Task<string> ReadMultiplexedToStringAsync(MultiplexedStream stream, CancellationToken ct)
    {
        var builder = new StringBuilder();
        var buffer = new byte[8192];

        while (true)
        {
            var read = await stream.ReadOutputAsync(buffer, 0, buffer.Length, ct);
            if (read.EOF || read.Count == 0)
            {
                break;
            }

            builder.Append(Encoding.UTF8.GetString(buffer, 0, read.Count));
        }

        return builder.ToString();
    }

    internal static (string Repo, string Tag) SplitImage(string image)
    {
        // Account for registry host ports (host:5000/repo:tag) by only splitting on the last colon
        // that follows the final path segment.
        var lastSlash = image.LastIndexOf('/');
        var lastColon = image.LastIndexOf(':');
        if (lastColon > lastSlash && lastColon >= 0)
        {
            return (image[..lastColon], image[(lastColon + 1)..]);
        }

        return (image, "latest");
    }
}
