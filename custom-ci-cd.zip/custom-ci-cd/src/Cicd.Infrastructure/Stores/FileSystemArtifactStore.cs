using Cicd.Core.Storage;

namespace Cicd.Infrastructure.Stores;

/// <summary>
/// Filesystem artifact store. Archives are stored at
/// <c>&lt;artifactRoot&gt;/&lt;runId&gt;/&lt;jobId&gt;/&lt;name&gt;.tar.gz</c>.
///
/// <para>
/// The Core <see cref="IArtifactStore"/> contract is stream-based and does not take the artifact
/// repository, so this store only persists the archive bytes and returns the storage path + size.
/// The caller (executor) writes the <see cref="ArtifactRecord"/> row via
/// <see cref="IArtifactRepository"/> using the returned path.
/// </para>
/// </summary>
public sealed class FileSystemArtifactStore : IArtifactStore
{
    private readonly string _artifactRoot;

    public FileSystemArtifactStore(string artifactRoot)
    {
        _artifactRoot = artifactRoot;
        Directory.CreateDirectory(_artifactRoot);
    }

    public async Task<(string Path, long SizeBytes)> SaveAsync(
        string runId,
        string jobId,
        string name,
        Stream content,
        CancellationToken ct)
    {
        var directory = Path.Combine(_artifactRoot, runId, jobId);
        Directory.CreateDirectory(directory);

        var path = Path.Combine(directory, SanitizeName(name) + ".tar.gz");

        long size;
        await using (var file = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
        {
            await content.CopyToAsync(file, ct);
            size = file.Length;
        }

        return (path, size);
    }

    public Stream OpenRead(string path)
    {
        return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
    }

    public Task DeleteAsync(string path, CancellationToken ct)
    {
        if (File.Exists(path))
        {
            File.Delete(path);
        }

        return Task.CompletedTask;
    }

    private static string SanitizeName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var sanitized = new string(name.Select(c => invalid.Contains(c) ? '_' : c).ToArray());
        return string.IsNullOrWhiteSpace(sanitized) ? "artifact" : sanitized;
    }
}
