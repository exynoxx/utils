using System.Security.Cryptography;
using System.Text;
using Cicd.Core.Storage;

namespace Cicd.Infrastructure.Stores;

/// <summary>
/// Filesystem cache store. Archives are stored at <c>&lt;cacheRoot&gt;/&lt;sha256(key)&gt;.tar.gz</c>
/// with a sidecar <c>.key</c> file recording the original key for restore-key prefix matching.
/// Restore tries the exact key first, then scans sidecars for a key that starts with one of the
/// restore-key prefixes, newest mtime winning.
///
/// <para>
/// The Core <see cref="ICacheStore"/> contract is stream-based: the executor produces the tar
/// stream (from the workspace volume, via a helper container) and hands it here, and reads the
/// archive back out for extraction. This store therefore only persists/retrieves opaque archive
/// bytes keyed by string — it does not touch Docker volumes itself.
/// </para>
/// </summary>
public sealed class FileSystemCacheStore : ICacheStore
{
    private readonly string _cacheRoot;

    public FileSystemCacheStore(string cacheRoot)
    {
        _cacheRoot = cacheRoot;
        Directory.CreateDirectory(_cacheRoot);
    }

    public async Task<bool> RestoreAsync(
        string key,
        IReadOnlyList<string> restoreKeys,
        Stream destination,
        CancellationToken ct)
    {
        var exact = ArchivePath(key);
        if (File.Exists(exact))
        {
            await CopyToAsync(exact, destination, ct);
            return true;
        }

        var match = FindByPrefix(restoreKeys);
        if (match is null)
        {
            return false;
        }

        await CopyToAsync(match, destination, ct);
        return true;
    }

    public async Task SaveAsync(string key, Stream content, CancellationToken ct)
    {
        var archivePath = ArchivePath(key);
        Directory.CreateDirectory(_cacheRoot);

        await using (var file = new FileStream(archivePath, FileMode.Create, FileAccess.Write, FileShare.None))
        {
            await content.CopyToAsync(file, ct);
        }

        await File.WriteAllTextAsync(SidecarPath(key), key, ct);
    }

    private string? FindByPrefix(IReadOnlyList<string> restoreKeys)
    {
        if (restoreKeys.Count == 0)
        {
            return null;
        }

        var candidates = Directory
            .EnumerateFiles(_cacheRoot, "*.key")
            .Select(sidecar => (Sidecar: sidecar, Key: File.ReadAllText(sidecar)))
            .Where(c => restoreKeys.Any(prefix => c.Key.StartsWith(prefix, StringComparison.Ordinal)))
            .Select(c => Path.ChangeExtension(c.Sidecar, ".tar.gz"))
            .Where(File.Exists)
            .OrderByDescending(path => new FileInfo(path).LastWriteTimeUtc)
            .ToList();

        return candidates.FirstOrDefault();
    }

    private static async Task CopyToAsync(string path, Stream destination, CancellationToken ct)
    {
        await using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        await file.CopyToAsync(destination, ct);
    }

    private string ArchivePath(string key)
    {
        return Path.Combine(_cacheRoot, HashKey(key) + ".tar.gz");
    }

    private string SidecarPath(string key)
    {
        return Path.Combine(_cacheRoot, HashKey(key) + ".key");
    }

    private static string HashKey(string key)
    {
        return Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(key)));
    }
}
