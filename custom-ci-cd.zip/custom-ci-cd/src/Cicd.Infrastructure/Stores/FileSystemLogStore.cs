using System.Collections.Concurrent;
using Cicd.Core.Domain;
using Cicd.Core.Storage;

namespace Cicd.Infrastructure.Stores;

/// <summary>
/// Filesystem log store: logs live at <c>&lt;root&gt;/logs/&lt;runId&gt;/&lt;jobId&gt;.log</c>.
/// Implements both <see cref="ILogStore"/> (reads) and <see cref="ILogWriter"/> (appends).
/// Appends publish a <see cref="LogChunk"/> to the broker for live fan-out. The caller is
/// expected to persist the final offset to <c>jobs.log_size</c> (the writer exposes the offset
/// through <see cref="AppendAsync"/>'s return value and via <see cref="CreateWriter"/>).
/// </summary>
public sealed class FileSystemLogStore : ILogStore, ILogWriter
{
    private readonly string _logRoot;
    private readonly ILogBroker _broker;
    private readonly ConcurrentDictionary<Guid, RunId> _jobRuns = new();
    private readonly ConcurrentDictionary<Guid, SemaphoreSlim> _locks = new();

    public FileSystemLogStore(string logRoot, ILogBroker broker)
    {
        _logRoot = logRoot;
        _broker = broker;
        Directory.CreateDirectory(_logRoot);
    }

    /// <summary>Associates a job with its run so the file path can be resolved for reads/writes.</summary>
    public void Register(JobId jobId, RunId runId)
    {
        _jobRuns[jobId.Value] = runId;
    }

    public async Task<long> GetSizeAsync(JobId jobId, CancellationToken ct)
    {
        var path = ResolvePath(jobId);
        if (path is null || !File.Exists(path))
        {
            return 0;
        }

        return await Task.FromResult(new FileInfo(path).Length);
    }

    public Stream OpenRead(JobId jobId, long fromOffset)
    {
        var path = ResolvePath(jobId);
        if (path is null || !File.Exists(path))
        {
            return Stream.Null;
        }

        var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        if (fromOffset > 0 && fromOffset <= stream.Length)
        {
            stream.Seek(fromOffset, SeekOrigin.Begin);
        }

        return stream;
    }

    public async Task<long> AppendAsync(JobId jobId, ReadOnlyMemory<byte> data, CancellationToken ct)
    {
        var path = ResolvePath(jobId)
            ?? throw new InvalidOperationException($"Job '{jobId}' has no registered run for log storage.");

        Directory.CreateDirectory(Path.GetDirectoryName(path)!);

        var gate = _locks.GetOrAdd(jobId.Value, _ => new SemaphoreSlim(1, 1));
        await gate.WaitAsync(ct);
        long offset;
        try
        {
            await using var stream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read);
            offset = stream.Position;
            await stream.WriteAsync(data, ct);
            await stream.FlushAsync(ct);
        }
        finally
        {
            gate.Release();
        }

        _broker.Publish(new LogChunk(jobId, offset, data));
        return offset + data.Length;
    }

    /// <summary>
    /// Creates a streaming writer for a job that masks secret values, fans out to the broker and
    /// tracks the running byte offset. Dispose to flush the masker tail and complete the broker.
    /// </summary>
    public JobLogWriter CreateWriter(JobId jobId, IEnumerable<string> secretValues)
    {
        return new JobLogWriter(this, _broker, jobId, secretValues);
    }

    private string? ResolvePath(JobId jobId)
    {
        if (!_jobRuns.TryGetValue(jobId.Value, out var runId))
        {
            return null;
        }

        return Path.Combine(_logRoot, runId.Value.ToString(), jobId.Value + ".log");
    }
}
