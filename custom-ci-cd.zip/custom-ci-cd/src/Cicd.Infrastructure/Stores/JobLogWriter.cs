using System.Text;
using Cicd.Core.Domain;
using Cicd.Core.Secrets;
using Cicd.Core.Storage;

namespace Cicd.Infrastructure.Stores;

/// <summary>
/// A per-job streaming log writer. Output is run through <see cref="SecretMasker"/> (streaming,
/// boundary-safe) before being appended to the durable store and fanned out to subscribers. The
/// running byte offset is exposed via <see cref="Offset"/> so the caller can persist
/// <c>jobs.log_size</c> after the job finishes.
/// </summary>
public sealed class JobLogWriter : IAsyncDisposable
{
    private readonly FileSystemLogStore _store;
    private readonly ILogBroker _broker;
    private readonly JobId _jobId;
    private readonly SecretMasker _masker;

    public JobLogWriter(FileSystemLogStore store, ILogBroker broker, JobId jobId, IEnumerable<string> secretValues)
    {
        _store = store;
        _broker = broker;
        _jobId = jobId;
        _masker = new SecretMasker(secretValues);
    }

    /// <summary>The current total byte size persisted for this job.</summary>
    public long Offset { get; private set; }

    public async Task WriteAsync(string text, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(text))
        {
            return;
        }

        var masked = _masker.MaskChunk(text);
        await EmitAsync(masked, ct);
    }

    public async Task WriteLineAsync(string text, CancellationToken ct)
    {
        await WriteAsync(text + "\n", ct);
    }

    public async ValueTask DisposeAsync()
    {
        var tail = _masker.Flush();
        if (tail.Length > 0)
        {
            await EmitAsync(tail, CancellationToken.None);
        }

        _broker.Complete(_jobId);
    }

    private async Task EmitAsync(string text, CancellationToken ct)
    {
        if (text.Length == 0)
        {
            return;
        }

        var bytes = Encoding.UTF8.GetBytes(text);
        Offset = await _store.AppendAsync(_jobId, bytes, ct);
    }
}
