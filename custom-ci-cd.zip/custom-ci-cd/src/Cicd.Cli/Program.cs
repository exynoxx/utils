using System.CommandLine;
using Cicd.Cli.Commands;

var root = new RootCommand("cicd — command-line client for the local-hostable CI/CD server.");

root.AddCommand(ConfigCommands.Build());
root.AddCommand(PipelineCommands.Build());
root.AddCommand(RunCommands.BuildRun());
root.AddCommand(RunCommands.BuildStatus());
root.AddCommand(RunCommands.BuildLogs());
root.AddCommand(RunCommands.BuildHistory());
root.AddCommand(SecretCommands.Build());
root.AddCommand(RunCommands.BuildCancel());

return await root.InvokeAsync(args);
