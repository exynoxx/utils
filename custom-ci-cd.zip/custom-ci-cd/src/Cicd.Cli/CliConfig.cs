using System.Text.Json;
using System.Text.Json.Serialization;

namespace Cicd.Cli;

public sealed record CliConfig
{
    public string? ServerUrl { get; init; }
    public string? Token { get; init; }

    public static string ConfigDirectory =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            ".cicd");

    public static string ConfigPath => Path.Combine(ConfigDirectory, "config.json");

    public static CliConfig Load()
    {
        if (!File.Exists(ConfigPath))
        {
            return new CliConfig();
        }

        var json = File.ReadAllText(ConfigPath);
        if (string.IsNullOrWhiteSpace(json))
        {
            return new CliConfig();
        }

        return JsonSerializer.Deserialize(json, CliConfigJsonContext.Default.CliConfig) ?? new CliConfig();
    }

    public void Save()
    {
        Directory.CreateDirectory(ConfigDirectory);
        var json = JsonSerializer.Serialize(this, CliConfigJsonContext.Default.CliConfig);
        File.WriteAllText(ConfigPath, json);
    }
}

[JsonSourceGenerationOptions(
    PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase,
    WriteIndented = true)]
[JsonSerializable(typeof(CliConfig))]
internal sealed partial class CliConfigJsonContext : JsonSerializerContext
{
}
