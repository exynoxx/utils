using Cicd.Contracts;

namespace Cicd.Cli;

public static class PipelineResolver
{
    public static async Task<Guid> ResolveAsync(CicdApiClient client, string nameOrId, CancellationToken ct)
    {
        if (Guid.TryParse(nameOrId, out var id))
        {
            return id;
        }

        var pipelines = await client.ListPipelinesAsync(ct);
        var matches = pipelines.Items
            .Where(p => string.Equals(p.Name, nameOrId, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (matches.Count == 0)
        {
            throw new CicdCommandException($"No pipeline found matching '{nameOrId}'.");
        }

        if (matches.Count > 1)
        {
            throw new CicdCommandException(
                $"Multiple pipelines named '{nameOrId}'. Use the pipeline id instead.");
        }

        return matches[0].Id;
    }
}

public sealed class CicdCommandException : Exception
{
    public CicdCommandException(string message)
        : base(message)
    {
    }
}
