using System.CommandLine;
using Cicd.Contracts;

namespace Cicd.Cli.Commands;

public static class RunCommands
{
    public static Command BuildRun()
    {
        var pipelineArgument = new Argument<string>("pipelineNameOrId", "Pipeline name or id.");
        var branchOption = new Option<string?>("--branch", "Branch to run against.");
        var inputOption = new Option<string[]>("--input", "Manual input as key=value (repeatable).")
        {
            AllowMultipleArgumentsPerToken = false
        };

        var run = new Command("run", "Trigger a pipeline run.");
        run.AddArgument(pipelineArgument);
        run.AddOption(branchOption);
        run.AddOption(inputOption);

        run.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var nameOrId = context.ParseResult.GetValueForArgument(pipelineArgument);
            var branch = context.ParseResult.GetValueForOption(branchOption);
            var inputs = ParseInputs(context.ParseResult.GetValueForOption(inputOption));

            var pipelineId = await PipelineResolver.ResolveAsync(client, nameOrId, ct);
            var request = new CreateRunRequest(branch, inputs);
            var created = await client.CreateRunAsync(pipelineId, request, ct);

            Console.Write($"Started run {created.Id} on '{created.Branch}' — ");
            ConsoleOutput.WriteRunStatus(created.Status);
        }));
        return run;
    }

    public static Command BuildStatus()
    {
        var runArgument = new Argument<string?>("runId", () => null, "Run id. Omit to list recent runs.");

        var status = new Command("status", "Show run status, or list recent runs.");
        status.AddArgument(runArgument);

        status.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var runIdRaw = context.ParseResult.GetValueForArgument(runArgument);
            if (string.IsNullOrWhiteSpace(runIdRaw))
            {
                await ListRecentAsync(client, ct);
                return;
            }

            if (!Guid.TryParse(runIdRaw, out var runId))
            {
                throw new CicdCommandException($"'{runIdRaw}' is not a valid run id.");
            }

            var run = await client.GetRunAsync(runId, ct);
            PrintRunDetail(run);
        }));
        return status;
    }

    public static Command BuildLogs()
    {
        var runArgument = new Argument<Guid>("runId", "Run id.");
        var jobOption = new Option<string?>("--job", "Job name (defaults to the only job, or fails if ambiguous).");
        var followOption = new Option<bool>("--follow", "Follow the live log stream (SSE).");

        var logs = new Command("logs", "Fetch or follow job logs for a run.");
        logs.AddArgument(runArgument);
        logs.AddOption(jobOption);
        logs.AddOption(followOption);

        logs.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var runId = context.ParseResult.GetValueForArgument(runArgument);
            var jobName = context.ParseResult.GetValueForOption(jobOption);
            var follow = context.ParseResult.GetValueForOption(followOption);

            var run = await client.GetRunAsync(runId, ct);
            var job = ResolveJob(run, jobName);

            if (follow)
            {
                var streamer = new SseLogStreamer(client, runId, job.Id);
                await streamer.StreamAsync(ct);
                return;
            }

            var body = await client.GetJobLogsAsync(runId, job.Id, ct);
            Console.Out.Write(body);
            if (!body.EndsWith('\n'))
            {
                Console.Out.WriteLine();
            }
        }));
        return logs;
    }

    public static Command BuildHistory()
    {
        var pipelineArgument = new Argument<string>("pipelineNameOrId", "Pipeline name or id.");
        var limitOption = new Option<int>("--limit", () => 20, "Maximum number of runs to show.");

        var history = new Command("history", "Show run history for a pipeline.");
        history.AddArgument(pipelineArgument);
        history.AddOption(limitOption);

        history.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var nameOrId = context.ParseResult.GetValueForArgument(pipelineArgument);
            var limit = context.ParseResult.GetValueForOption(limitOption);

            var pipelineId = await PipelineResolver.ResolveAsync(client, nameOrId, ct);
            var result = await client.GetPipelineRunsAsync(pipelineId, limit, ct);
            PrintRunTable(result.Items);
        }));
        return history;
    }

    public static Command BuildCancel()
    {
        var runArgument = new Argument<Guid>("runId", "Run id to cancel.");

        var cancel = new Command("cancel", "Cancel a running pipeline run.");
        cancel.AddArgument(runArgument);

        cancel.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var runId = context.ParseResult.GetValueForArgument(runArgument);
            await client.CancelRunAsync(runId, ct);
            Console.WriteLine($"Requested cancellation of run {runId}.");
        }));
        return cancel;
    }

    private static async Task ListRecentAsync(CicdApiClient client, CancellationToken ct)
    {
        var result = await client.ListRecentRunsAsync(20, ct);
        PrintRunTable(result.Items);
    }

    private static void PrintRunTable(IReadOnlyList<RunDto> runs)
    {
        if (runs.Count == 0)
        {
            Console.WriteLine("No runs found.");
            return;
        }

        var rows = runs
            .Select(r => (IReadOnlyList<string>)new[]
            {
                r.Id.ToString(),
                r.Branch,
                r.TriggerOn,
                r.Status.ToString(),
                r.CreatedAt.ToString("u")
            })
            .ToList();

        ConsoleOutput.Table(new[] { "RUN", "BRANCH", "TRIGGER", "STATUS", "CREATED" }, rows);
    }

    private static void PrintRunDetail(RunDetailDto run)
    {
        Console.Write($"Run {run.Id}  branch={run.Branch}  trigger={run.TriggerOn}  status=");
        ConsoleOutput.WriteColoredCell(ConsoleOutput.StatusColor(run.Status), run.Status.ToString());
        Console.WriteLine();

        if (run.Jobs.Count == 0)
        {
            return;
        }

        Console.WriteLine();
        Console.WriteLine("Jobs:");
        foreach (var job in run.Jobs)
        {
            Console.Write("  ");
            ConsoleOutput.WriteColoredCell(ConsoleOutput.StatusColor(job.Status), job.Status.ToString().PadRight(10));
            Console.WriteLine($"  {job.Name}  (attempt {job.Attempt})");
        }
    }

    private static JobDto ResolveJob(RunDetailDto run, string? jobName)
    {
        if (run.Jobs.Count == 0)
        {
            throw new CicdCommandException("Run has no jobs.");
        }

        if (!string.IsNullOrWhiteSpace(jobName))
        {
            var match = run.Jobs.FirstOrDefault(
                j => string.Equals(j.Name, jobName, StringComparison.OrdinalIgnoreCase));
            if (match is null)
            {
                throw new CicdCommandException($"No job named '{jobName}' in run {run.Id}.");
            }

            return match;
        }

        if (run.Jobs.Count > 1)
        {
            var names = string.Join(", ", run.Jobs.Select(j => j.Name));
            throw new CicdCommandException(
                $"Run has multiple jobs ({names}). Specify one with --job.");
        }

        return run.Jobs[0];
    }

    private static IReadOnlyDictionary<string, string>? ParseInputs(string[]? raw)
    {
        if (raw is null || raw.Length == 0)
        {
            return null;
        }

        var dict = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var entry in raw)
        {
            var separator = entry.IndexOf('=');
            if (separator <= 0)
            {
                throw new CicdCommandException($"Invalid --input '{entry}'. Expected key=value.");
            }

            var key = entry[..separator];
            var value = entry[(separator + 1)..];
            dict[key] = value;
        }

        return dict;
    }
}
