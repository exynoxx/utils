using System.CommandLine;

namespace Cicd.Cli.Commands;

public static class ConfigCommands
{
    public static Command Build()
    {
        var configCommand = new Command("config", "Manage CLI configuration.");

        var urlArgument = new Argument<string>("url", "Base URL of the Cicd server.");
        var tokenOption = new Option<string>("--token", "API token used for authentication.")
        {
            IsRequired = true
        };

        var setServer = new Command("set-server", "Persist the server URL and API token to ~/.cicd/config.json.");
        setServer.AddArgument(urlArgument);
        setServer.AddOption(tokenOption);
        setServer.SetHandler(context =>
        {
            var url = context.ParseResult.GetValueForArgument(urlArgument);
            var token = context.ParseResult.GetValueForOption(tokenOption);

            var config = CliConfig.Load() with
            {
                ServerUrl = url,
                Token = token
            };
            config.Save();

            Console.WriteLine($"Saved server '{url}' to {CliConfig.ConfigPath}.");
        });

        configCommand.AddCommand(setServer);
        return configCommand;
    }
}
