using System.CommandLine;
using Cicd.Contracts;

namespace Cicd.Cli.Commands;

public static class PipelineCommands
{
    public static Command Build()
    {
        var pipelines = new Command("pipelines", "Manage pipelines.");
        pipelines.AddCommand(BuildList());
        pipelines.AddCommand(BuildRegister());
        pipelines.AddCommand(BuildValidate());
        return pipelines;
    }

    private static Command BuildList()
    {
        var list = new Command("list", "List registered pipelines.");
        list.SetHandler(CommandRunner.WithClient(async (client, _, ct) =>
        {
            var result = await client.ListPipelinesAsync(ct);
            if (result.Items.Count == 0)
            {
                Console.WriteLine("No pipelines registered.");
                return;
            }

            var rows = result.Items
                .Select(p => (IReadOnlyList<string>)new[]
                {
                    p.Id.ToString(),
                    p.Name,
                    p.RepoUrl ?? (p.HasRawYaml ? "(standalone)" : "-"),
                    p.CreatedAt.ToString("u")
                })
                .ToList();

            ConsoleOutput.Table(new[] { "ID", "NAME", "SOURCE", "CREATED" }, rows);
        }));
        return list;
    }

    private static Command BuildRegister()
    {
        var fileArgument = new Argument<FileInfo>("file", "Pipeline YAML file.");
        var repoOption = new Option<string?>("--repo", "Repository URL for a repo-backed pipeline.");
        var nameOption = new Option<string?>("--name", "Pipeline name override.");

        var register = new Command("register", "Register a pipeline from a YAML file.");
        register.AddArgument(fileArgument);
        register.AddOption(repoOption);
        register.AddOption(nameOption);

        register.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var file = context.ParseResult.GetValueForArgument(fileArgument);
            var repo = context.ParseResult.GetValueForOption(repoOption);
            var name = context.ParseResult.GetValueForOption(nameOption);

            if (!file.Exists)
            {
                throw new CicdCommandException($"File not found: {file.FullName}");
            }

            var yaml = await File.ReadAllTextAsync(file.FullName, ct);
            var request = new RegisterPipelineRequest(name, repo, yaml);
            var pipeline = await client.RegisterPipelineAsync(request, ct);

            Console.WriteLine($"Registered pipeline '{pipeline.Name}' ({pipeline.Id}).");
        }));
        return register;
    }

    private static Command BuildValidate()
    {
        var fileArgument = new Argument<FileInfo>("file", "Pipeline YAML file.");

        var validate = new Command("validate", "Validate a pipeline YAML file against the server.");
        validate.AddArgument(fileArgument);

        validate.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var file = context.ParseResult.GetValueForArgument(fileArgument);
            if (!file.Exists)
            {
                throw new CicdCommandException($"File not found: {file.FullName}");
            }

            var yaml = await File.ReadAllTextAsync(file.FullName, ct);
            var result = await client.ValidateAsync(new ValidateRequest(yaml), ct);

            if (result.IsValid)
            {
                ConsoleOutput.WriteColoredCell(ConsoleColor.Green, "Valid");
                Console.WriteLine();
                return;
            }

            ConsoleOutput.Error("Invalid pipeline:");
            Console.Error.WriteLine();
            foreach (var error in result.Errors)
            {
                var location = error.Line is { } line
                    ? $"line {line}" + (error.Column is { } col ? $", col {col}" : string.Empty)
                    : "unknown location";
                Console.Error.WriteLine($"  [{location}] {error.Message}");
            }

            context.ExitCode = 1;
        }));
        return validate;
    }
}
