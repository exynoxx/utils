using System.CommandLine;
using System.Text;
using Cicd.Contracts;

namespace Cicd.Cli.Commands;

public static class SecretCommands
{
    public static Command Build()
    {
        var secrets = new Command("secrets", "Manage secrets.");
        secrets.AddCommand(BuildSet());
        secrets.AddCommand(BuildList());
        return secrets;
    }

    private static Command BuildSet()
    {
        var nameArgument = new Argument<string>("name", "Secret name.");
        var scopeOption = new Option<string>(
            "--scope",
            () => "global",
            "Scope: 'global' or a pipeline name/id.");

        var set = new Command("set", "Set or update a secret. Reads CICD_SECRET_VALUE if set, otherwise prompts.");
        set.AddArgument(nameArgument);
        set.AddOption(scopeOption);

        set.SetHandler(CommandRunner.WithClient(async (client, context, ct) =>
        {
            var name = context.ParseResult.GetValueForArgument(nameArgument);
            var scope = context.ParseResult.GetValueForOption(scopeOption) ?? "global";

            var value = ReadSecretValue();
            if (string.IsNullOrEmpty(value))
            {
                throw new CicdCommandException("Secret value was empty.");
            }

            string scopeName;
            Guid? pipelineId = null;
            if (string.Equals(scope, "global", StringComparison.OrdinalIgnoreCase))
            {
                scopeName = "global";
            }
            else
            {
                pipelineId = await PipelineResolver.ResolveAsync(client, scope, ct);
                scopeName = "pipeline";
            }

            var request = new SetSecretRequest(value, scopeName, pipelineId);
            await client.SetSecretAsync(name, request, ct);
            Console.WriteLine($"Set secret '{name}' (scope: {scope}).");
        }));
        return set;
    }

    private static Command BuildList()
    {
        var list = new Command("list", "List secret names and scopes (never values).");
        list.SetHandler(CommandRunner.WithClient(async (client, _, ct) =>
        {
            var secrets = await client.ListSecretsAsync(ct);
            if (secrets.Count == 0)
            {
                Console.WriteLine("No secrets set.");
                return;
            }

            var rows = secrets
                .Select(s => (IReadOnlyList<string>)new[]
                {
                    s.Name,
                    s.Scope,
                    s.PipelineId?.ToString() ?? "-"
                })
                .ToList();

            ConsoleOutput.Table(new[] { "NAME", "SCOPE", "PIPELINE" }, rows);
        }));
        return list;
    }

    private static string ReadSecretValue()
    {
        var fromEnv = Environment.GetEnvironmentVariable("CICD_SECRET_VALUE");
        if (!string.IsNullOrEmpty(fromEnv))
        {
            return fromEnv;
        }

        if (Console.IsInputRedirected)
        {
            return Console.In.ReadToEnd().Trim('\r', '\n');
        }

        Console.Out.Write("Secret value: ");
        var builder = new StringBuilder();
        while (true)
        {
            var key = Console.ReadKey(intercept: true);
            if (key.Key == ConsoleKey.Enter)
            {
                Console.Out.WriteLine();
                break;
            }

            if (key.Key == ConsoleKey.Backspace)
            {
                if (builder.Length > 0)
                {
                    builder.Length--;
                }

                continue;
            }

            if (!char.IsControl(key.KeyChar))
            {
                builder.Append(key.KeyChar);
            }
        }

        return builder.ToString();
    }
}
