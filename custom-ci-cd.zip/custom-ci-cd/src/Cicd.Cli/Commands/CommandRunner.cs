using System.CommandLine.Invocation;

namespace Cicd.Cli.Commands;

public static class CommandRunner
{
    public static Func<InvocationContext, Task> WithClient(Func<CicdApiClient, InvocationContext, CancellationToken, Task> action)
    {
        return async context =>
        {
            var ct = context.GetCancellationToken();
            try
            {
                using var client = new CicdApiClient(CliConfig.Load());
                await action(client, context, ct);
            }
            catch (OperationCanceledException)
            {
                context.ExitCode = 130;
            }
            catch (CicdApiException ex)
            {
                ConsoleOutput.Error($"API error ({(int)ex.StatusCode}): {ex.Message}");
                Console.Error.WriteLine();
                context.ExitCode = 1;
            }
            catch (CicdCommandException ex)
            {
                ConsoleOutput.Error(ex.Message);
                Console.Error.WriteLine();
                context.ExitCode = 1;
            }
            catch (InvalidOperationException ex)
            {
                ConsoleOutput.Error(ex.Message);
                Console.Error.WriteLine();
                context.ExitCode = 1;
            }
            catch (HttpRequestException ex)
            {
                ConsoleOutput.Error($"Could not reach server: {ex.Message}");
                Console.Error.WriteLine();
                context.ExitCode = 1;
            }
        };
    }
}
