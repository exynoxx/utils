using System.Text;
using Cicd.Contracts;

namespace Cicd.Cli;

public static class ConsoleOutput
{
    public static void Error(string message)
    {
        WriteColored(ConsoleColor.Red, message, Console.Error);
    }

    public static void WriteRunStatus(RunStatusDto status)
    {
        WriteColored(StatusColor(status), status.ToString(), Console.Out);
        Console.Out.WriteLine();
    }

    public static ConsoleColor StatusColor(RunStatusDto status)
    {
        return status switch
        {
            RunStatusDto.Succeeded => ConsoleColor.Green,
            RunStatusDto.Failed => ConsoleColor.Red,
            RunStatusDto.Canceled => ConsoleColor.Red,
            RunStatusDto.Running => ConsoleColor.Yellow,
            RunStatusDto.Queued => ConsoleColor.Yellow,
            _ => Console.ForegroundColor
        };
    }

    public static ConsoleColor StatusColor(JobStatusDto status)
    {
        return status switch
        {
            JobStatusDto.Succeeded => ConsoleColor.Green,
            JobStatusDto.Failed => ConsoleColor.Red,
            JobStatusDto.Canceled => ConsoleColor.Red,
            JobStatusDto.Running => ConsoleColor.Yellow,
            JobStatusDto.Queued => ConsoleColor.Yellow,
            JobStatusDto.Pending => ConsoleColor.Yellow,
            _ => Console.ForegroundColor
        };
    }

    public static void WriteColoredCell(ConsoleColor color, string text)
    {
        WriteColored(color, text, Console.Out);
    }

    public static void Table(IReadOnlyList<string> headers, IReadOnlyList<IReadOnlyList<string>> rows)
    {
        var widths = new int[headers.Count];
        for (var i = 0; i < headers.Count; i++)
        {
            widths[i] = headers[i].Length;
        }

        foreach (var row in rows)
        {
            for (var i = 0; i < headers.Count && i < row.Count; i++)
            {
                widths[i] = Math.Max(widths[i], row[i].Length);
            }
        }

        Console.Out.WriteLine(FormatRow(headers, widths));
        var separator = new StringBuilder();
        for (var i = 0; i < headers.Count; i++)
        {
            if (i > 0)
            {
                separator.Append("  ");
            }

            separator.Append(new string('-', widths[i]));
        }

        Console.Out.WriteLine(separator.ToString());

        foreach (var row in rows)
        {
            Console.Out.WriteLine(FormatRow(row, widths));
        }
    }

    private static string FormatRow(IReadOnlyList<string> cells, int[] widths)
    {
        var builder = new StringBuilder();
        for (var i = 0; i < widths.Length; i++)
        {
            if (i > 0)
            {
                builder.Append("  ");
            }

            var value = i < cells.Count ? cells[i] : string.Empty;
            builder.Append(value.PadRight(widths[i]));
        }

        return builder.ToString().TrimEnd();
    }

    private static void WriteColored(ConsoleColor color, string message, TextWriter writer)
    {
        var previous = Console.ForegroundColor;
        try
        {
            Console.ForegroundColor = color;
            writer.Write(message);
        }
        finally
        {
            Console.ForegroundColor = previous;
        }
    }
}
