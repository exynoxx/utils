using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Cicd.Contracts;

namespace Cicd.Cli;

public sealed class CicdApiClient : IDisposable
{
    private readonly HttpClient _http;

    public CicdApiClient(CliConfig config)
    {
        if (string.IsNullOrWhiteSpace(config.ServerUrl))
        {
            throw new InvalidOperationException(
                "No server configured. Run 'cicd config set-server <url> --token <token>' first.");
        }

        _http = new HttpClient
        {
            BaseAddress = new Uri(config.ServerUrl.TrimEnd('/') + "/")
        };

        if (!string.IsNullOrWhiteSpace(config.Token))
        {
            _http.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", config.Token);
        }
    }

    public static JsonSerializerOptions JsonOptions { get; } = CreateJsonOptions();

    public void Dispose()
    {
        _http.Dispose();
    }

    // --- Pipelines ---

    public Task<PagedResult<PipelineDto>> ListPipelinesAsync(CancellationToken ct)
    {
        return GetAsync<PagedResult<PipelineDto>>("api/pipelines", ct);
    }

    public Task<PipelineDetailDto> GetPipelineAsync(Guid pipelineId, CancellationToken ct)
    {
        return GetAsync<PipelineDetailDto>($"api/pipelines/{pipelineId}", ct);
    }

    public Task<PipelineDto> RegisterPipelineAsync(RegisterPipelineRequest request, CancellationToken ct)
    {
        return PostAsync<RegisterPipelineRequest, PipelineDto>("api/pipelines", request, ct);
    }

    public Task<PipelineDetailDto> UpdatePipelineAsync(Guid pipelineId, UpdatePipelineRequest request, CancellationToken ct)
    {
        return SendJsonAsync<UpdatePipelineRequest, PipelineDetailDto>(
            HttpMethod.Put, $"api/pipelines/{pipelineId}", request, ct);
    }

    public Task DeletePipelineAsync(Guid pipelineId, CancellationToken ct)
    {
        return SendNoContentAsync(HttpMethod.Delete, $"api/pipelines/{pipelineId}", ct);
    }

    public Task<ValidationResultDto> ValidateAsync(ValidateRequest request, CancellationToken ct)
    {
        return PostAsync<ValidateRequest, ValidationResultDto>("api/pipelines/validate", request, ct);
    }

    public Task<ValidationResultDto> ValidatePipelineByIdAsync(Guid pipelineId, ValidateRequest request, CancellationToken ct)
    {
        return PostAsync<ValidateRequest, ValidationResultDto>(
            $"api/pipelines/{pipelineId}/validate", request, ct);
    }

    // --- Runs ---

    public Task<RunDto> CreateRunAsync(Guid pipelineId, CreateRunRequest request, CancellationToken ct)
    {
        return PostAsync<CreateRunRequest, RunDto>($"api/pipelines/{pipelineId}/runs", request, ct);
    }

    public Task<PagedResult<RunDto>> GetPipelineRunsAsync(Guid pipelineId, int limit, CancellationToken ct)
    {
        return GetAsync<PagedResult<RunDto>>($"api/pipelines/{pipelineId}/runs?pageSize={limit}", ct);
    }

    public Task<PagedResult<RunDto>> ListRecentRunsAsync(int limit, CancellationToken ct)
    {
        return GetAsync<PagedResult<RunDto>>($"api/runs?limit={limit}", ct);
    }

    public Task<RunDetailDto> GetRunAsync(Guid runId, CancellationToken ct)
    {
        return GetAsync<RunDetailDto>($"api/runs/{runId}", ct);
    }

    public Task CancelRunAsync(Guid runId, CancellationToken ct)
    {
        return SendNoContentAsync(HttpMethod.Post, $"api/runs/{runId}/cancel", ct);
    }

    public Task<JobDto> GetJobAsync(Guid runId, Guid jobId, CancellationToken ct)
    {
        return GetAsync<JobDto>($"api/runs/{runId}/jobs/{jobId}", ct);
    }

    // --- Logs ---

    public async Task<string> GetJobLogsAsync(Guid runId, Guid jobId, CancellationToken ct)
    {
        using var response = await _http.GetAsync(
            $"api/runs/{runId}/jobs/{jobId}/logs", ct);
        await EnsureSuccessAsync(response, ct);
        return await response.Content.ReadAsStringAsync(ct);
    }

    public Task<HttpResponseMessage> OpenLogStreamAsync(Guid runId, Guid jobId, long fromOffset, CancellationToken ct)
    {
        var request = new HttpRequestMessage(
            HttpMethod.Get,
            $"api/runs/{runId}/jobs/{jobId}/logs/stream");
        if (fromOffset > 0)
        {
            request.Headers.TryAddWithoutValidation("Last-Event-ID", fromOffset.ToString());
        }

        return _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
    }

    // --- Artifacts ---

    public Task<IReadOnlyList<ArtifactDto>> GetRunArtifactsAsync(Guid runId, CancellationToken ct)
    {
        return GetAsync<IReadOnlyList<ArtifactDto>>($"api/runs/{runId}/artifacts", ct);
    }

    // --- Secrets ---

    public Task<IReadOnlyList<SecretDto>> ListSecretsAsync(CancellationToken ct)
    {
        return GetAsync<IReadOnlyList<SecretDto>>("api/secrets", ct);
    }

    public Task SetSecretAsync(string name, SetSecretRequest request, CancellationToken ct)
    {
        return SendNoContentAsync(HttpMethod.Put, $"api/secrets/{Uri.EscapeDataString(name)}", ct, request);
    }

    public Task DeleteSecretAsync(string name, CancellationToken ct)
    {
        return SendNoContentAsync(HttpMethod.Delete, $"api/secrets/{Uri.EscapeDataString(name)}", ct);
    }

    // --- Tokens ---

    public Task<IReadOnlyList<ApiTokenDto>> ListTokensAsync(CancellationToken ct)
    {
        return GetAsync<IReadOnlyList<ApiTokenDto>>("api/tokens", ct);
    }

    public Task<CreateTokenResponse> CreateTokenAsync(CreateTokenRequest request, CancellationToken ct)
    {
        return PostAsync<CreateTokenRequest, CreateTokenResponse>("api/tokens", request, ct);
    }

    public Task DeleteTokenAsync(Guid tokenId, CancellationToken ct)
    {
        return SendNoContentAsync(HttpMethod.Delete, $"api/tokens/{tokenId}", ct);
    }

    private static JsonSerializerOptions CreateJsonOptions()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }

    private async Task<T> GetAsync<T>(string path, CancellationToken ct)
    {
        using var response = await _http.GetAsync(path, ct);
        await EnsureSuccessAsync(response, ct);
        return await ReadAsync<T>(response, ct);
    }

    private async Task<TResponse> PostAsync<TRequest, TResponse>(string path, TRequest body, CancellationToken ct)
    {
        return await SendJsonAsync<TRequest, TResponse>(HttpMethod.Post, path, body, ct);
    }

    private async Task<TResponse> SendJsonAsync<TRequest, TResponse>(
        HttpMethod method, string path, TRequest body, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(method, path)
        {
            Content = JsonContent.Create(body, options: JsonOptions)
        };
        using var response = await _http.SendAsync(request, ct);
        await EnsureSuccessAsync(response, ct);
        return await ReadAsync<TResponse>(response, ct);
    }

    private async Task SendNoContentAsync(
        HttpMethod method, string path, CancellationToken ct, object? body = null)
    {
        using var request = new HttpRequestMessage(method, path);
        if (body is not null)
        {
            request.Content = JsonContent.Create(body, body.GetType(), options: JsonOptions);
        }

        using var response = await _http.SendAsync(request, ct);
        await EnsureSuccessAsync(response, ct);
    }

    private static async Task<T> ReadAsync<T>(HttpResponseMessage response, CancellationToken ct)
    {
        var result = await response.Content.ReadFromJsonAsync<T>(JsonOptions, ct);
        if (result is null)
        {
            throw new CicdApiException(response.StatusCode, "Server returned an empty response body.");
        }

        return result;
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response, CancellationToken ct)
    {
        if (response.IsSuccessStatusCode)
        {
            return;
        }

        var message = await TryReadProblemAsync(response, ct);
        throw new CicdApiException(response.StatusCode, message);
    }

    private static async Task<string> TryReadProblemAsync(HttpResponseMessage response, CancellationToken ct)
    {
        var fallback = $"{(int)response.StatusCode} {response.ReasonPhrase}";
        try
        {
            var raw = await response.Content.ReadAsStringAsync(ct);
            if (string.IsNullOrWhiteSpace(raw))
            {
                return fallback;
            }

            try
            {
                using var doc = JsonDocument.Parse(raw);
                var root = doc.RootElement;
                if (root.ValueKind == JsonValueKind.Object)
                {
                    if (root.TryGetProperty("detail", out var detail) && detail.ValueKind == JsonValueKind.String)
                    {
                        return detail.GetString() ?? fallback;
                    }

                    if (root.TryGetProperty("title", out var title) && title.ValueKind == JsonValueKind.String)
                    {
                        return title.GetString() ?? fallback;
                    }
                }
            }
            catch (JsonException)
            {
                return raw.Trim();
            }

            return raw.Trim();
        }
        catch (Exception)
        {
            return fallback;
        }
    }
}
