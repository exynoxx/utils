using System.Net;

namespace Cicd.Cli;

public sealed class CicdApiException : Exception
{
    public CicdApiException(HttpStatusCode statusCode, string message)
        : base(message)
    {
        StatusCode = statusCode;
    }

    public HttpStatusCode StatusCode { get; }
}
