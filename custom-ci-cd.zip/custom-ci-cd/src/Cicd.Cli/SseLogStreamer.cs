namespace Cicd.Cli;

// Consumes an SSE log stream: accumulates `data:` lines until a blank line,
// prints the payload, tracks `id:` (byte offset) for a single reconnect attempt,
// and terminates on `event: end`.
public sealed class SseLogStreamer
{
    private readonly CicdApiClient _client;
    private readonly Guid _runId;
    private readonly Guid _jobId;

    public SseLogStreamer(CicdApiClient client, Guid runId, Guid jobId)
    {
        _client = client;
        _runId = runId;
        _jobId = jobId;
    }

    public async Task StreamAsync(CancellationToken ct)
    {
        long offset = 0;
        var reconnectsLeft = 1;

        while (true)
        {
            var ended = false;
            try
            {
                ended = await ReadOnceAsync(offset, newOffset => offset = newOffset, ct);
            }
            catch (Exception) when (!ct.IsCancellationRequested && reconnectsLeft > 0)
            {
                reconnectsLeft--;
                await Task.Delay(TimeSpan.FromSeconds(1), ct);
                continue;
            }

            if (ended || ct.IsCancellationRequested)
            {
                return;
            }

            // Stream closed without an explicit end event; attempt one reconnect.
            if (reconnectsLeft > 0)
            {
                reconnectsLeft--;
                continue;
            }

            return;
        }
    }

    private async Task<bool> ReadOnceAsync(long fromOffset, Action<long> updateOffset, CancellationToken ct)
    {
        using var response = await _client.OpenLogStreamAsync(_runId, _jobId, fromOffset, ct);
        response.EnsureSuccessStatusCode();

        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        using var reader = new StreamReader(stream);

        var dataLines = new List<string>();
        var eventName = string.Empty;

        while (!ct.IsCancellationRequested)
        {
            var line = await reader.ReadLineAsync(ct);
            if (line is null)
            {
                return false;
            }

            if (line.Length == 0)
            {
                if (string.Equals(eventName, "end", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                if (dataLines.Count > 0)
                {
                    Console.Out.Write(string.Join("\n", dataLines));
                    Console.Out.Write("\n");
                }

                dataLines.Clear();
                eventName = string.Empty;
                continue;
            }

            if (line.StartsWith("data:", StringComparison.Ordinal))
            {
                dataLines.Add(StripField(line, "data:"));
            }
            else if (line.StartsWith("id:", StringComparison.Ordinal))
            {
                if (long.TryParse(StripField(line, "id:"), out var parsed))
                {
                    updateOffset(parsed);
                }
            }
            else if (line.StartsWith("event:", StringComparison.Ordinal))
            {
                eventName = StripField(line, "event:");
            }
        }

        return false;
    }

    private static string StripField(string line, string prefix)
    {
        var value = line[prefix.Length..];
        if (value.StartsWith(' '))
        {
            value = value[1..];
        }

        return value;
    }
}
