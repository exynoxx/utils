using Cicd.Core.Domain;

namespace Cicd.Core.Execution;

/// <summary>
/// Builds a <see cref="JobExecutionContext"/> for a claimed job. Implemented in Infrastructure
/// (loads the job's run, the pipeline definition slice, resolves secrets and the workspace source).
/// </summary>
public interface IJobContextFactory
{
    Task<JobExecutionContext> CreateAsync(ClaimedJob claimedJob, CancellationToken ct);
}
