using Cicd.Core.Domain;
using Microsoft.Extensions.Logging;

namespace Cicd.Core.Execution;

/// <summary>
/// Spawns N worker loops that claim, execute and complete jobs. Plain class (not a hosted
/// service) so the server can wrap it in a BackgroundService. Handles per-job timeout via a
/// linked CTS, lease renewal heartbeats, run cancellation, and a polling backoff when idle.
/// </summary>
public sealed class WorkerCoordinator
{
    private static readonly TimeSpan IdlePollDelay = TimeSpan.FromSeconds(1);
    private static readonly TimeSpan LeaseRenewInterval = TimeSpan.FromSeconds(15);

    private readonly IJobQueue _queue;
    private readonly IJobContextFactory _contextFactory;
    private readonly IJobExecutorRegistry _executors;
    private readonly IRunScheduler _scheduler;
    private readonly ICancellationRegistry _cancellation;
    private readonly TimeProvider _clock;
    private readonly ILogger<WorkerCoordinator> _logger;

    public WorkerCoordinator(
        IJobQueue queue,
        IJobContextFactory contextFactory,
        IJobExecutorRegistry executors,
        IRunScheduler scheduler,
        ICancellationRegistry cancellation,
        TimeProvider clock,
        ILogger<WorkerCoordinator> logger)
    {
        _queue = queue;
        _contextFactory = contextFactory;
        _executors = executors;
        _scheduler = scheduler;
        _cancellation = cancellation;
        _clock = clock;
        _logger = logger;
    }

    public async Task RunWorkersAsync(int workerCount, CancellationToken ct)
    {
        if (workerCount < 1)
        {
            workerCount = 1;
        }

        var loops = Enumerable
            .Range(0, workerCount)
            .Select(_ => Task.Run(() => WorkerLoopAsync(WorkerId.New(), ct), ct))
            .ToArray();

        await Task.WhenAll(loops);
    }

    private async Task WorkerLoopAsync(WorkerId workerId, CancellationToken ct)
    {
        _logger.LogInformation("Worker {WorkerId} started", workerId);

        while (!ct.IsCancellationRequested)
        {
            ClaimedJob? claimed;
            try
            {
                claimed = await _queue.ClaimNextAsync(workerId, ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Worker {WorkerId} failed to claim a job", workerId);
                await DelayAsync(IdlePollDelay, ct);
                continue;
            }

            if (claimed is null)
            {
                await DelayAsync(IdlePollDelay, ct);
                continue;
            }

            await ProcessClaimedJobAsync(workerId, claimed, ct);
        }

        _logger.LogInformation("Worker {WorkerId} stopped", workerId);
    }

    private async Task ProcessClaimedJobAsync(WorkerId workerId, ClaimedJob claimed, CancellationToken ct)
    {
        var status = JobStatus.Failed;
        try
        {
            var context = await _contextFactory.CreateAsync(claimed, ct);

            var runToken = _cancellation.Register(claimed.RunId);
            using var timeoutCts = new CancellationTokenSource(context.Timeout);
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, runToken, timeoutCts.Token);

            using var leaseCts = CancellationTokenSource.CreateLinkedTokenSource(linked.Token);
            var leaseTask = RenewLeaseLoopAsync(claimed.JobId, workerId, leaseCts.Token);

            try
            {
                var executor = _executors.Resolve(context.Executor);
                var result = await executor.ExecuteAsync(context, linked.Token);
                status = result.Status;
            }
            catch (OperationCanceledException) when (runToken.IsCancellationRequested)
            {
                status = JobStatus.Canceled;
            }
            catch (OperationCanceledException) when (timeoutCts.IsCancellationRequested)
            {
                _logger.LogWarning("Job {JobId} timed out after {Timeout}", claimed.JobId, context.Timeout);
                status = JobStatus.Failed;
            }
            finally
            {
                // The executor is done — stop the heartbeat instead of waiting for job timeout.
                leaseCts.Cancel();
                await SafeAwaitLeaseAsync(leaseTask);
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            return;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Job {JobId} failed during execution", claimed.JobId);
            status = JobStatus.Failed;
        }

        try
        {
            await _queue.CompleteAsync(claimed.JobId, status, CancellationToken.None);
            await _scheduler.OnJobFinishedAsync(claimed.JobId, status, CancellationToken.None);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to finalize job {JobId}", claimed.JobId);
        }
    }

    private async Task RenewLeaseLoopAsync(JobId jobId, WorkerId workerId, CancellationToken ct)
    {
        try
        {
            while (!ct.IsCancellationRequested)
            {
                await DelayAsync(LeaseRenewInterval, ct);
                if (ct.IsCancellationRequested)
                {
                    break;
                }

                var renewed = await _queue.RenewLeaseAsync(jobId, workerId, ct);
                if (!renewed)
                {
                    _logger.LogWarning("Lost lease for job {JobId}", jobId);
                    break;
                }
            }
        }
        catch (OperationCanceledException)
        {
            // Expected when the job completes.
        }
    }

    private async Task SafeAwaitLeaseAsync(Task leaseTask)
    {
        try
        {
            await leaseTask;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Lease renewal loop ended");
        }
    }

    private async Task DelayAsync(TimeSpan delay, CancellationToken ct)
    {
        try
        {
            await Task.Delay(delay, _clock, ct);
        }
        catch (OperationCanceledException)
        {
            // Shutting down.
        }
    }
}
