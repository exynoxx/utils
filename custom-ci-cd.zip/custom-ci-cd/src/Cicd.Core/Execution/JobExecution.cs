using Cicd.Core.Definition;
using Cicd.Core.Definition.Expressions;
using Cicd.Core.Domain;

namespace Cicd.Core.Execution;

/// <summary>Where the job's workspace contents come from.</summary>
public abstract record WorkspaceSource;

/// <summary>Clone a git repo at a SHA into the workspace (push/schedule pipelines).</summary>
public sealed record GitSource(string RepoUrl, string Sha) : WorkspaceSource;

/// <summary>Copy a local directory into the workspace (fileWatch dev loops).</summary>
public sealed record LocalDirSource(string Path) : WorkspaceSource;

/// <summary>No source — the workspace starts empty (pure standalone pipelines).</summary>
public sealed record EmptySource : WorkspaceSource;

/// <summary>The result of a single step execution.</summary>
public sealed record StepResult(int Ordinal, string Name, StepStatus Status, int? ExitCode);

/// <summary>The outcome of executing a job.</summary>
public sealed record JobResult(JobStatus Status, string? FailureReason, IReadOnlyList<StepResult> Steps);

/// <summary>
/// Everything an executor needs to run a job. The context carries the (post-template) raw steps
/// plus an <see cref="ExpressionContext"/>; the executor is responsible for calling
/// <see cref="ExpressionEvaluator.Interpolate"/> on step strings, env values, image names, etc.
/// </summary>
public sealed record JobExecutionContext
{
    public required RunId RunId { get; init; }
    public required JobId JobId { get; init; }
    public required string JobName { get; init; }
    public string? Image { get; init; }
    public required string Executor { get; init; }

    public required IReadOnlyList<StepDefinition> Steps { get; init; }

    /// <summary>Context for interpolating expressions (carries vars, inputs, matrix, secret values).</summary>
    public required ExpressionContext ExpressionContext { get; init; }

    /// <summary>Base env map (pipeline variables + job env + built-in CICD_* values).</summary>
    public IReadOnlyDictionary<string, string> Env { get; init; } = new Dictionary<string, string>();

    /// <summary>Resolved secret values (name → plaintext) for env/with injection.</summary>
    public IReadOnlyDictionary<string, string> SecretValues { get; init; } = new Dictionary<string, string>();

    public required WorkspaceSource WorkspaceSource { get; init; }

    public IReadOnlyList<CacheDefinition> Caches { get; init; } = [];
    public ArtifactsDefinition? Artifacts { get; init; }

    /// <summary>Job names this job needs (for auto-restoring their artifacts).</summary>
    public IReadOnlyList<string> Needs { get; init; } = [];

    public TimeSpan Timeout { get; init; } = TimeSpan.FromMinutes(30);
}

/// <summary>
/// Runs a job. Keyed by the YAML <c>executor:</c> field. The seam for future remote agents.
/// </summary>
public interface IJobExecutor
{
    string Type { get; }

    Task<JobResult> ExecuteAsync(JobExecutionContext context, CancellationToken ct);
}

/// <summary>Resolves an <see cref="IJobExecutor"/> by its <c>Type</c>.</summary>
public interface IJobExecutorRegistry
{
    IJobExecutor Resolve(string executorType);

    bool TryResolve(string executorType, out IJobExecutor executor);
}

/// <summary>Dictionary-backed executor registry.</summary>
public sealed class JobExecutorRegistry : IJobExecutorRegistry
{
    private readonly IReadOnlyDictionary<string, IJobExecutor> _executors;

    public JobExecutorRegistry(IEnumerable<IJobExecutor> executors)
    {
        _executors = executors.ToDictionary(e => e.Type, StringComparer.Ordinal);
    }

    public IJobExecutor Resolve(string executorType)
    {
        if (!_executors.TryGetValue(executorType, out var executor))
        {
            throw new InvalidOperationException($"No executor registered for type '{executorType}'.");
        }

        return executor;
    }

    public bool TryResolve(string executorType, out IJobExecutor executor)
    {
        return _executors.TryGetValue(executorType, out executor!);
    }
}
