using Cicd.Core.Definition;
using Cicd.Core.Domain;

namespace Cicd.Core.Execution;

/// <summary>
/// Loads and parses a pipeline's definition for a given commit. Implemented in Infrastructure
/// (reads in-repo YAML at the commit, or stored standalone YAML).
/// </summary>
public interface IPipelineDefinitionSource
{
    Task<PipelineDefinition> GetDefinitionAsync(PipelineId pipelineId, string commitSha, CancellationToken ct);
}

/// <summary>
/// Pure orchestration: turns a trigger event into a materialized run + jobs, enqueues runnable
/// jobs, and advances the DAG as jobs finish.
/// </summary>
public interface IRunScheduler
{
    /// <summary>
    /// Loads the pipeline definition, evaluates trigger match, expands <c>parallel.matrix</c>,
    /// materializes the run and jobs, enqueues root jobs and marks the rest Pending.
    /// </summary>
    Task<RunId> CreateRunAsync(PipelineId pipelineId, TriggerEvent ev, CancellationToken ct);

    /// <summary>
    /// Applies retry logic, evaluates dependents (enqueue satisfied, skip blocked recursively),
    /// and finalizes the run when all jobs are terminal.
    /// </summary>
    Task OnJobFinishedAsync(JobId jobId, JobStatus result, CancellationToken ct);
}
