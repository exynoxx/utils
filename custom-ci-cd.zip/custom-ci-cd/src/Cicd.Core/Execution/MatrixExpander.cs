namespace Cicd.Core.Execution;

/// <summary>
/// Expands a <c>parallel.matrix</c> into the cross product of axis values.
/// Each combination is an ordered (by axis name) map of axis → value.
/// </summary>
public static class MatrixExpander
{
    public static IReadOnlyList<IReadOnlyDictionary<string, string>> Expand(
        IReadOnlyDictionary<string, IReadOnlyList<string>> matrix)
    {
        var axes = matrix
            .OrderBy(pair => pair.Key, StringComparer.Ordinal)
            .ToList();

        var combinations = new List<IReadOnlyDictionary<string, string>>
        {
            new Dictionary<string, string>()
        };

        foreach (var (axis, values) in axes)
        {
            var next = new List<IReadOnlyDictionary<string, string>>();
            foreach (var combo in combinations)
            {
                foreach (var value in values)
                {
                    var extended = new Dictionary<string, string>(combo) { [axis] = value };
                    next.Add(extended);
                }
            }

            combinations = next;
        }

        return combinations;
    }

    /// <summary>
    /// Builds the display suffix for a matrix combination, e.g. <c> (suite=unit, dotnet=8.0)</c>.
    /// Returns the base name unchanged when there are no values.
    /// </summary>
    public static string JobName(string baseName, IReadOnlyDictionary<string, string> combination)
    {
        if (combination.Count == 0)
        {
            return baseName;
        }

        var parts = combination
            .OrderBy(pair => pair.Key, StringComparer.Ordinal)
            .Select(pair => $"{pair.Key}={pair.Value}");

        return $"{baseName} ({string.Join(", ", parts)})";
    }
}
