using Cicd.Core.Domain;

namespace Cicd.Core.Execution;

/// <summary>
/// An event that may start a run. Produced by trigger sources or by manual API/CLI calls.
/// </summary>
public sealed record TriggerEvent(
    PipelineId PipelineId,
    string On,
    string Branch,
    string CommitSha,
    IReadOnlyList<string> ChangedPaths,
    IReadOnlyDictionary<string, string> Inputs);
