using Cicd.Core.Definition;
using Cicd.Core.Definition.Expressions;
using Cicd.Core.Domain;
using Cicd.Core.Storage;
using Microsoft.Extensions.Logging;

namespace Cicd.Core.Execution;

/// <summary>
/// Pure orchestration logic for runs. Depends only on storage/queue abstractions.
/// </summary>
public sealed class RunScheduler : IRunScheduler
{
    private readonly IPipelineDefinitionSource _definitionSource;
    private readonly IRunRepository _runs;
    private readonly IJobRepository _jobs;
    private readonly IStepRepository _steps;
    private readonly IJobQueue _queue;
    private readonly TimeProvider _clock;
    private readonly ILogger<RunScheduler> _logger;

    public RunScheduler(
        IPipelineDefinitionSource definitionSource,
        IRunRepository runs,
        IJobRepository jobs,
        IStepRepository steps,
        IJobQueue queue,
        TimeProvider clock,
        ILogger<RunScheduler> logger)
    {
        _definitionSource = definitionSource;
        _runs = runs;
        _jobs = jobs;
        _steps = steps;
        _queue = queue;
        _clock = clock;
        _logger = logger;
    }

    public async Task<RunId> CreateRunAsync(PipelineId pipelineId, TriggerEvent ev, CancellationToken ct)
    {
        var definition = await _definitionSource.GetDefinitionAsync(pipelineId, ev.CommitSha, ct);

        var now = _clock.GetUtcNow();
        var run = new Run
        {
            Id = RunId.New(),
            PipelineId = pipelineId,
            TriggerOn = ev.On,
            Branch = ev.Branch,
            CommitSha = ev.CommitSha,
            Inputs = ev.Inputs,
            Status = RunStatus.Queued,
            CreatedAt = now
        };
        await _runs.CreateAsync(run, ct);

        var materialized = MaterializeJobs(definition, run, ev);

        // Determine which base job names have at least one runnable (non-skipped) instance.
        var baseNamesWithJobs = materialized
            .Select(m => m.BaseName)
            .ToHashSet(StringComparer.Ordinal);

        foreach (var item in materialized)
        {
            await _jobs.CreateAsync(item.Job, ct);
            await _steps.CreateManyAsync(item.Steps, ct);
        }

        // Enqueue root jobs (no needs that map to actual jobs); rest stay Pending.
        foreach (var item in materialized)
        {
            var hasUnmetNeeds = item.Job.Needs.Any(baseNamesWithJobs.Contains);
            if (!hasUnmetNeeds)
            {
                await _jobs.UpdateStatusAsync(item.Job.Id, JobStatus.Queued, null, null, ct);
                await _queue.EnqueueAsync(item.Job.Id, ct);
            }
        }

        await _runs.UpdateStatusAsync(run.Id, RunStatus.Running, now, null, ct);
        _logger.LogInformation("Created run {RunId} for pipeline {PipelineId} with {JobCount} jobs",
            run.Id, pipelineId, materialized.Count);

        return run.Id;
    }

    public async Task OnJobFinishedAsync(JobId jobId, JobStatus result, CancellationToken ct)
    {
        var job = await _jobs.GetAsync(jobId, ct);
        if (job is null)
        {
            _logger.LogWarning("OnJobFinished for unknown job {JobId}", jobId);
            return;
        }

        // Retry: re-enqueue a fresh attempt if failed and attempts remain.
        if (result == JobStatus.Failed && job.Attempt < job.MaxRetries)
        {
            var nextAttempt = job.Attempt + 1;
            await _jobs.UpdateAttemptAsync(jobId, nextAttempt, ct);
            await _jobs.UpdateStatusAsync(jobId, JobStatus.Queued, null, null, ct);
            await _queue.EnqueueAsync(jobId, ct);
            _logger.LogInformation("Re-enqueued job {JobId} attempt {Attempt}/{Max}",
                jobId, nextAttempt, job.MaxRetries);
            return;
        }

        await _jobs.UpdateStatusAsync(jobId, result, job.StartedAt, _clock.GetUtcNow(), ct);

        var run = await _runs.GetAsync(job.RunId, ct);
        var variables = await LoadVariablesAsync(run, ct);

        var allJobs = await _jobs.ListByRunAsync(job.RunId, ct);
        await EvaluateDependentsAsync(job, allJobs, run, variables, ct);

        // Reload after potential dependent updates to decide run finalization.
        allJobs = await _jobs.ListByRunAsync(job.RunId, ct);
        await FinalizeRunIfTerminalAsync(job.RunId, allJobs, ct);
    }

    private async Task<IReadOnlyDictionary<string, string>> LoadVariablesAsync(Run? run, CancellationToken ct)
    {
        if (run is null)
        {
            return new Dictionary<string, string>();
        }

        try
        {
            var definition = await _definitionSource.GetDefinitionAsync(run.PipelineId, run.CommitSha, ct);
            return definition.Variables;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not load variables for run {RunId}", run.Id);
            return new Dictionary<string, string>();
        }
    }

    private async Task EvaluateDependentsAsync(
        Job finished,
        IReadOnlyList<Job> allJobs,
        Run? run,
        IReadOnlyDictionary<string, string> variables,
        CancellationToken ct)
    {
        var byBaseName = allJobs
            .GroupBy(BaseName, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);

        var finishedBase = BaseName(finished);

        var dependents = allJobs
            .Where(j => j.Status == JobStatus.Pending && j.Needs.Contains(finishedBase))
            .ToList();

        foreach (var dependent in dependents)
        {
            await TryAdvanceDependentAsync(dependent, byBaseName, run, variables, ct);
        }
    }

    private async Task TryAdvanceDependentAsync(
        Job dependent,
        IReadOnlyDictionary<string, List<Job>> byBaseName,
        Run? run,
        IReadOnlyDictionary<string, string> variables,
        CancellationToken ct)
    {
        var needStatuses = new List<JobStatus>();
        foreach (var need in dependent.Needs)
        {
            if (byBaseName.TryGetValue(need, out var needJobs))
            {
                needStatuses.AddRange(needJobs.Select(j => j.Status));
            }
        }

        // Matrix fan-in: wait until every needed instance is terminal.
        if (needStatuses.Any(s => !RunStateMachine.IsTerminal(s)))
        {
            return;
        }

        var anyBlocked = needStatuses.Any(s =>
            s is JobStatus.Failed or JobStatus.Skipped or JobStatus.Canceled);

        if (anyBlocked)
        {
            await SkipRecursivelyAsync(dependent, byBaseName, ct);
            return;
        }

        // All needs succeeded: evaluate the dependent's `if` (skip if false), else enqueue.
        if (!EvaluateJobIf(dependent, byBaseName, run, variables))
        {
            await SkipRecursivelyAsync(dependent, byBaseName, ct);
            return;
        }

        await _jobs.UpdateStatusAsync(dependent.Id, JobStatus.Queued, null, null, ct);
        await _queue.EnqueueAsync(dependent.Id, ct);
    }

    private async Task SkipRecursivelyAsync(
        Job job,
        IReadOnlyDictionary<string, List<Job>> byBaseName,
        CancellationToken ct)
    {
        if (RunStateMachine.IsTerminal(job.Status))
        {
            return;
        }

        await _jobs.UpdateStatusAsync(job.Id, JobStatus.Skipped, null, _clock.GetUtcNow(), ct);

        // Reflect the new status in the local view, then cascade to dependents.
        var skipped = job with { Status = JobStatus.Skipped };
        UpdateLocal(byBaseName, skipped);

        var skippedBase = BaseName(job);
        var dependents = byBaseName.Values
            .SelectMany(list => list)
            .Where(j => j.Status == JobStatus.Pending && j.Needs.Contains(skippedBase))
            .ToList();

        foreach (var dependent in dependents)
        {
            await SkipRecursivelyAsync(dependent, byBaseName, ct);
        }
    }

    private async Task FinalizeRunIfTerminalAsync(RunId runId, IReadOnlyList<Job> allJobs, CancellationToken ct)
    {
        if (allJobs.Any(j => !RunStateMachine.IsTerminal(j.Status)))
        {
            return;
        }

        var run = await _runs.GetAsync(runId, ct);
        if (run is null || RunStateMachine.IsTerminal(run.Status))
        {
            return;
        }

        RunStatus finalStatus;
        if (allJobs.Any(j => j.Status == JobStatus.Canceled))
        {
            finalStatus = RunStatus.Canceled;
        }
        else if (allJobs.Any(j => j.Status == JobStatus.Failed))
        {
            finalStatus = RunStatus.Failed;
        }
        else
        {
            // Succeeded iff all non-skipped jobs succeeded.
            finalStatus = RunStatus.Succeeded;
        }

        await _runs.UpdateStatusAsync(runId, finalStatus, run.StartedAt, _clock.GetUtcNow(), ct);
        _logger.LogInformation("Run {RunId} finalized as {Status}", runId, finalStatus);
    }

    private bool EvaluateJobIf(
        Job job,
        IReadOnlyDictionary<string, List<Job>> byBaseName,
        Run? run,
        IReadOnlyDictionary<string, string> variables)
    {
        if (string.IsNullOrWhiteSpace(job.If))
        {
            return true;
        }

        // Map each needed base job to a single status (worst-case for matrix fan-in).
        var statuses = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var (baseName, jobs) in byBaseName)
        {
            statuses[baseName] = AggregateStatus(jobs);
        }

        var context = new ExpressionContext
        {
            Branch = run?.Branch ?? string.Empty,
            Event = run?.TriggerOn ?? string.Empty,
            JobStatuses = statuses,
            Vars = variables,
            Inputs = run?.Inputs ?? new Dictionary<string, string>(),
            Matrix = job.MatrixValues ?? new Dictionary<string, string>()
        };

        try
        {
            return ExpressionEvaluator.EvaluateBool(job.If, context);
        }
        catch (ExpressionException ex)
        {
            _logger.LogWarning(ex, "Failed to evaluate 'if' for job {JobId}; skipping", job.Id);
            return false;
        }
    }

    private static string AggregateStatus(IReadOnlyList<Job> jobs)
    {
        if (jobs.Any(j => j.Status is JobStatus.Failed or JobStatus.Canceled))
        {
            return "failed";
        }

        if (jobs.Any(j => j.Status == JobStatus.Skipped))
        {
            return "skipped";
        }

        if (jobs.All(j => j.Status == JobStatus.Succeeded))
        {
            return "success";
        }

        return "pending";
    }

    private static IReadOnlyList<MaterializedJob> MaterializeJobs(
        PipelineDefinition definition,
        Run run,
        TriggerEvent ev)
    {
        var result = new List<MaterializedJob>();

        foreach (var (jobName, jobDef) in definition.Jobs)
        {
            var resolved = jobDef.Resolve(definition.Defaults);
            var combinations = resolved.Matrix is null
                ? [new Dictionary<string, string>()]
                : MatrixExpander.Expand(resolved.Matrix);

            foreach (var combination in combinations)
            {
                var name = MatrixExpander.JobName(jobName, combination);
                var image = resolved.Image;
                if (image is not null && combination.Count > 0)
                {
                    var ctx = new ExpressionContext { Matrix = combination };
                    image = ExpressionEvaluator.Interpolate(image, ctx);
                }

                var jobId = JobId.New();
                var job = new Job
                {
                    Id = jobId,
                    RunId = run.Id,
                    Name = name,
                    Executor = resolved.Executor,
                    Image = image,
                    Needs = resolved.Needs,
                    If = resolved.If,
                    MatrixValues = combination.Count > 0 ? combination : null,
                    Status = JobStatus.Pending,
                    Attempt = 0,
                    MaxRetries = resolved.Retries,
                    Timeout = resolved.Timeout
                };

                var steps = resolved.Steps
                    .Select((step, index) => new StepRecord
                    {
                        Id = StepId.New(),
                        JobId = jobId,
                        Ordinal = index,
                        Name = step.Name ?? step.Run ?? step.Uses ?? $"step-{index}",
                        Status = StepStatus.Pending
                    })
                    .ToList();

                result.Add(new MaterializedJob(jobName, job, steps));
            }
        }

        return result;
    }

    private static string BaseName(Job job)
    {
        var index = job.Name.IndexOf(" (", StringComparison.Ordinal);
        return index < 0 ? job.Name : job.Name[..index];
    }

    private static void UpdateLocal(IReadOnlyDictionary<string, List<Job>> byBaseName, Job updated)
    {
        var key = BaseName(updated);
        if (!byBaseName.TryGetValue(key, out var list))
        {
            return;
        }

        for (var i = 0; i < list.Count; i++)
        {
            if (list[i].Id == updated.Id)
            {
                list[i] = updated;
                return;
            }
        }
    }

    private sealed record MaterializedJob(string BaseName, Job Job, IReadOnlyList<StepRecord> Steps);
}
