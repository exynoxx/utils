using System.Collections.Concurrent;
using Cicd.Core.Domain;

namespace Cicd.Core.Execution;

/// <summary>
/// Tracks cancellation tokens per run so the cancel API can signal running workers.
/// </summary>
public interface ICancellationRegistry
{
    /// <summary>Registers a run and returns a token that is canceled when the run is canceled.</summary>
    CancellationToken Register(RunId runId);

    void Cancel(RunId runId);

    bool IsCanceled(RunId runId);

    void Remove(RunId runId);
}

/// <summary>In-memory <see cref="ICancellationRegistry"/>.</summary>
public sealed class CancellationRegistry : ICancellationRegistry
{
    private readonly ConcurrentDictionary<Guid, CancellationTokenSource> _sources = new();

    public CancellationToken Register(RunId runId)
    {
        var source = _sources.GetOrAdd(runId.Value, _ => new CancellationTokenSource());
        return source.Token;
    }

    public void Cancel(RunId runId)
    {
        if (_sources.TryGetValue(runId.Value, out var source))
        {
            source.Cancel();
        }
        else
        {
            // Register pre-canceled so a worker that starts later sees the cancellation.
            var preCanceled = new CancellationTokenSource();
            preCanceled.Cancel();
            _sources.TryAdd(runId.Value, preCanceled);
        }
    }

    public bool IsCanceled(RunId runId)
    {
        return _sources.TryGetValue(runId.Value, out var source) && source.IsCancellationRequested;
    }

    public void Remove(RunId runId)
    {
        if (_sources.TryRemove(runId.Value, out var source))
        {
            source.Dispose();
        }
    }
}
