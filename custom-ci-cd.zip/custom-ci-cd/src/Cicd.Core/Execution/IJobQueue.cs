using Cicd.Core.Domain;

namespace Cicd.Core.Execution;

/// <summary>A job claimed from the queue by a worker.</summary>
public sealed record ClaimedJob(JobId JobId, RunId RunId, int Attempt, DateTimeOffset LeaseExpiresAt);

/// <summary>
/// The execution queue. Backed by Postgres (FOR UPDATE SKIP LOCKED) in production; the scheduler
/// enqueues runnable jobs and workers claim/complete them.
/// </summary>
public interface IJobQueue
{
    Task EnqueueAsync(JobId jobId, CancellationToken ct);

    Task<ClaimedJob?> ClaimNextAsync(WorkerId worker, CancellationToken ct);

    Task CompleteAsync(JobId jobId, JobStatus status, CancellationToken ct);

    /// <summary>Heartbeat to extend the claim lease. Returns false if the claim was lost.</summary>
    Task<bool> RenewLeaseAsync(JobId jobId, WorkerId worker, CancellationToken ct);
}
