namespace Cicd.Core.Domain;

/// <summary>
/// Central authority for status transitions of runs, jobs and steps.
/// </summary>
public static class RunStateMachine
{
    public static bool CanTransition(RunStatus from, RunStatus to)
    {
        if (from == to)
        {
            return false;
        }

        return from switch
        {
            RunStatus.Queued => to is RunStatus.Running or RunStatus.Canceled,
            RunStatus.Running => to is RunStatus.Succeeded or RunStatus.Failed or RunStatus.Canceled,
            _ => false
        };
    }

    public static bool CanTransition(JobStatus from, JobStatus to)
    {
        if (from == to)
        {
            return false;
        }

        return from switch
        {
            JobStatus.Pending => to is JobStatus.Queued or JobStatus.Skipped or JobStatus.Canceled,
            JobStatus.Queued => to is JobStatus.Running or JobStatus.Skipped or JobStatus.Canceled,
            JobStatus.Running => to is JobStatus.Succeeded or JobStatus.Failed or JobStatus.Canceled
                or JobStatus.Queued, // re-enqueue for retry
            _ => false
        };
    }

    public static bool CanTransition(StepStatus from, StepStatus to)
    {
        if (from == to)
        {
            return false;
        }

        return from switch
        {
            StepStatus.Pending => to is StepStatus.Running or StepStatus.Skipped,
            StepStatus.Running => to is StepStatus.Succeeded or StepStatus.Failed,
            _ => false
        };
    }

    public static bool IsTerminal(RunStatus status)
    {
        return status is RunStatus.Succeeded or RunStatus.Failed or RunStatus.Canceled;
    }

    public static bool IsTerminal(JobStatus status)
    {
        return status is JobStatus.Succeeded or JobStatus.Failed or JobStatus.Skipped or JobStatus.Canceled;
    }

    public static bool IsTerminal(StepStatus status)
    {
        return status is StepStatus.Succeeded or StepStatus.Failed or StepStatus.Skipped;
    }
}
