namespace Cicd.Core.Domain;

/// <summary>
/// A registered pipeline. Either repo-backed (<see cref="RepoUrl"/>) or standalone (<see cref="RawYaml"/>).
/// </summary>
public sealed record Pipeline
{
    public required PipelineId Id { get; init; }
    public required string Name { get; init; }
    public string? RepoUrl { get; init; }
    public string? RawYaml { get; init; }
    public DateTimeOffset CreatedAt { get; init; }
}

/// <summary>
/// A single execution of a pipeline.
/// </summary>
public sealed record Run
{
    public required RunId Id { get; init; }
    public required PipelineId PipelineId { get; init; }
    public required string TriggerOn { get; init; }
    public required string Branch { get; init; }
    public required string CommitSha { get; init; }
    public IReadOnlyDictionary<string, string> Inputs { get; init; } =
        new Dictionary<string, string>();
    public RunStatus Status { get; init; } = RunStatus.Queued;
    public DateTimeOffset CreatedAt { get; init; }
    public DateTimeOffset? StartedAt { get; init; }
    public DateTimeOffset? FinishedAt { get; init; }
}

/// <summary>
/// A materialized job within a run (one per matrix combination after fan-out).
/// </summary>
public sealed record Job
{
    public required JobId Id { get; init; }
    public required RunId RunId { get; init; }
    public required string Name { get; init; }
    public required string Executor { get; init; }
    public string? Image { get; init; }

    /// <summary>Job names within the same run that must succeed first.</summary>
    public IReadOnlyList<string> Needs { get; init; } = [];

    /// <summary>The job's <c>if</c> condition expression, if any (evaluated by the scheduler).</summary>
    public string? If { get; init; }

    /// <summary>Resolved matrix axis values for this job, if it came from a matrix expansion.</summary>
    public IReadOnlyDictionary<string, string>? MatrixValues { get; init; }

    public JobStatus Status { get; init; } = JobStatus.Pending;
    public int Attempt { get; init; }
    public int MaxRetries { get; init; }
    public TimeSpan Timeout { get; init; } = TimeSpan.FromMinutes(30);

    public WorkerId? ClaimedBy { get; init; }
    public DateTimeOffset? LeaseExpiresAt { get; init; }
    public long LogSize { get; init; }
    public DateTimeOffset? StartedAt { get; init; }
    public DateTimeOffset? FinishedAt { get; init; }
}

/// <summary>
/// A persisted, lightweight step row. The full step definition lives in the parsed JobDefinition.
/// </summary>
public sealed record StepRecord
{
    public required StepId Id { get; init; }
    public required JobId JobId { get; init; }
    public required int Ordinal { get; init; }
    public required string Name { get; init; }
    public StepStatus Status { get; init; } = StepStatus.Pending;
    public int? ExitCode { get; init; }
    public DateTimeOffset? StartedAt { get; init; }
    public DateTimeOffset? FinishedAt { get; init; }
}
