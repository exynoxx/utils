namespace Cicd.Core.Domain;

/// <summary>
/// Base type for value objects backed by a non-empty, non-whitespace string.
/// </summary>
public abstract record NonEmptyStringValue
{
    public string Value { get; init; }

    protected NonEmptyStringValue(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException("Value must not be empty or whitespace.", nameof(value));
        }

        Value = value;
    }

    public override string ToString()
    {
        return Value;
    }
}

public sealed record PipelineName(string Value) : NonEmptyStringValue(Value);

public sealed record JobName(string Value) : NonEmptyStringValue(Value);
