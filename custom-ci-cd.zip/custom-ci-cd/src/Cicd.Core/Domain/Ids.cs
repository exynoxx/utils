namespace Cicd.Core.Domain;

/// <summary>
/// Base type for value-object identifiers backed by a non-empty <see cref="Guid"/>.
/// </summary>
public abstract record NonEmptyGuidValue
{
    public Guid Value { get; init; }

    protected NonEmptyGuidValue(Guid value)
    {
        if (value == Guid.Empty)
        {
            throw new ArgumentException("Guid must not be empty.", nameof(value));
        }

        Value = value;
    }

    public override string ToString()
    {
        return Value.ToString();
    }
}

public sealed record PipelineId(Guid Value) : NonEmptyGuidValue(Value)
{
    public static PipelineId New()
    {
        return new PipelineId(Guid.CreateVersion7());
    }
}

public sealed record RunId(Guid Value) : NonEmptyGuidValue(Value)
{
    public static RunId New()
    {
        return new RunId(Guid.CreateVersion7());
    }
}

public sealed record JobId(Guid Value) : NonEmptyGuidValue(Value)
{
    public static JobId New()
    {
        return new JobId(Guid.CreateVersion7());
    }
}

public sealed record StepId(Guid Value) : NonEmptyGuidValue(Value)
{
    public static StepId New()
    {
        return new StepId(Guid.CreateVersion7());
    }
}

public sealed record WorkerId(Guid Value) : NonEmptyGuidValue(Value)
{
    public static WorkerId New()
    {
        return new WorkerId(Guid.CreateVersion7());
    }
}

public sealed record SecretId(Guid Value) : NonEmptyGuidValue(Value)
{
    public static SecretId New()
    {
        return new SecretId(Guid.CreateVersion7());
    }
}

public sealed record ArtifactId(Guid Value) : NonEmptyGuidValue(Value)
{
    public static ArtifactId New()
    {
        return new ArtifactId(Guid.CreateVersion7());
    }
}
