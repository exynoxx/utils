namespace Cicd.Core.Domain;

public enum RunStatus
{
    Queued,
    Running,
    Succeeded,
    Failed,
    Canceled
}

public enum JobStatus
{
    Pending,
    Queued,
    Running,
    Succeeded,
    Failed,
    Skipped,
    Canceled
}

public enum StepStatus
{
    Pending,
    Running,
    Succeeded,
    Failed,
    Skipped
}
