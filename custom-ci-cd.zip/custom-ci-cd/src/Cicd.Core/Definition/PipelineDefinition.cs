namespace Cicd.Core.Definition;

/// <summary>
/// Immutable pipeline model — post-validation, post-template-expansion.
/// </summary>
public sealed record PipelineDefinition
{
    public required int Version { get; init; }
    public required string Name { get; init; }
    public required IReadOnlyList<TriggerDefinition> Triggers { get; init; }
    public required JobDefaults Defaults { get; init; }
    public required IReadOnlyDictionary<string, string> Variables { get; init; }
    public required IReadOnlyDictionary<string, JobDefinition> Jobs { get; init; }
}

public sealed record ParseError(string Message, int? Line, int? Column);

public sealed record ParseResult(PipelineDefinition? Definition, IReadOnlyList<ParseError> Errors)
{
    public bool Success => Definition is not null && Errors.Count == 0;
}

public interface IPipelineParser
{
    ParseResult Parse(string yaml);
}
