namespace Cicd.Core.Definition;

public enum InputType
{
    String,
    Enum,
    Bool
}

/// <summary>
/// A typed input declaration shared by <c>on: manual</c> triggers and step templates.
/// </summary>
public sealed record InputDefinition
{
    public required InputType Type { get; init; }
    public IReadOnlyList<string> Values { get; init; } = [];
    public string? Default { get; init; }
    public bool Required { get; init; }
}
