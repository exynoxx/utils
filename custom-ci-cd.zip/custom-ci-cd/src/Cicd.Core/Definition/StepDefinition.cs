namespace Cicd.Core.Definition;

/// <summary>
/// A single step. Bottoms out in "run commands in a container". Exactly one of
/// <see cref="Run"/> or <see cref="Uses"/> is set after validation.
/// </summary>
public sealed record StepDefinition
{
    public string? Name { get; init; }
    public string? Run { get; init; }

    /// <summary>Built-in step type or template reference.</summary>
    public string? Uses { get; init; }

    public IReadOnlyDictionary<string, string> With { get; init; } =
        new Dictionary<string, string>();

    /// <summary>Per-step image override.</summary>
    public string? Image { get; init; }

    public IReadOnlyDictionary<string, string> Env { get; init; } =
        new Dictionary<string, string>();

    public string? Workdir { get; init; }
    public string? If { get; init; }
}
