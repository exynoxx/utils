using Cicd.Core.Definition.Expressions;
using Cicd.Core.Definition.Templates;
using Cicd.Core.Definition.Yaml;
using Cronos;
using YamlDotNet.RepresentationModel;

namespace Cicd.Core.Definition;

/// <summary>
/// Parses a pipeline YAML document into a validated <see cref="PipelineDefinition"/>.
/// Parsing is done manually over the YAML representation model so validation errors carry
/// line/column information. Multiple errors are collected where practical.
/// </summary>
public sealed class PipelineParser : IPipelineParser
{
    private static readonly IReadOnlySet<string> KnownTriggers =
        new HashSet<string>(StringComparer.Ordinal) { "push", "schedule", "fileWatch", "manual" };

    private readonly TemplateExpander? _templateExpander;

    public PipelineParser(ITemplateResolver? templateResolver = null)
    {
        _templateExpander = templateResolver is null ? null : new TemplateExpander(templateResolver);
    }

    public ParseResult Parse(string yaml)
    {
        var errors = new List<ParseError>();

        var root = YamlReader.ParseDocument(yaml, out var line, out var column, out var yamlError);
        if (root is null)
        {
            errors.Add(new ParseError(yamlError ?? "Invalid YAML.", line, column));
            return new ParseResult(null, errors);
        }

        var version = ParseVersion(root, errors);
        var name = YamlReader.GetScalar(root, "name") ?? "pipeline";
        var triggers = ParseTriggers(root, errors);
        var defaults = ParseDefaults(root, errors);
        var variables = YamlReader.GetStringMap(root, "variables");
        var jobs = ParseJobs(root, defaults, errors);

        if (jobs.Count == 0)
        {
            errors.Add(new ParseError("Pipeline must declare at least one job.", null, null));
        }

        ValidateNeedsAndDag(jobs, errors);

        if (errors.Count > 0)
        {
            return new ParseResult(null, errors);
        }

        var definition = new PipelineDefinition
        {
            Version = version,
            Name = name,
            Triggers = triggers,
            Defaults = defaults,
            Variables = variables,
            Jobs = jobs
        };

        return new ParseResult(definition, errors);
    }

    private int ParseVersion(YamlMappingNode root, List<ParseError> errors)
    {
        var node = YamlReader.Get(root, "version");
        if (node is not YamlScalarNode scalar || !int.TryParse(scalar.Value, out var version))
        {
            var (l, c) = node is null ? YamlReader.Mark(root) : YamlReader.Mark(node);
            errors.Add(new ParseError("'version' is required and must be the integer 1.", l, c));
            return 0;
        }

        if (version != 1)
        {
            var (l, c) = YamlReader.Mark(node);
            errors.Add(new ParseError($"Unsupported version '{version}'. Only version 1 is supported.", l, c));
        }

        return version;
    }

    private IReadOnlyList<TriggerDefinition> ParseTriggers(YamlMappingNode root, List<ParseError> errors)
    {
        var result = new List<TriggerDefinition>();
        if (YamlReader.Get(root, "triggers") is not YamlSequenceNode triggers)
        {
            return result;
        }

        foreach (var item in triggers.Children)
        {
            if (item is not YamlMappingNode map)
            {
                var (l, c) = YamlReader.Mark(item);
                errors.Add(new ParseError("Each trigger must be a mapping.", l, c));
                continue;
            }

            var on = YamlReader.GetScalar(map, "on");
            var (ml, mc) = YamlReader.Mark(map);
            if (on is null)
            {
                errors.Add(new ParseError("Trigger is missing 'on'.", ml, mc));
                continue;
            }

            if (!KnownTriggers.Contains(on))
            {
                errors.Add(new ParseError(
                    $"Unknown trigger 'on: {on}'. Expected one of: {string.Join(", ", KnownTriggers)}.", ml, mc));
                continue;
            }

            var trigger = ParseTrigger(on, map, errors);
            if (trigger is not null)
            {
                result.Add(trigger);
            }
        }

        return result;
    }

    private TriggerDefinition? ParseTrigger(string on, YamlMappingNode map, List<ParseError> errors)
    {
        switch (on)
        {
            case "push":
                return new PushTriggerDefinition
                {
                    On = on,
                    Branches = YamlReader.GetStringList(map, "branches"),
                    Paths = YamlReader.GetStringList(map, "paths")
                };
            case "schedule":
            {
                var cron = YamlReader.GetScalar(map, "cron");
                var (l, c) = YamlReader.Mark(map);
                if (cron is null)
                {
                    errors.Add(new ParseError("Schedule trigger requires 'cron'.", l, c));
                    return null;
                }

                try
                {
                    CronExpression.Parse(cron);
                }
                catch (CronFormatException ex)
                {
                    errors.Add(new ParseError($"Invalid cron expression '{cron}': {ex.Message}", l, c));
                    return null;
                }

                return new ScheduleTriggerDefinition { On = on, Cron = cron };
            }
            case "fileWatch":
            {
                var debounce = TimeSpan.FromMilliseconds(800);
                var debounceText = YamlReader.GetScalar(map, "debounce");
                if (debounceText is not null)
                {
                    if (!DurationParser.TryParse(debounceText, out debounce, out var derr))
                    {
                        var (l, c) = YamlReader.Mark(map);
                        errors.Add(new ParseError(derr!, l, c));
                    }
                }

                return new FileWatchTriggerDefinition
                {
                    On = on,
                    Directories = YamlReader.GetStringList(map, "directories"),
                    Patterns = YamlReader.GetStringList(map, "patterns"),
                    Debounce = debounce
                };
            }
            case "manual":
                return new ManualTriggerDefinition
                {
                    On = on,
                    Inputs = ParseInputs(map, errors)
                };
            default:
                return null;
        }
    }

    private IReadOnlyDictionary<string, InputDefinition> ParseInputs(YamlMappingNode map, List<ParseError> errors)
    {
        var result = new Dictionary<string, InputDefinition>();
        if (YamlReader.Get(map, "inputs") is not YamlMappingNode inputs)
        {
            return result;
        }

        foreach (var pair in inputs.Children)
        {
            if (pair.Key is not YamlScalarNode keyNode || keyNode.Value is null ||
                pair.Value is not YamlMappingNode spec)
            {
                continue;
            }

            var typeText = YamlReader.GetScalar(spec, "type") ?? "string";
            InputType type;
            switch (typeText)
            {
                case "string":
                    type = InputType.String;
                    break;
                case "enum":
                    type = InputType.Enum;
                    break;
                case "bool":
                    type = InputType.Bool;
                    break;
                default:
                    var (l, c) = YamlReader.Mark(spec);
                    errors.Add(new ParseError(
                        $"Input '{keyNode.Value}' has invalid type '{typeText}' (expected string, enum, or bool).", l, c));
                    continue;
            }

            result[keyNode.Value] = new InputDefinition
            {
                Type = type,
                Values = YamlReader.GetStringList(spec, "values"),
                Default = YamlReader.GetScalar(spec, "default"),
                Required = string.Equals(YamlReader.GetScalar(spec, "required"), "true", StringComparison.OrdinalIgnoreCase)
            };
        }

        return result;
    }

    private JobDefaults ParseDefaults(YamlMappingNode root, List<ParseError> errors)
    {
        if (YamlReader.Get(root, "defaults") is not YamlMappingNode map)
        {
            return new JobDefaults();
        }

        TimeSpan? timeout = null;
        var timeoutText = YamlReader.GetScalar(map, "timeout");
        if (timeoutText is not null)
        {
            if (DurationParser.TryParse(timeoutText, out var parsed, out var derr))
            {
                timeout = parsed;
            }
            else
            {
                var (l, c) = YamlReader.Mark(map);
                errors.Add(new ParseError(derr!, l, c));
            }
        }

        return new JobDefaults
        {
            Executor = YamlReader.GetScalar(map, "executor"),
            Image = YamlReader.GetScalar(map, "image"),
            Timeout = timeout
        };
    }

    private IReadOnlyDictionary<string, JobDefinition> ParseJobs(
        YamlMappingNode root,
        JobDefaults defaults,
        List<ParseError> errors)
    {
        var result = new Dictionary<string, JobDefinition>();
        if (YamlReader.Get(root, "jobs") is not YamlMappingNode jobs)
        {
            return result;
        }

        foreach (var pair in jobs.Children)
        {
            if (pair.Key is not YamlScalarNode keyNode || keyNode.Value is null ||
                pair.Value is not YamlMappingNode jobMap)
            {
                continue;
            }

            var job = ParseJob(keyNode.Value, jobMap, defaults, errors);
            if (job is not null)
            {
                result[keyNode.Value] = job;
            }
        }

        return result;
    }

    private JobDefinition? ParseJob(
        string jobName,
        YamlMappingNode map,
        JobDefaults defaults,
        List<ParseError> errors)
    {
        var (jl, jc) = YamlReader.Mark(map);

        var steps = ParseSteps(jobName, map, errors);
        if (_templateExpander is not null)
        {
            try
            {
                steps = _templateExpander.Expand(steps);
            }
            catch (TemplateException ex)
            {
                errors.Add(new ParseError($"Job '{jobName}': {ex.Message}", jl, jc));
            }
        }
        // No resolver configured (e.g. standalone validation): template references are left
        // unexpanded — they resolve at run time when the workspace source provides them.

        if (steps.Count == 0)
        {
            errors.Add(new ParseError($"Job '{jobName}' must declare at least one step.", jl, jc));
        }

        var executor = YamlReader.GetScalar(map, "executor");
        var image = YamlReader.GetScalar(map, "image");
        var effectiveExecutor = executor ?? defaults.Executor ?? "docker";
        var effectiveImage = image ?? defaults.Image;

        if (string.Equals(effectiveExecutor, "docker", StringComparison.Ordinal) && effectiveImage is null)
        {
            errors.Add(new ParseError(
                $"Job '{jobName}' uses the docker executor but no image is set (job or defaults).", jl, jc));
        }

        TimeSpan? timeout = ParseDuration(map, "timeout", jobName, errors);

        var retries = 0;
        var retriesText = YamlReader.GetScalar(map, "retries");
        if (retriesText is not null && !int.TryParse(retriesText, out retries))
        {
            errors.Add(new ParseError($"Job '{jobName}' has a non-integer 'retries' value.", jl, jc));
        }

        var ifExpr = YamlReader.GetScalar(map, "if");
        if (ifExpr is not null)
        {
            var syntaxError = ExpressionEvaluator.ValidateSyntax(ifExpr);
            if (syntaxError is not null)
            {
                errors.Add(new ParseError($"Job '{jobName}' has an invalid 'if' expression: {syntaxError}", jl, jc));
            }
        }

        return new JobDefinition
        {
            Executor = executor,
            Image = image,
            Steps = steps,
            Needs = YamlReader.GetStringList(map, "needs"),
            If = ifExpr,
            Env = YamlReader.GetStringMap(map, "env"),
            Caches = ParseCaches(map, jobName, errors),
            Artifacts = ParseArtifacts(map, jobName, errors),
            Timeout = timeout,
            Retries = retries,
            Matrix = ParseMatrix(map),
            Services = ParseServices(map)
        };
    }

    private IReadOnlyList<StepDefinition> ParseSteps(string jobName, YamlMappingNode map, List<ParseError> errors)
    {
        var result = new List<StepDefinition>();
        if (YamlReader.Get(map, "steps") is not YamlSequenceNode steps)
        {
            return result;
        }

        var ordinal = 0;
        foreach (var item in steps.Children)
        {
            ordinal++;

            if (item is YamlScalarNode)
            {
                var (sl, sc) = YamlReader.Mark(item);
                errors.Add(new ParseError($"Job '{jobName}' step {ordinal} must be a mapping.", sl, sc));
                continue;
            }

            if (item is not YamlMappingNode stepMap)
            {
                continue;
            }

            var run = YamlReader.GetScalar(stepMap, "run");
            var uses = YamlReader.GetScalar(stepMap, "uses");
            var (l, c) = YamlReader.Mark(stepMap);

            if (run is null && uses is null)
            {
                errors.Add(new ParseError($"Job '{jobName}' step {ordinal} must have exactly one of 'run' or 'uses'.", l, c));
            }
            else if (run is not null && uses is not null)
            {
                errors.Add(new ParseError($"Job '{jobName}' step {ordinal} cannot have both 'run' and 'uses'.", l, c));
            }

            var ifExpr = YamlReader.GetScalar(stepMap, "if");
            if (ifExpr is not null)
            {
                var syntaxError = ExpressionEvaluator.ValidateSyntax(ifExpr);
                if (syntaxError is not null)
                {
                    errors.Add(new ParseError(
                        $"Job '{jobName}' step {ordinal} has an invalid 'if' expression: {syntaxError}", l, c));
                }
            }

            result.Add(new StepDefinition
            {
                Name = YamlReader.GetScalar(stepMap, "name"),
                Run = run,
                Uses = uses,
                With = YamlReader.GetStringMap(stepMap, "with"),
                Image = YamlReader.GetScalar(stepMap, "image"),
                Env = YamlReader.GetStringMap(stepMap, "env"),
                Workdir = YamlReader.GetScalar(stepMap, "workdir"),
                If = ifExpr
            });
        }

        return result;
    }

    private IReadOnlyList<CacheDefinition> ParseCaches(YamlMappingNode map, string jobName, List<ParseError> errors)
    {
        var node = YamlReader.Get(map, "cache");
        if (node is null)
        {
            return [];
        }

        var result = new List<CacheDefinition>();

        switch (node)
        {
            case YamlMappingNode single:
                result.Add(ParseCache(single, jobName, errors));
                break;
            case YamlSequenceNode list:
                foreach (var item in list.Children)
                {
                    if (item is YamlMappingNode cacheMap)
                    {
                        result.Add(ParseCache(cacheMap, jobName, errors));
                    }
                }

                break;
        }

        return result;
    }

    private CacheDefinition ParseCache(YamlMappingNode map, string jobName, List<ParseError> errors)
    {
        var key = YamlReader.GetScalar(map, "key");
        if (key is null)
        {
            var (l, c) = YamlReader.Mark(map);
            errors.Add(new ParseError($"Job '{jobName}' cache entry requires a 'key'.", l, c));
            key = string.Empty;
        }

        return new CacheDefinition
        {
            Key = key,
            RestoreKeys = YamlReader.GetStringList(map, "restoreKeys"),
            Paths = YamlReader.GetStringList(map, "paths")
        };
    }

    private ArtifactsDefinition? ParseArtifacts(YamlMappingNode map, string jobName, List<ParseError> errors)
    {
        if (YamlReader.Get(map, "artifacts") is not YamlMappingNode artifacts)
        {
            return null;
        }

        TimeSpan? expire = null;
        var expireText = YamlReader.GetScalar(artifacts, "expire");
        if (expireText is not null)
        {
            if (DurationParser.TryParse(expireText, out var parsed, out var derr))
            {
                expire = parsed;
            }
            else
            {
                var (l, c) = YamlReader.Mark(artifacts);
                errors.Add(new ParseError($"Job '{jobName}' artifacts: {derr}", l, c));
            }
        }

        return new ArtifactsDefinition
        {
            Paths = YamlReader.GetStringList(artifacts, "paths"),
            Expire = expire
        };
    }

    private IReadOnlyDictionary<string, IReadOnlyList<string>>? ParseMatrix(YamlMappingNode map)
    {
        if (YamlReader.Get(map, "parallel") is not YamlMappingNode parallel)
        {
            return null;
        }

        if (YamlReader.Get(parallel, "matrix") is not YamlMappingNode matrix)
        {
            return null;
        }

        var result = new Dictionary<string, IReadOnlyList<string>>();
        foreach (var pair in matrix.Children)
        {
            if (pair.Key is YamlScalarNode axis && axis.Value is not null && pair.Value is YamlSequenceNode values)
            {
                var list = values.Children
                    .OfType<YamlScalarNode>()
                    .Where(v => v.Value is not null)
                    .Select(v => v.Value!)
                    .ToList();
                result[axis.Value] = list;
            }
        }

        return result.Count == 0 ? null : result;
    }

    private IReadOnlyList<ServiceDefinition> ParseServices(YamlMappingNode map)
    {
        if (YamlReader.Get(map, "services") is not YamlSequenceNode services)
        {
            return [];
        }

        var result = new List<ServiceDefinition>();
        foreach (var item in services.Children)
        {
            if (item is not YamlMappingNode svc)
            {
                continue;
            }

            var name = YamlReader.GetScalar(svc, "name");
            var image = YamlReader.GetScalar(svc, "image");
            if (name is null || image is null)
            {
                continue;
            }

            result.Add(new ServiceDefinition
            {
                Name = name,
                Image = image,
                Env = YamlReader.GetStringMap(svc, "env")
            });
        }

        return result;
    }

    private TimeSpan? ParseDuration(YamlMappingNode map, string key, string jobName, List<ParseError> errors)
    {
        var text = YamlReader.GetScalar(map, key);
        if (text is null)
        {
            return null;
        }

        if (DurationParser.TryParse(text, out var parsed, out var derr))
        {
            return parsed;
        }

        var (l, c) = YamlReader.Mark(map);
        errors.Add(new ParseError($"Job '{jobName}' {key}: {derr}", l, c));
        return null;
    }

    private void ValidateNeedsAndDag(IReadOnlyDictionary<string, JobDefinition> jobs, List<ParseError> errors)
    {
        foreach (var (jobName, job) in jobs)
        {
            foreach (var need in job.Needs)
            {
                if (!jobs.ContainsKey(need))
                {
                    errors.Add(new ParseError($"Job '{jobName}' needs unknown job '{need}'.", null, null));
                }
            }
        }

        var cycle = FindCycle(jobs);
        if (cycle is not null)
        {
            errors.Add(new ParseError($"Dependency cycle detected: {string.Join(" -> ", cycle)}.", null, null));
        }
    }

    private static IReadOnlyList<string>? FindCycle(IReadOnlyDictionary<string, JobDefinition> jobs)
    {
        var visiting = new HashSet<string>();
        var visited = new HashSet<string>();
        var stack = new List<string>();

        foreach (var job in jobs.Keys)
        {
            var cycle = Visit(job, jobs, visiting, visited, stack);
            if (cycle is not null)
            {
                return cycle;
            }
        }

        return null;
    }

    private static IReadOnlyList<string>? Visit(
        string job,
        IReadOnlyDictionary<string, JobDefinition> jobs,
        HashSet<string> visiting,
        HashSet<string> visited,
        List<string> stack)
    {
        if (visited.Contains(job))
        {
            return null;
        }

        if (!visiting.Add(job))
        {
            return null;
        }

        stack.Add(job);

        foreach (var need in jobs[job].Needs)
        {
            if (!jobs.ContainsKey(need))
            {
                continue;
            }

            if (visiting.Contains(need))
            {
                var startIndex = stack.IndexOf(need);
                var cycle = stack.Skip(startIndex).ToList();
                cycle.Add(need);
                return cycle;
            }

            var found = Visit(need, jobs, visiting, visited, stack);
            if (found is not null)
            {
                return found;
            }
        }

        stack.RemoveAt(stack.Count - 1);
        visiting.Remove(job);
        visited.Add(job);
        return null;
    }
}
