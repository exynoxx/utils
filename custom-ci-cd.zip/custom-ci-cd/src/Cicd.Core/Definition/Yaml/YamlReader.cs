using YamlDotNet.RepresentationModel;

namespace Cicd.Core.Definition.Yaml;

/// <summary>
/// Helpers for reading <see cref="YamlNode"/> trees with line/column marks and typed accessors.
/// </summary>
internal static class YamlReader
{
    public static YamlMappingNode? ParseDocument(string yaml, out int? line, out int? column, out string? error)
    {
        line = null;
        column = null;
        error = null;

        var stream = new YamlStream();
        try
        {
            using var reader = new StringReader(yaml);
            stream.Load(reader);
        }
        catch (YamlDotNet.Core.YamlException ex)
        {
            line = (int)ex.Start.Line;
            column = (int)ex.Start.Column;
            error = ex.Message;
            return null;
        }

        if (stream.Documents.Count == 0)
        {
            error = "YAML document is empty.";
            return null;
        }

        if (stream.Documents[0].RootNode is not YamlMappingNode root)
        {
            var node = stream.Documents[0].RootNode;
            line = (int)node.Start.Line;
            column = (int)node.Start.Column;
            error = "Top-level YAML node must be a mapping.";
            return null;
        }

        return root;
    }

    public static (int? Line, int? Column) Mark(YamlNode node)
    {
        return ((int)node.Start.Line, (int)node.Start.Column);
    }

    public static YamlNode? Get(YamlMappingNode map, string key)
    {
        return map.Children.TryGetValue(new YamlScalarNode(key), out var node) ? node : null;
    }

    public static string? GetScalar(YamlMappingNode map, string key)
    {
        return Get(map, key) is YamlScalarNode scalar ? scalar.Value : null;
    }

    public static IReadOnlyList<string> GetStringList(YamlMappingNode map, string key)
    {
        if (Get(map, key) is not YamlSequenceNode seq)
        {
            return [];
        }

        var result = new List<string>();
        foreach (var item in seq.Children)
        {
            if (item is YamlScalarNode scalar && scalar.Value is not null)
            {
                result.Add(scalar.Value);
            }
        }

        return result;
    }

    public static IReadOnlyDictionary<string, string> GetStringMap(YamlMappingNode map, string key)
    {
        if (Get(map, key) is not YamlMappingNode inner)
        {
            return new Dictionary<string, string>();
        }

        return ToStringMap(inner);
    }

    public static IReadOnlyDictionary<string, string> ToStringMap(YamlMappingNode map)
    {
        var result = new Dictionary<string, string>();
        foreach (var pair in map.Children)
        {
            if (pair.Key is YamlScalarNode keyNode && keyNode.Value is not null &&
                pair.Value is YamlScalarNode valueNode)
            {
                result[keyNode.Value] = valueNode.Value ?? string.Empty;
            }
        }

        return result;
    }
}
