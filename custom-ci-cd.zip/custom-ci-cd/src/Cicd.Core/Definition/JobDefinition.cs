namespace Cicd.Core.Definition;

/// <summary>
/// A Phase-3 service/sidecar declaration. Parsed but not yet supported by the executor.
/// </summary>
public sealed record ServiceDefinition
{
    public required string Name { get; init; }
    public required string Image { get; init; }
    public IReadOnlyDictionary<string, string> Env { get; init; } =
        new Dictionary<string, string>();
}

/// <summary>
/// Global, per-job-overridable defaults.
/// </summary>
public sealed record JobDefaults
{
    public string? Executor { get; init; }
    public string? Image { get; init; }
    public TimeSpan? Timeout { get; init; }
}

public sealed record JobDefinition
{
    public string? Executor { get; init; }
    public string? Image { get; init; }
    public IReadOnlyList<StepDefinition> Steps { get; init; } = [];
    public IReadOnlyList<string> Needs { get; init; } = [];
    public string? If { get; init; }
    public IReadOnlyDictionary<string, string> Env { get; init; } =
        new Dictionary<string, string>();
    public IReadOnlyList<CacheDefinition> Caches { get; init; } = [];
    public ArtifactsDefinition? Artifacts { get; init; }
    public TimeSpan? Timeout { get; init; }
    public int Retries { get; init; }

    /// <summary>From <c>parallel.matrix</c>: axis name → list of values.</summary>
    public IReadOnlyDictionary<string, IReadOnlyList<string>>? Matrix { get; init; }

    /// <summary>Parsed but not yet supported (Phase 3).</summary>
    public IReadOnlyList<ServiceDefinition> Services { get; init; } = [];

    /// <summary>
    /// Resolves effective executor/image/timeout by merging this job's values with the
    /// pipeline defaults and the built-in fallbacks (executor <c>docker</c>, timeout 30m).
    /// </summary>
    public ResolvedJobDefinition Resolve(JobDefaults defaults)
    {
        var executor = Executor ?? defaults.Executor ?? "docker";
        var image = Image ?? defaults.Image;
        var timeout = Timeout ?? defaults.Timeout ?? TimeSpan.FromMinutes(30);

        return new ResolvedJobDefinition
        {
            Executor = executor,
            Image = image,
            Timeout = timeout,
            Steps = Steps,
            Needs = Needs,
            If = If,
            Env = Env,
            Caches = Caches,
            Artifacts = Artifacts,
            Retries = Retries,
            Matrix = Matrix,
            Services = Services
        };
    }
}

/// <summary>
/// A job with executor/image/timeout already merged from defaults.
/// </summary>
public sealed record ResolvedJobDefinition
{
    public required string Executor { get; init; }
    public string? Image { get; init; }
    public required TimeSpan Timeout { get; init; }
    public IReadOnlyList<StepDefinition> Steps { get; init; } = [];
    public IReadOnlyList<string> Needs { get; init; } = [];
    public string? If { get; init; }
    public IReadOnlyDictionary<string, string> Env { get; init; } =
        new Dictionary<string, string>();
    public IReadOnlyList<CacheDefinition> Caches { get; init; } = [];
    public ArtifactsDefinition? Artifacts { get; init; }
    public int Retries { get; init; }
    public IReadOnlyDictionary<string, IReadOnlyList<string>>? Matrix { get; init; }
    public IReadOnlyList<ServiceDefinition> Services { get; init; } = [];
}
