using System.Text;

namespace Cicd.Core.Definition.Expressions;

internal enum TokenType
{
    Identifier,
    String,
    Dot,
    Comma,
    LParen,
    RParen,
    Eq,
    Neq,
    And,
    Or,
    Not,
    End
}

internal readonly record struct Token(TokenType Type, string Text);

/// <summary>
/// Hand-written lexer for the minimal expression language.
/// </summary>
internal sealed class ExpressionLexer
{
    private readonly string _source;
    private int _position;

    public ExpressionLexer(string source)
    {
        _source = source;
    }

    public List<Token> Tokenize()
    {
        var tokens = new List<Token>();

        while (true)
        {
            var token = NextToken();
            tokens.Add(token);
            if (token.Type == TokenType.End)
            {
                break;
            }
        }

        return tokens;
    }

    private Token NextToken()
    {
        SkipWhitespace();

        if (_position >= _source.Length)
        {
            return new Token(TokenType.End, string.Empty);
        }

        var c = _source[_position];

        switch (c)
        {
            case '.':
                _position++;
                return new Token(TokenType.Dot, ".");
            case ',':
                _position++;
                return new Token(TokenType.Comma, ",");
            case '(':
                _position++;
                return new Token(TokenType.LParen, "(");
            case ')':
                _position++;
                return new Token(TokenType.RParen, ")");
            case '\'':
            case '"':
                return ReadString(c);
            case '=':
                return ReadDouble('=', TokenType.Eq, "==");
            case '!':
                if (Peek(1) == '=')
                {
                    _position += 2;
                    return new Token(TokenType.Neq, "!=");
                }

                _position++;
                return new Token(TokenType.Not, "!");
            case '&':
                return ReadDouble('&', TokenType.And, "&&");
            case '|':
                return ReadDouble('|', TokenType.Or, "||");
        }

        if (char.IsLetter(c) || c == '_')
        {
            return ReadIdentifier();
        }

        throw new ExpressionException($"Unexpected character '{c}' at position {_position}.");
    }

    private Token ReadDouble(char expected, TokenType type, string text)
    {
        if (Peek(1) != expected)
        {
            throw new ExpressionException($"Expected '{text}' at position {_position}.");
        }

        _position += 2;
        return new Token(type, text);
    }

    private Token ReadString(char quote)
    {
        _position++; // opening quote
        var builder = new StringBuilder();

        while (_position < _source.Length && _source[_position] != quote)
        {
            if (_source[_position] == '\\' && _position + 1 < _source.Length)
            {
                _position++;
                builder.Append(_source[_position]);
            }
            else
            {
                builder.Append(_source[_position]);
            }

            _position++;
        }

        if (_position >= _source.Length)
        {
            throw new ExpressionException("Unterminated string literal.");
        }

        _position++; // closing quote
        return new Token(TokenType.String, builder.ToString());
    }

    private Token ReadIdentifier()
    {
        var start = _position;
        while (_position < _source.Length &&
               (char.IsLetterOrDigit(_source[_position]) || _source[_position] == '_'))
        {
            _position++;
        }

        return new Token(TokenType.Identifier, _source[start.._position]);
    }

    private char Peek(int offset)
    {
        var index = _position + offset;
        return index < _source.Length ? _source[index] : '\0';
    }

    private void SkipWhitespace()
    {
        while (_position < _source.Length && char.IsWhiteSpace(_source[_position]))
        {
            _position++;
        }
    }
}
