namespace Cicd.Core.Definition.Expressions;

/// <summary>Thrown when an expression cannot be parsed or evaluated.</summary>
public sealed class ExpressionException : Exception
{
    public ExpressionException(string message) : base(message)
    {
    }
}

public abstract record ExpressionNode;

public sealed record StringLiteral(string Value) : ExpressionNode;

public sealed record BoolLiteral(bool Value) : ExpressionNode;

/// <summary>A dotted identifier path, e.g. <c>status.build</c> or <c>matrix.suite</c>.</summary>
public sealed record Identifier(IReadOnlyList<string> Parts) : ExpressionNode;

public sealed record FunctionCall(string Name, IReadOnlyList<ExpressionNode> Arguments) : ExpressionNode;

public enum UnaryOperator
{
    Not
}

public sealed record UnaryExpression(UnaryOperator Operator, ExpressionNode Operand) : ExpressionNode;

public enum BinaryOperator
{
    Equal,
    NotEqual,
    And,
    Or
}

public sealed record BinaryExpression(BinaryOperator Operator, ExpressionNode Left, ExpressionNode Right)
    : ExpressionNode;
