namespace Cicd.Core.Definition.Expressions;

/// <summary>
/// The evaluation context for the <c>${{ }}</c> / <c>if:</c> expression language.
/// </summary>
public sealed record ExpressionContext
{
    public string Branch { get; init; } = string.Empty;

    /// <summary><c>push</c> | <c>schedule</c> | <c>fileWatch</c> | <c>manual</c>.</summary>
    public string Event { get; init; } = string.Empty;

    /// <summary>Job name → status string (<c>success</c> | <c>failed</c> | <c>skipped</c>).</summary>
    public IReadOnlyDictionary<string, string> JobStatuses { get; init; } =
        new Dictionary<string, string>();

    public IReadOnlyDictionary<string, string> Vars { get; init; } =
        new Dictionary<string, string>();

    public IReadOnlyDictionary<string, string> Inputs { get; init; } =
        new Dictionary<string, string>();

    public IReadOnlyDictionary<string, string> Matrix { get; init; } =
        new Dictionary<string, string>();

    /// <summary>Secret names visible to <c>if:</c> (presence only, never values).</summary>
    public ISet<string> SecretNames { get; init; } = new HashSet<string>();

    /// <summary>Secret values, used only by <see cref="ExpressionEvaluator.Interpolate"/> for env/with.</summary>
    public IReadOnlyDictionary<string, string>? SecretValues { get; init; }

    /// <summary>Hook for the <c>hash('glob', ...)</c> function.</summary>
    public Func<string[], string>? HashFiles { get; init; }
}
