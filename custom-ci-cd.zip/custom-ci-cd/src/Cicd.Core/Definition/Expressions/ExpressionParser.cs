namespace Cicd.Core.Definition.Expressions;

/// <summary>
/// Recursive-descent parser producing an <see cref="ExpressionNode"/> AST.
/// Grammar (lowest to highest precedence): or → and → equality → unary → primary.
/// </summary>
internal sealed class ExpressionParser
{
    private readonly List<Token> _tokens;
    private int _position;

    private ExpressionParser(List<Token> tokens)
    {
        _tokens = tokens;
    }

    public static ExpressionNode Parse(string expression)
    {
        var tokens = new ExpressionLexer(expression).Tokenize();
        var parser = new ExpressionParser(tokens);
        var node = parser.ParseOr();
        parser.Expect(TokenType.End);
        return node;
    }

    private ExpressionNode ParseOr()
    {
        var left = ParseAnd();
        while (Current.Type == TokenType.Or)
        {
            Advance();
            var right = ParseAnd();
            left = new BinaryExpression(BinaryOperator.Or, left, right);
        }

        return left;
    }

    private ExpressionNode ParseAnd()
    {
        var left = ParseEquality();
        while (Current.Type == TokenType.And)
        {
            Advance();
            var right = ParseEquality();
            left = new BinaryExpression(BinaryOperator.And, left, right);
        }

        return left;
    }

    private ExpressionNode ParseEquality()
    {
        var left = ParseUnary();
        while (Current.Type is TokenType.Eq or TokenType.Neq)
        {
            var op = Current.Type == TokenType.Eq ? BinaryOperator.Equal : BinaryOperator.NotEqual;
            Advance();
            var right = ParseUnary();
            left = new BinaryExpression(op, left, right);
        }

        return left;
    }

    private ExpressionNode ParseUnary()
    {
        if (Current.Type == TokenType.Not)
        {
            Advance();
            var operand = ParseUnary();
            return new UnaryExpression(UnaryOperator.Not, operand);
        }

        return ParsePrimary();
    }

    private ExpressionNode ParsePrimary()
    {
        var token = Current;

        switch (token.Type)
        {
            case TokenType.LParen:
            {
                Advance();
                var inner = ParseOr();
                Expect(TokenType.RParen);
                return inner;
            }
            case TokenType.String:
                Advance();
                return new StringLiteral(token.Text);
            case TokenType.Identifier:
                return ParseIdentifierOrCall();
            default:
                throw new ExpressionException($"Unexpected token '{token.Text}'.");
        }
    }

    private ExpressionNode ParseIdentifierOrCall()
    {
        var first = Current.Text;
        Advance();

        if (Current.Type == TokenType.LParen)
        {
            return ParseCall(first);
        }

        // Literals true/false.
        if (first is "true" or "false")
        {
            return new BoolLiteral(first == "true");
        }

        var parts = new List<string> { first };
        while (Current.Type == TokenType.Dot)
        {
            Advance();
            if (Current.Type != TokenType.Identifier)
            {
                throw new ExpressionException("Expected identifier after '.'.");
            }

            parts.Add(Current.Text);
            Advance();
        }

        return new Identifier(parts);
    }

    private ExpressionNode ParseCall(string name)
    {
        Expect(TokenType.LParen);
        var args = new List<ExpressionNode>();

        if (Current.Type != TokenType.RParen)
        {
            args.Add(ParseOr());
            while (Current.Type == TokenType.Comma)
            {
                Advance();
                args.Add(ParseOr());
            }
        }

        Expect(TokenType.RParen);
        return new FunctionCall(name, args);
    }

    private Token Current => _tokens[_position];

    private void Advance()
    {
        if (_position < _tokens.Count - 1)
        {
            _position++;
        }
    }

    private void Expect(TokenType type)
    {
        if (Current.Type != type)
        {
            throw new ExpressionException($"Expected {type} but found '{Current.Text}'.");
        }

        Advance();
    }
}
