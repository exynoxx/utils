using System.Text;

namespace Cicd.Core.Definition.Expressions;

/// <summary>
/// Evaluates the minimal <c>${{ }}</c> / <c>if:</c> expression language.
/// </summary>
public static class ExpressionEvaluator
{
    /// <summary>
    /// Validates that an expression parses. Returns null on success, or an error message.
    /// </summary>
    public static string? ValidateSyntax(string expression)
    {
        try
        {
            ExpressionParser.Parse(expression);
            return null;
        }
        catch (ExpressionException ex)
        {
            return ex.Message;
        }
    }

    /// <summary>
    /// Evaluates a boolean condition (used by <c>if:</c>). Non-boolean results are
    /// coerced: a non-empty string is true, an empty string is false.
    /// </summary>
    public static bool EvaluateBool(string expression, ExpressionContext context)
    {
        if (string.IsNullOrWhiteSpace(expression))
        {
            return true;
        }

        var node = ExpressionParser.Parse(expression);
        var value = Evaluate(node, context, allowSecretValues: false);
        return ToBool(value);
    }

    /// <summary>
    /// Substitutes every <c>${{ ... }}</c> occurrence in <paramref name="text"/> with the
    /// string result of evaluating the contained expression. Secret values are available here.
    /// </summary>
    public static string Interpolate(string text, ExpressionContext context)
    {
        if (string.IsNullOrEmpty(text) || !text.Contains("${{", StringComparison.Ordinal))
        {
            return text;
        }

        var builder = new StringBuilder();
        var i = 0;

        while (i < text.Length)
        {
            var open = text.IndexOf("${{", i, StringComparison.Ordinal);
            if (open < 0)
            {
                builder.Append(text, i, text.Length - i);
                break;
            }

            builder.Append(text, i, open - i);
            var close = text.IndexOf("}}", open + 3, StringComparison.Ordinal);
            if (close < 0)
            {
                throw new ExpressionException("Unterminated '${{' in interpolated string.");
            }

            var inner = text.Substring(open + 3, close - (open + 3));
            var node = ExpressionParser.Parse(inner);
            var value = Evaluate(node, context, allowSecretValues: true);
            builder.Append(ToStringValue(value));
            i = close + 2;
        }

        return builder.ToString();
    }

    private static object Evaluate(ExpressionNode node, ExpressionContext context, bool allowSecretValues)
    {
        return node switch
        {
            StringLiteral s => s.Value,
            BoolLiteral b => b.Value,
            Identifier id => EvaluateIdentifier(id, context, allowSecretValues),
            FunctionCall call => EvaluateFunction(call, context, allowSecretValues),
            UnaryExpression unary => EvaluateUnary(unary, context, allowSecretValues),
            BinaryExpression binary => EvaluateBinary(binary, context, allowSecretValues),
            _ => throw new ExpressionException($"Unsupported expression node '{node.GetType().Name}'.")
        };
    }

    private static object EvaluateUnary(UnaryExpression unary, ExpressionContext context, bool allowSecretValues)
    {
        var operand = Evaluate(unary.Operand, context, allowSecretValues);
        return !ToBool(operand);
    }

    private static object EvaluateBinary(BinaryExpression binary, ExpressionContext context, bool allowSecretValues)
    {
        switch (binary.Operator)
        {
            case BinaryOperator.And:
                return ToBool(Evaluate(binary.Left, context, allowSecretValues)) &&
                       ToBool(Evaluate(binary.Right, context, allowSecretValues));
            case BinaryOperator.Or:
                return ToBool(Evaluate(binary.Left, context, allowSecretValues)) ||
                       ToBool(Evaluate(binary.Right, context, allowSecretValues));
            case BinaryOperator.Equal:
            case BinaryOperator.NotEqual:
            {
                var left = Evaluate(binary.Left, context, allowSecretValues);
                var right = Evaluate(binary.Right, context, allowSecretValues);
                var equal = ValuesEqual(left, right);
                return binary.Operator == BinaryOperator.Equal ? equal : !equal;
            }
            default:
                throw new ExpressionException($"Unsupported operator '{binary.Operator}'.");
        }
    }

    private static object EvaluateIdentifier(Identifier id, ExpressionContext context, bool allowSecretValues)
    {
        var parts = id.Parts;
        var root = parts[0];

        switch (root)
        {
            case "branch":
                Expect(parts, 1, "branch");
                return context.Branch;
            case "event":
                Expect(parts, 1, "event");
                return context.Event;
            case "status":
                ExpectScoped(parts, "status");
                return context.JobStatuses.TryGetValue(parts[1], out var status)
                    ? status
                    : throw new ExpressionException($"Unknown job '{parts[1]}' in 'status.{parts[1]}'.");
            case "vars":
                ExpectScoped(parts, "vars");
                return context.Vars.TryGetValue(parts[1], out var v) ? v : string.Empty;
            case "inputs":
                ExpectScoped(parts, "inputs");
                return context.Inputs.TryGetValue(parts[1], out var input) ? input : string.Empty;
            case "matrix":
                ExpectScoped(parts, "matrix");
                return context.Matrix.TryGetValue(parts[1], out var m) ? m : string.Empty;
            case "secrets":
                ExpectScoped(parts, "secrets");
                if (allowSecretValues)
                {
                    return context.SecretValues is not null &&
                           context.SecretValues.TryGetValue(parts[1], out var secret)
                        ? secret
                        : string.Empty;
                }

                // In `if:` only presence is exposed.
                return context.SecretNames.Contains(parts[1]);
            default:
                throw new ExpressionException($"Unknown identifier '{root}'.");
        }
    }

    private static object EvaluateFunction(FunctionCall call, ExpressionContext context, bool allowSecretValues)
    {
        if (call.Name == "hash")
        {
            if (call.Arguments.Count == 0)
            {
                throw new ExpressionException("hash() requires at least one glob argument.");
            }

            if (context.HashFiles is null)
            {
                throw new ExpressionException("hash() is not available in this context.");
            }

            var globs = call.Arguments
                .Select(arg => ToStringValue(Evaluate(arg, context, allowSecretValues)))
                .ToArray();

            return context.HashFiles(globs);
        }

        throw new ExpressionException($"Unknown function '{call.Name}'.");
    }

    private static bool ValuesEqual(object left, object right)
    {
        if (left is bool lb && right is bool rb)
        {
            return lb == rb;
        }

        return string.Equals(ToStringValue(left), ToStringValue(right), StringComparison.Ordinal);
    }

    private static bool ToBool(object value)
    {
        return value switch
        {
            bool b => b,
            string s => s.Length > 0,
            _ => true
        };
    }

    private static string ToStringValue(object value)
    {
        return value switch
        {
            bool b => b ? "true" : "false",
            string s => s,
            _ => value.ToString() ?? string.Empty
        };
    }

    private static void Expect(IReadOnlyList<string> parts, int count, string name)
    {
        if (parts.Count != count)
        {
            throw new ExpressionException($"'{name}' does not take a member access.");
        }
    }

    private static void ExpectScoped(IReadOnlyList<string> parts, string name)
    {
        if (parts.Count != 2)
        {
            throw new ExpressionException($"'{name}' requires a member, e.g. '{name}.NAME'.");
        }
    }
}
