namespace Cicd.Core.Definition;

/// <summary>
/// Base type for trigger declarations. The <c>on:</c> field is the discriminator.
/// </summary>
public abstract record TriggerDefinition
{
    public required string On { get; init; }
}

public sealed record PushTriggerDefinition : TriggerDefinition
{
    public IReadOnlyList<string> Branches { get; init; } = [];
    public IReadOnlyList<string> Paths { get; init; } = [];
}

public sealed record ScheduleTriggerDefinition : TriggerDefinition
{
    public required string Cron { get; init; }
}

public sealed record FileWatchTriggerDefinition : TriggerDefinition
{
    public IReadOnlyList<string> Directories { get; init; } = [];
    public IReadOnlyList<string> Patterns { get; init; } = [];
    public TimeSpan Debounce { get; init; } = TimeSpan.FromMilliseconds(800);
}

public sealed record ManualTriggerDefinition : TriggerDefinition
{
    public IReadOnlyDictionary<string, InputDefinition> Inputs { get; init; } =
        new Dictionary<string, InputDefinition>();
}
