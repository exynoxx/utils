namespace Cicd.Core.Definition;

public sealed record CacheDefinition
{
    public required string Key { get; init; }
    public IReadOnlyList<string> RestoreKeys { get; init; } = [];
    public IReadOnlyList<string> Paths { get; init; } = [];
}

public sealed record ArtifactsDefinition
{
    public IReadOnlyList<string> Paths { get; init; } = [];
    public TimeSpan? Expire { get; init; }
}
