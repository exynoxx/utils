namespace Cicd.Core.Definition.Templates;

/// <summary>The raw YAML content of a resolved template, plus a canonical reference for cycle detection.</summary>
public sealed record TemplateDocument(string Reference, string Yaml);

/// <summary>
/// Resolves a <c>uses:</c> template reference to its YAML document.
/// </summary>
public interface ITemplateResolver
{
    TemplateDocument? Resolve(string reference);
}

/// <summary>
/// Resolves template references relative to a root directory on disk.
/// </summary>
public sealed class FileSystemTemplateResolver : ITemplateResolver
{
    private readonly string _rootDirectory;

    public FileSystemTemplateResolver(string rootDirectory)
    {
        _rootDirectory = rootDirectory;
    }

    public TemplateDocument? Resolve(string reference)
    {
        var relative = reference.TrimStart('.', '/');
        var fullPath = Path.GetFullPath(Path.Combine(_rootDirectory, relative));

        if (!fullPath.StartsWith(Path.GetFullPath(_rootDirectory), StringComparison.Ordinal))
        {
            // Refuse to escape the root directory.
            return null;
        }

        if (!File.Exists(fullPath))
        {
            return null;
        }

        var yaml = File.ReadAllText(fullPath);
        return new TemplateDocument(fullPath, yaml);
    }
}

/// <summary>
/// Resolves template references via a user-supplied delegate (e.g. server-registered templates).
/// </summary>
public sealed class DelegateTemplateResolver : ITemplateResolver
{
    private readonly Func<string, TemplateDocument?> _resolve;

    public DelegateTemplateResolver(Func<string, TemplateDocument?> resolve)
    {
        _resolve = resolve;
    }

    public TemplateDocument? Resolve(string reference)
    {
        return _resolve(reference);
    }
}
