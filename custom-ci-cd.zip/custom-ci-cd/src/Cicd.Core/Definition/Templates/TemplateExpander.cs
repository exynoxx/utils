using Cicd.Core.Definition.Expressions;
using Cicd.Core.Definition.Yaml;
using YamlDotNet.RepresentationModel;

namespace Cicd.Core.Definition.Templates;

/// <summary>Raised when a template cannot be resolved, parsed, or its inputs are invalid.</summary>
public sealed class TemplateException : Exception
{
    public TemplateException(string message) : base(message)
    {
    }
}

/// <summary>
/// Expands <c>uses: ./template.yml</c> step invocations into inline steps.
/// Resolves recursively (depth limit 10) with cycle detection by reference path,
/// validates required inputs against <c>with:</c>, applies defaults, and substitutes
/// <c>${{ inputs.NAME }}</c> occurrences into expanded step strings.
/// </summary>
public sealed class TemplateExpander
{
    private const int MaxDepth = 10;

    private readonly ITemplateResolver _resolver;

    public TemplateExpander(ITemplateResolver resolver)
    {
        _resolver = resolver;
    }

    /// <summary>
    /// Expands a list of steps, inlining any template invocations. Built-in <c>uses:</c>
    /// steps and plain <c>run:</c> steps are passed through unchanged.
    /// </summary>
    public IReadOnlyList<StepDefinition> Expand(IReadOnlyList<StepDefinition> steps)
    {
        var result = new List<StepDefinition>();
        foreach (var step in steps)
        {
            ExpandStep(step, result, new HashSet<string>(StringComparer.Ordinal), 0);
        }

        return result;
    }

    private void ExpandStep(StepDefinition step, List<StepDefinition> output, ISet<string> stack, int depth)
    {
        if (step.Uses is null || !BuiltInSteps.IsTemplateReference(step.Uses))
        {
            output.Add(step);
            return;
        }

        if (depth >= MaxDepth)
        {
            throw new TemplateException($"Template expansion exceeded depth limit of {MaxDepth} at '{step.Uses}'.");
        }

        var document = _resolver.Resolve(step.Uses)
                       ?? throw new TemplateException($"Template '{step.Uses}' could not be resolved.");

        if (!stack.Add(document.Reference))
        {
            throw new TemplateException($"Template cycle detected at '{document.Reference}'.");
        }

        try
        {
            var (inputs, templateSteps) = ParseTemplate(document);
            var resolvedInputs = ResolveInputs(inputs, step.With, step.Uses);

            foreach (var templateStep in templateSteps)
            {
                var substituted = Substitute(templateStep, resolvedInputs);
                ExpandStep(substituted, output, stack, depth + 1);
            }
        }
        finally
        {
            stack.Remove(document.Reference);
        }
    }

    private (IReadOnlyDictionary<string, InputDefinition> Inputs, IReadOnlyList<StepDefinition> Steps)
        ParseTemplate(TemplateDocument document)
    {
        var root = YamlReader.ParseDocument(document.Yaml, out _, out _, out var error)
                   ?? throw new TemplateException($"Template '{document.Reference}' is invalid YAML: {error}");

        var kind = YamlReader.GetScalar(root, "kind");
        if (!string.Equals(kind, "stepTemplate", StringComparison.Ordinal))
        {
            throw new TemplateException($"Template '{document.Reference}' must declare 'kind: stepTemplate'.");
        }

        var inputs = ParseInputs(root, document.Reference);

        if (YamlReader.Get(root, "steps") is not YamlSequenceNode stepsNode)
        {
            throw new TemplateException($"Template '{document.Reference}' must declare 'steps'.");
        }

        var steps = new List<StepDefinition>();
        foreach (var item in stepsNode.Children)
        {
            steps.Add(ParseStepNode(item, document.Reference));
        }

        return (inputs, steps);
    }

    private static IReadOnlyDictionary<string, InputDefinition> ParseInputs(YamlMappingNode root, string reference)
    {
        var result = new Dictionary<string, InputDefinition>();
        if (YamlReader.Get(root, "inputs") is not YamlMappingNode inputsNode)
        {
            return result;
        }

        foreach (var pair in inputsNode.Children)
        {
            if (pair.Key is not YamlScalarNode keyNode || keyNode.Value is null ||
                pair.Value is not YamlMappingNode spec)
            {
                continue;
            }

            var typeText = YamlReader.GetScalar(spec, "type") ?? "string";
            var type = typeText switch
            {
                "string" => InputType.String,
                "enum" => InputType.Enum,
                "bool" => InputType.Bool,
                _ => throw new TemplateException(
                    $"Template '{reference}' input '{keyNode.Value}' has invalid type '{typeText}'.")
            };

            result[keyNode.Value] = new InputDefinition
            {
                Type = type,
                Values = YamlReader.GetStringList(spec, "values"),
                Default = YamlReader.GetScalar(spec, "default"),
                Required = string.Equals(YamlReader.GetScalar(spec, "required"), "true", StringComparison.OrdinalIgnoreCase)
            };
        }

        return result;
    }

    private static StepDefinition ParseStepNode(YamlNode node, string reference)
    {
        if (node is YamlScalarNode)
        {
            throw new TemplateException($"Template '{reference}' steps must be mappings.");
        }

        if (node is not YamlMappingNode map)
        {
            throw new TemplateException($"Template '{reference}' has an invalid step.");
        }

        return new StepDefinition
        {
            Name = YamlReader.GetScalar(map, "name"),
            Run = YamlReader.GetScalar(map, "run"),
            Uses = YamlReader.GetScalar(map, "uses"),
            With = YamlReader.GetStringMap(map, "with"),
            Image = YamlReader.GetScalar(map, "image"),
            Env = YamlReader.GetStringMap(map, "env"),
            Workdir = YamlReader.GetScalar(map, "workdir"),
            If = YamlReader.GetScalar(map, "if")
        };
    }

    private static IReadOnlyDictionary<string, string> ResolveInputs(
        IReadOnlyDictionary<string, InputDefinition> declared,
        IReadOnlyDictionary<string, string> provided,
        string reference)
    {
        var resolved = new Dictionary<string, string>();

        foreach (var (name, definition) in declared)
        {
            if (provided.TryGetValue(name, out var value))
            {
                if (definition.Type == InputType.Enum && definition.Values.Count > 0 &&
                    !definition.Values.Contains(value))
                {
                    throw new TemplateException(
                        $"Template '{reference}' input '{name}' value '{value}' is not one of [{string.Join(", ", definition.Values)}].");
                }

                resolved[name] = value;
            }
            else if (definition.Default is not null)
            {
                resolved[name] = definition.Default;
            }
            else if (definition.Required)
            {
                throw new TemplateException($"Template '{reference}' requires input '{name}'.");
            }
        }

        return resolved;
    }

    private static StepDefinition Substitute(StepDefinition step, IReadOnlyDictionary<string, string> inputs)
    {
        var context = new ExpressionContext { Inputs = inputs };

        return step with
        {
            Run = step.Run is null ? null : ExpressionEvaluator.Interpolate(step.Run, context),
            Uses = step.Uses is null ? null : ExpressionEvaluator.Interpolate(step.Uses, context),
            Image = step.Image is null ? null : ExpressionEvaluator.Interpolate(step.Image, context),
            Workdir = step.Workdir is null ? null : ExpressionEvaluator.Interpolate(step.Workdir, context),
            With = SubstituteMap(step.With, context),
            Env = SubstituteMap(step.Env, context)
        };
    }

    private static IReadOnlyDictionary<string, string> SubstituteMap(
        IReadOnlyDictionary<string, string> map,
        ExpressionContext context)
    {
        if (map.Count == 0)
        {
            return map;
        }

        var result = new Dictionary<string, string>();
        foreach (var (key, value) in map)
        {
            result[key] = ExpressionEvaluator.Interpolate(value, context);
        }

        return result;
    }
}
