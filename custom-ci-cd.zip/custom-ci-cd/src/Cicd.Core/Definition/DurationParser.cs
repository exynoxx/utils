using System.Globalization;
using System.Text;

namespace Cicd.Core.Definition;

/// <summary>
/// Parses human duration strings such as <c>800ms</c>, <c>30s</c>, <c>30m</c>, <c>2h</c>, <c>7d</c>.
/// Combinations (e.g. <c>1h30m</c>) are supported but not required.
/// </summary>
public static class DurationParser
{
    public static TimeSpan Parse(string text)
    {
        if (TryParse(text, out var value, out var error))
        {
            return value;
        }

        throw new FormatException(error);
    }

    public static bool TryParse(string? text, out TimeSpan value, out string? error)
    {
        value = TimeSpan.Zero;
        error = null;

        if (string.IsNullOrWhiteSpace(text))
        {
            error = "Duration must not be empty.";
            return false;
        }

        var span = text.Trim();
        var total = TimeSpan.Zero;
        var matchedAny = false;
        var index = 0;

        while (index < span.Length)
        {
            var numberStart = index;
            while (index < span.Length && (char.IsDigit(span[index]) || span[index] == '.'))
            {
                index++;
            }

            if (index == numberStart)
            {
                error = $"Invalid duration '{text}': expected a number at position {index}.";
                return false;
            }

            var numberText = span[numberStart..index];
            if (!double.TryParse(numberText, NumberStyles.Float, CultureInfo.InvariantCulture, out var number))
            {
                error = $"Invalid duration '{text}': '{numberText}' is not a number.";
                return false;
            }

            var unitStart = index;
            while (index < span.Length && char.IsLetter(span[index]))
            {
                index++;
            }

            var unit = span[unitStart..index];
            if (unit.Length == 0)
            {
                error = $"Invalid duration '{text}': missing unit after '{numberText}'.";
                return false;
            }

            switch (unit)
            {
                case "ms":
                    total += TimeSpan.FromMilliseconds(number);
                    break;
                case "s":
                    total += TimeSpan.FromSeconds(number);
                    break;
                case "m":
                    total += TimeSpan.FromMinutes(number);
                    break;
                case "h":
                    total += TimeSpan.FromHours(number);
                    break;
                case "d":
                    total += TimeSpan.FromDays(number);
                    break;
                default:
                    error = $"Invalid duration '{text}': unknown unit '{unit}' (expected ms, s, m, h, d).";
                    return false;
            }

            matchedAny = true;
        }

        if (!matchedAny)
        {
            error = $"Invalid duration '{text}'.";
            return false;
        }

        value = total;
        return true;
    }
}
