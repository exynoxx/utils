namespace Cicd.Core.Definition;

/// <summary>
/// The set of built-in <c>uses:</c> step types. These are interpreted by the executor,
/// not expanded as templates.
/// </summary>
public static class BuiltInSteps
{
    public const string CacheRestore = "cache/restore";
    public const string CacheSave = "cache/save";
    public const string ArtifactUpload = "artifact/upload";
    public const string ArtifactDownload = "artifact/download";
    public const string NugetAuth = "nuget/auth";
    public const string NpmAuth = "npm/auth";
    public const string Checkout = "checkout";

    public static readonly IReadOnlySet<string> Names = new HashSet<string>(StringComparer.Ordinal)
    {
        CacheRestore,
        CacheSave,
        ArtifactUpload,
        ArtifactDownload,
        NugetAuth,
        NpmAuth,
        Checkout
    };

    public static bool IsBuiltIn(string uses)
    {
        return Names.Contains(uses);
    }

    /// <summary>
    /// A template reference looks like a path (contains '/' or '.') and is not a known built-in.
    /// </summary>
    public static bool IsTemplateReference(string uses)
    {
        if (IsBuiltIn(uses))
        {
            return false;
        }

        return uses.Contains('/') || uses.EndsWith(".yml", StringComparison.OrdinalIgnoreCase) ||
               uses.EndsWith(".yaml", StringComparison.OrdinalIgnoreCase);
    }
}
