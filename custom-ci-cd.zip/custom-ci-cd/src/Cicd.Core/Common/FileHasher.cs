using System.Security.Cryptography;
using System.Text;

namespace Cicd.Core.Common;

/// <summary>
/// Computes a stable SHA-256 hash over the contents of files matching one or more globs,
/// rooted at a base directory. Files are sorted by relative path for determinism.
/// </summary>
public sealed class FileHasher
{
    private readonly string _rootDirectory;

    public FileHasher(string rootDirectory)
    {
        _rootDirectory = rootDirectory;
    }

    public string Hash(params string[] globs)
    {
        return Hash((IEnumerable<string>)globs);
    }

    public string Hash(IEnumerable<string> globs)
    {
        if (!Directory.Exists(_rootDirectory))
        {
            return EmptyHash();
        }

        var globList = globs.ToList();

        var matched = Directory
            .EnumerateFiles(_rootDirectory, "*", SearchOption.AllDirectories)
            .Select(absolute => (Absolute: absolute, Relative: ToRelative(absolute)))
            .Where(file => GlobMatcher.IsMatchAny(globList, file.Relative))
            .OrderBy(file => file.Relative, StringComparer.Ordinal)
            .ToList();

        using var sha = SHA256.Create();
        using var stream = new MemoryStream();

        foreach (var file in matched)
        {
            var header = Encoding.UTF8.GetBytes(file.Relative + "\0");
            stream.Write(header, 0, header.Length);
            var content = File.ReadAllBytes(file.Absolute);
            stream.Write(content, 0, content.Length);
        }

        stream.Position = 0;
        var hash = sha.ComputeHash(stream);
        return Convert.ToHexStringLower(hash);
    }

    private static string EmptyHash()
    {
        return Convert.ToHexStringLower(SHA256.HashData(ReadOnlySpan<byte>.Empty));
    }

    private string ToRelative(string absolute)
    {
        return Path.GetRelativePath(_rootDirectory, absolute).Replace('\\', '/');
    }
}
