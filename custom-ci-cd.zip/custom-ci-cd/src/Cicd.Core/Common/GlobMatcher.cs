using System.Text;
using System.Text.RegularExpressions;

namespace Cicd.Core.Common;

/// <summary>
/// Minimal glob matcher. Translates glob patterns to regular expressions.
/// Supported wildcards:
/// <list type="bullet">
/// <item><c>**</c> matches any number of path segments (including none).</item>
/// <item><c>*</c> matches any run of characters except the path separator.</item>
/// <item><c>?</c> matches a single character except the path separator.</item>
/// </list>
/// Matching is performed against forward-slash-normalized paths and is case-sensitive.
/// </summary>
public static class GlobMatcher
{
    public static bool IsMatch(string pattern, string path)
    {
        var normalizedPath = Normalize(path);
        var regex = ToRegex(pattern);
        return regex.IsMatch(normalizedPath);
    }

    public static bool IsMatchAny(IEnumerable<string> patterns, string path)
    {
        foreach (var pattern in patterns)
        {
            if (IsMatch(pattern, path))
            {
                return true;
            }
        }

        return false;
    }

    public static Regex ToRegex(string pattern)
    {
        var normalized = Normalize(pattern);
        var builder = new StringBuilder("^");
        var i = 0;

        while (i < normalized.Length)
        {
            var c = normalized[i];
            switch (c)
            {
                case '*':
                    if (i + 1 < normalized.Length && normalized[i + 1] == '*')
                    {
                        // "**/" or "**" — match across segment boundaries.
                        i += 2;
                        if (i < normalized.Length && normalized[i] == '/')
                        {
                            i++;
                            builder.Append("(?:.*/)?");
                        }
                        else
                        {
                            builder.Append(".*");
                        }
                    }
                    else
                    {
                        builder.Append("[^/]*");
                        i++;
                    }

                    break;
                case '?':
                    builder.Append("[^/]");
                    i++;
                    break;
                default:
                    builder.Append(Regex.Escape(c.ToString()));
                    i++;
                    break;
            }
        }

        builder.Append('$');
        return new Regex(builder.ToString(), RegexOptions.CultureInvariant);
    }

    private static string Normalize(string value)
    {
        return value.Replace('\\', '/');
    }
}
