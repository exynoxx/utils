using System.Text;

namespace Cicd.Core.Secrets;

/// <summary>
/// Replaces secret values with <c>***</c> in log output. Holds the active secret values for a
/// job (only values of length >= 4 are masked, to avoid masking trivial substrings).
///
/// <para>
/// <see cref="MaskChunk"/> is streaming-safe: a secret may be split across two chunk boundaries,
/// so the masker retains a tail buffer of up to (maxSecretLength - 1) bytes that could be the
/// prefix of a secret straddling the boundary, and only releases bytes that cannot be part of a
/// pending match. Call <see cref="Flush"/> at end of stream to emit any retained tail.
/// </para>
/// </summary>
public sealed class SecretMasker
{
    private const int MinLength = 4;
    private const string Replacement = "***";

    private readonly List<string> _secrets;
    private readonly int _maxLength;
    private string _carry = string.Empty;

    public SecretMasker(IEnumerable<string> secretValues)
    {
        _secrets = secretValues
            .Where(v => v.Length >= MinLength)
            .Distinct()
            .OrderByDescending(v => v.Length)
            .ToList();
        _maxLength = _secrets.Count == 0 ? 0 : _secrets.Max(s => s.Length);
    }

    /// <summary>Masks a complete string (no cross-call boundary state).</summary>
    public string Mask(string input)
    {
        if (_secrets.Count == 0 || string.IsNullOrEmpty(input))
        {
            return input;
        }

        var result = input;
        foreach (var secret in _secrets)
        {
            result = result.Replace(secret, Replacement, StringComparison.Ordinal);
        }

        return result;
    }

    /// <summary>
    /// Masks a chunk, carrying a tail buffer so secrets split across chunk boundaries are still
    /// masked. Returns the safe-to-emit portion; retained bytes are emitted by a later call or
    /// by <see cref="Flush"/>.
    /// </summary>
    public string MaskChunk(string chunk)
    {
        if (_secrets.Count == 0)
        {
            return chunk;
        }

        var combined = _carry + chunk;
        var masked = Mask(combined);

        // Retain a tail that could still be the prefix of a secret straddling the next chunk.
        var retain = Math.Min(_maxLength - 1, masked.Length);
        if (retain <= 0)
        {
            _carry = string.Empty;
            return masked;
        }

        var emit = masked[..^retain];
        _carry = masked[^retain..];
        return emit;
    }

    /// <summary>Emits any retained tail at end of stream, masked.</summary>
    public string Flush()
    {
        if (_carry.Length == 0)
        {
            return string.Empty;
        }

        var result = Mask(_carry);
        _carry = string.Empty;
        return result;
    }
}
