using System.Security.Cryptography;
using System.Text;

namespace Cicd.Core.Secrets;

/// <summary>An encrypted secret value: ciphertext, the random nonce, and the GCM auth tag.</summary>
public sealed record EncryptedSecret(byte[] Ciphertext, byte[] Nonce, byte[] Tag);

/// <summary>
/// AES-256-GCM encryption for secret values. A fresh random nonce is generated per value.
/// The master key is supplied as raw bytes (256-bit) by the host (e.g. from CICD_MASTER_KEY).
/// </summary>
public sealed class SecretCipher
{
    private const int NonceSize = 12; // 96-bit nonce recommended for GCM
    private const int TagSize = 16; // 128-bit auth tag

    private readonly byte[] _masterKey;

    public SecretCipher(byte[] masterKey)
    {
        if (masterKey.Length != 32)
        {
            throw new ArgumentException("Master key must be 256 bits (32 bytes).", nameof(masterKey));
        }

        _masterKey = masterKey;
    }

    public EncryptedSecret Encrypt(string plaintext)
    {
        var plainBytes = Encoding.UTF8.GetBytes(plaintext);
        var nonce = RandomNumberGenerator.GetBytes(NonceSize);
        var ciphertext = new byte[plainBytes.Length];
        var tag = new byte[TagSize];

        using var aes = new AesGcm(_masterKey, TagSize);
        aes.Encrypt(nonce, plainBytes, ciphertext, tag);

        return new EncryptedSecret(ciphertext, nonce, tag);
    }

    public string Decrypt(EncryptedSecret secret)
    {
        var plainBytes = new byte[secret.Ciphertext.Length];

        using var aes = new AesGcm(_masterKey, TagSize);
        aes.Decrypt(secret.Nonce, secret.Ciphertext, secret.Tag, plainBytes);

        return Encoding.UTF8.GetString(plainBytes);
    }
}
