using Cicd.Core.Domain;

namespace Cicd.Core.Secrets;

/// <summary>A secret's name and scope (never its value).</summary>
public sealed record SecretInfo(string Name, string Scope, PipelineId? PipelineId);

/// <summary>
/// Stores secrets encrypted at rest. Scopes: global plus per-pipeline.
/// </summary>
public interface ISecretStore
{
    /// <summary>
    /// Returns the resolved plaintext secrets visible to a pipeline scope
    /// (per-pipeline secrets layered over global), as name → value.
    /// </summary>
    Task<IReadOnlyDictionary<string, string>> GetForPipelineAsync(PipelineId pipelineId, CancellationToken ct);

    Task SetAsync(string name, string scope, PipelineId? pipelineId, string value, CancellationToken ct);

    Task DeleteAsync(string name, string scope, PipelineId? pipelineId, CancellationToken ct);

    Task<IReadOnlyList<SecretInfo>> ListAsync(CancellationToken ct);
}
