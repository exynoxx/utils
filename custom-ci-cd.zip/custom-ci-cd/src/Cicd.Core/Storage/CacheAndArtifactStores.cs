namespace Cicd.Core.Storage;

/// <summary>
/// Content cache keyed by a string. Restore tries the exact key, then restore-key prefixes
/// (newest match). Stores tar streams produced by the executor.
/// </summary>
public interface ICacheStore
{
    /// <summary>Restores into <paramref name="destination"/> stream. Returns true if a hit occurred.</summary>
    Task<bool> RestoreAsync(string key, IReadOnlyList<string> restoreKeys, Stream destination, CancellationToken ct);

    Task SaveAsync(string key, Stream content, CancellationToken ct);
}

/// <summary>
/// Stores per-run/job artifact archives. The executor tars declared paths and uploads here.
/// </summary>
public interface IArtifactStore
{
    /// <summary>Persists an artifact archive and returns the storage path and size in bytes.</summary>
    Task<(string Path, long SizeBytes)> SaveAsync(string runId, string jobId, string name, Stream content, CancellationToken ct);

    Stream OpenRead(string path);

    Task DeleteAsync(string path, CancellationToken ct);
}
