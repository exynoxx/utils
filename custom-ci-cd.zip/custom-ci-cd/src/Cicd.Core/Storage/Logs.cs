using System.Threading.Channels;
using Cicd.Core.Domain;

namespace Cicd.Core.Storage;

/// <summary>A contiguous chunk of log bytes for a job at a known byte offset.</summary>
public sealed record LogChunk(JobId JobId, long Offset, ReadOnlyMemory<byte> Data);

/// <summary>Appends log bytes to durable storage and reports the new byte offset.</summary>
public interface ILogWriter
{
    /// <summary>Appends bytes for a job and returns the new total byte size.</summary>
    Task<long> AppendAsync(JobId jobId, ReadOnlyMemory<byte> data, CancellationToken ct);
}

/// <summary>Reads persisted job logs, optionally from a byte offset.</summary>
public interface ILogStore
{
    Task<long> GetSizeAsync(JobId jobId, CancellationToken ct);
    Stream OpenRead(JobId jobId, long fromOffset);
}

/// <summary>
/// In-memory live fan-out of log chunks per job. Subscribers attach to receive new chunks
/// as they are published; callers replay persisted bytes from the store first to avoid gaps.
/// </summary>
public interface ILogBroker
{
    void Publish(LogChunk chunk);
    IDisposable Subscribe(JobId jobId, ChannelWriter<LogChunk> writer);
    void Complete(JobId jobId);
}

/// <summary>
/// Channel-based <see cref="ILogBroker"/> with per-job multicast to a list of subscribers.
/// </summary>
public sealed class LogBroker : ILogBroker
{
    private readonly object _gate = new();
    private readonly Dictionary<Guid, List<ChannelWriter<LogChunk>>> _subscribers = new();

    public void Publish(LogChunk chunk)
    {
        List<ChannelWriter<LogChunk>>? targets;
        lock (_gate)
        {
            if (!_subscribers.TryGetValue(chunk.JobId.Value, out var list))
            {
                return;
            }

            targets = [.. list];
        }

        foreach (var writer in targets)
        {
            writer.TryWrite(chunk);
        }
    }

    public IDisposable Subscribe(JobId jobId, ChannelWriter<LogChunk> writer)
    {
        lock (_gate)
        {
            if (!_subscribers.TryGetValue(jobId.Value, out var list))
            {
                list = [];
                _subscribers[jobId.Value] = list;
            }

            list.Add(writer);
        }

        return new Subscription(this, jobId, writer);
    }

    public void Complete(JobId jobId)
    {
        List<ChannelWriter<LogChunk>>? targets;
        lock (_gate)
        {
            if (!_subscribers.TryGetValue(jobId.Value, out var list))
            {
                return;
            }

            targets = [.. list];
        }

        foreach (var writer in targets)
        {
            writer.TryComplete();
        }
    }

    private void Unsubscribe(JobId jobId, ChannelWriter<LogChunk> writer)
    {
        lock (_gate)
        {
            if (_subscribers.TryGetValue(jobId.Value, out var list))
            {
                list.Remove(writer);
                if (list.Count == 0)
                {
                    _subscribers.Remove(jobId.Value);
                }
            }
        }
    }

    private sealed class Subscription : IDisposable
    {
        private readonly LogBroker _broker;
        private readonly JobId _jobId;
        private readonly ChannelWriter<LogChunk> _writer;

        public Subscription(LogBroker broker, JobId jobId, ChannelWriter<LogChunk> writer)
        {
            _broker = broker;
            _jobId = jobId;
            _writer = writer;
        }

        public void Dispose()
        {
            _broker.Unsubscribe(_jobId, _writer);
        }
    }
}
