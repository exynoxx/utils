using Cicd.Core.Domain;

namespace Cicd.Core.Storage;

/// <summary>A page of results plus the total count for paging.</summary>
public sealed record Page<T>(IReadOnlyList<T> Items, int TotalCount);

public interface IPipelineRepository
{
    Task<Pipeline> CreateAsync(Pipeline pipeline, CancellationToken ct);
    Task<Pipeline?> GetAsync(PipelineId id, CancellationToken ct);
    Task<Pipeline?> GetByNameAsync(string name, CancellationToken ct);
    Task<Page<Pipeline>> ListAsync(int skip, int take, CancellationToken ct);
    Task<Pipeline> UpdateAsync(Pipeline pipeline, CancellationToken ct);
    Task DeleteAsync(PipelineId id, CancellationToken ct);
}

public interface IRunRepository
{
    Task<Run> CreateAsync(Run run, CancellationToken ct);
    Task<Run?> GetAsync(RunId id, CancellationToken ct);
    Task<Page<Run>> ListByPipelineAsync(PipelineId pipelineId, int skip, int take, CancellationToken ct);
    Task UpdateStatusAsync(RunId id, RunStatus status, DateTimeOffset? startedAt, DateTimeOffset? finishedAt, CancellationToken ct);
}

public interface IJobRepository
{
    Task<Job> CreateAsync(Job job, CancellationToken ct);
    Task<Job?> GetAsync(JobId id, CancellationToken ct);
    Task<IReadOnlyList<Job>> ListByRunAsync(RunId runId, CancellationToken ct);
    Task UpdateStatusAsync(JobId id, JobStatus status, DateTimeOffset? startedAt, DateTimeOffset? finishedAt, CancellationToken ct);
    Task UpdateAttemptAsync(JobId id, int attempt, CancellationToken ct);
    Task UpdateLogSizeAsync(JobId id, long logSize, CancellationToken ct);
}

public interface IStepRepository
{
    Task CreateManyAsync(IReadOnlyList<StepRecord> steps, CancellationToken ct);
    Task<IReadOnlyList<StepRecord>> ListByJobAsync(JobId jobId, CancellationToken ct);
    Task UpdateStatusAsync(StepId id, StepStatus status, int? exitCode, DateTimeOffset? startedAt, DateTimeOffset? finishedAt, CancellationToken ct);
}

public sealed record ArtifactRecord
{
    public required ArtifactId Id { get; init; }
    public required RunId RunId { get; init; }
    public required JobId JobId { get; init; }
    public required string Name { get; init; }
    public required string Path { get; init; }
    public long SizeBytes { get; init; }
    public DateTimeOffset? ExpiresAt { get; init; }
    public DateTimeOffset CreatedAt { get; init; }
}

public interface IArtifactRepository
{
    Task<ArtifactRecord> CreateAsync(ArtifactRecord artifact, CancellationToken ct);
    Task<ArtifactRecord?> GetAsync(ArtifactId id, CancellationToken ct);
    Task<IReadOnlyList<ArtifactRecord>> ListByRunAsync(RunId runId, CancellationToken ct);
    Task<IReadOnlyList<ArtifactRecord>> ListByJobAsync(JobId jobId, CancellationToken ct);
    Task<IReadOnlyList<ArtifactRecord>> ListExpiredAsync(DateTimeOffset now, CancellationToken ct);
    Task DeleteAsync(ArtifactId id, CancellationToken ct);
}

/// <summary>Per repo+branch last-seen SHA, used by the push trigger.</summary>
public interface IRepoBranchStateStore
{
    Task<string?> GetLastShaAsync(string repoUrl, string branch, CancellationToken ct);
    Task SetLastShaAsync(string repoUrl, string branch, string sha, CancellationToken ct);
}
