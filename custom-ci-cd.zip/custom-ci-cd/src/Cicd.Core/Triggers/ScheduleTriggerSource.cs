using System.Runtime.CompilerServices;
using Cicd.Core.Definition;
using Cicd.Core.Execution;
using Cronos;
using Microsoft.Extensions.Logging;

namespace Cicd.Core.Triggers;

/// <summary>
/// Fires schedule triggers using Cronos. Polls all pipelines with schedule triggers, computes the
/// next occurrence (UTC) per cron expression, and emits an event when due.
/// </summary>
public sealed class ScheduleTriggerSource : ITriggerSource
{
    private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(30);

    private readonly IPipelineCatalog _catalog;
    private readonly TimeProvider _clock;
    private readonly ILogger<ScheduleTriggerSource> _logger;
    private readonly Dictionary<string, DateTimeOffset> _nextOccurrences = new();

    public ScheduleTriggerSource(
        IPipelineCatalog catalog,
        TimeProvider clock,
        ILogger<ScheduleTriggerSource> logger)
    {
        _catalog = catalog;
        _clock = clock;
        _logger = logger;
    }

    public string On => "schedule";

    public async IAsyncEnumerable<TriggerEvent> WatchAsync([EnumeratorCancellation] CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            IReadOnlyList<CatalogEntry> entries;
            try
            {
                entries = await _catalog.ListAsync(ct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Schedule trigger failed to list pipelines");
                await DelayAsync(ct);
                continue;
            }

            var now = _clock.GetUtcNow();

            foreach (var entry in entries)
            {
                foreach (var schedule in entry.Triggers.OfType<ScheduleTriggerDefinition>())
                {
                    var key = $"{entry.PipelineId.Value}|{schedule.Cron}";
                    var ev = Evaluate(entry, schedule, key, now);
                    if (ev is not null)
                    {
                        yield return ev;
                    }
                }
            }

            await DelayAsync(ct);
        }
    }

    private TriggerEvent? Evaluate(CatalogEntry entry, ScheduleTriggerDefinition schedule, string key, DateTimeOffset now)
    {
        CronExpression cron;
        try
        {
            cron = CronExpression.Parse(schedule.Cron);
        }
        catch (CronFormatException ex)
        {
            _logger.LogWarning(ex, "Invalid cron '{Cron}' for pipeline {Pipeline}", schedule.Cron, entry.PipelineId);
            return null;
        }

        if (!_nextOccurrences.TryGetValue(key, out var next))
        {
            var first = cron.GetNextOccurrence(now.UtcDateTime, TimeZoneInfo.Utc);
            if (first is null)
            {
                return null;
            }

            _nextOccurrences[key] = first.Value;
            return null;
        }

        if (now < next)
        {
            return null;
        }

        var following = cron.GetNextOccurrence(now.UtcDateTime, TimeZoneInfo.Utc);
        if (following is not null)
        {
            _nextOccurrences[key] = following.Value;
        }

        var branch = string.IsNullOrEmpty(entry.DefaultBranch) ? "main" : entry.DefaultBranch;
        return new TriggerEvent(
            entry.PipelineId,
            On,
            branch,
            entry.RepoUrl is null ? "local" : "HEAD",
            [],
            new Dictionary<string, string>());
    }

    private async Task DelayAsync(CancellationToken ct)
    {
        try
        {
            await Task.Delay(PollInterval, ct);
        }
        catch (OperationCanceledException)
        {
            // Shutting down.
        }
    }
}
