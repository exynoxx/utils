using System.Diagnostics;
using System.Text;

namespace Cicd.Core.Triggers;

/// <summary>Result of a git invocation.</summary>
public sealed record GitResult(int ExitCode, string StdOut, string StdErr)
{
    public bool Success => ExitCode == 0;
}

/// <summary>
/// Thin wrapper that shells out to the <c>git</c> binary. Used by the push trigger to maintain
/// bare mirrors and inspect refs/diffs without parsing a porcelain library.
/// </summary>
public sealed class GitCli
{
    private readonly string _gitPath;

    public GitCli(string gitPath = "git")
    {
        _gitPath = gitPath;
    }

    public async Task<GitResult> RunAsync(string? workingDirectory, CancellationToken ct, params string[] args)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = _gitPath,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        if (workingDirectory is not null)
        {
            startInfo.WorkingDirectory = workingDirectory;
        }

        foreach (var arg in args)
        {
            startInfo.ArgumentList.Add(arg);
        }

        using var process = new Process { StartInfo = startInfo };
        var stdout = new StringBuilder();
        var stderr = new StringBuilder();

        process.OutputDataReceived += (_, e) =>
        {
            if (e.Data is not null)
            {
                stdout.AppendLine(e.Data);
            }
        };
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data is not null)
            {
                stderr.AppendLine(e.Data);
            }
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();

        await process.WaitForExitAsync(ct);

        return new GitResult(process.ExitCode, stdout.ToString(), stderr.ToString());
    }
}
