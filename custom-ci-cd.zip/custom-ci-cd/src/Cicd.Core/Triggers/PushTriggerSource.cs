using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using Cicd.Core.Definition;
using Cicd.Core.Execution;
using Cicd.Core.Storage;
using Microsoft.Extensions.Logging;

namespace Cicd.Core.Triggers;

/// <summary>
/// Detects pushes by polling git mirrors. Maintains a bare mirror per repo under the mirror root,
/// fetches on an interval, compares per-branch SHAs against <see cref="IRepoBranchStateStore"/>,
/// and emits a <see cref="TriggerEvent"/> per new SHA on a matching branch (with changed paths).
/// </summary>
public sealed class PushTriggerSource : ITriggerSource
{
    private readonly string _mirrorRoot;
    private readonly TimeSpan _pollInterval;
    private readonly IPipelineCatalog _catalog;
    private readonly IRepoBranchStateStore _stateStore;
    private readonly GitCli _git;
    private readonly ILogger<PushTriggerSource> _logger;

    public PushTriggerSource(
        string mirrorRoot,
        TimeSpan pollInterval,
        IPipelineCatalog catalog,
        IRepoBranchStateStore stateStore,
        GitCli git,
        ILogger<PushTriggerSource> logger)
    {
        _mirrorRoot = mirrorRoot;
        _pollInterval = pollInterval;
        _catalog = catalog;
        _stateStore = stateStore;
        _git = git;
        _logger = logger;
    }

    public string On => "push";

    public async IAsyncEnumerable<TriggerEvent> WatchAsync([EnumeratorCancellation] CancellationToken ct)
    {
        Directory.CreateDirectory(_mirrorRoot);

        while (!ct.IsCancellationRequested)
        {
            IReadOnlyList<CatalogEntry> entries;
            try
            {
                entries = await _catalog.ListAsync(ct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Push trigger failed to list pipelines");
                await DelayAsync(ct);
                continue;
            }

            foreach (var entry in entries)
            {
                if (entry.RepoUrl is null)
                {
                    continue;
                }

                var pushTriggers = entry.Triggers.OfType<PushTriggerDefinition>().ToList();
                if (pushTriggers.Count == 0)
                {
                    continue;
                }

                var events = await PollRepoAsync(entry, pushTriggers, ct);
                foreach (var ev in events)
                {
                    yield return ev;
                }
            }

            await DelayAsync(ct);
        }
    }

    private async Task<IReadOnlyList<TriggerEvent>> PollRepoAsync(
        CatalogEntry entry,
        IReadOnlyList<PushTriggerDefinition> pushTriggers,
        CancellationToken ct)
    {
        var repoUrl = entry.RepoUrl!;
        var results = new List<TriggerEvent>();

        try
        {
            var mirrorPath = await EnsureMirrorAsync(repoUrl, ct);

            var refs = await _git.RunAsync(mirrorPath, ct, "for-each-ref", "--format=%(refname:short) %(objectname)", "refs/heads/");
            if (!refs.Success)
            {
                _logger.LogWarning("git for-each-ref failed for {Repo}: {Err}", repoUrl, refs.StdErr);
                return results;
            }

            foreach (var line in refs.StdOut.Split('\n', StringSplitOptions.RemoveEmptyEntries))
            {
                var parts = line.Trim().Split(' ', 2);
                if (parts.Length != 2)
                {
                    continue;
                }

                var branch = parts[0];
                var newSha = parts[1];

                var matchingTrigger = pushTriggers.FirstOrDefault(t => TriggerFilter.BranchMatches(t.Branches, branch));
                if (matchingTrigger is null)
                {
                    continue;
                }

                var lastSha = await _stateStore.GetLastShaAsync(repoUrl, branch, ct);
                if (string.Equals(lastSha, newSha, StringComparison.Ordinal))
                {
                    continue;
                }

                var changedPaths = lastSha is null
                    ? []
                    : await DiffPathsAsync(mirrorPath, lastSha, newSha, ct);

                await _stateStore.SetLastShaAsync(repoUrl, branch, newSha, ct);

                if (lastSha is null)
                {
                    // First sighting: record state but don't fire a run for historical commits.
                    continue;
                }

                if (!TriggerFilter.PathsMatch(matchingTrigger.Paths, changedPaths))
                {
                    continue;
                }

                results.Add(new TriggerEvent(
                    entry.PipelineId,
                    On,
                    branch,
                    newSha,
                    changedPaths,
                    new Dictionary<string, string>()));
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Push trigger failed polling {Repo}", repoUrl);
        }

        return results;
    }

    private async Task<string> EnsureMirrorAsync(string repoUrl, CancellationToken ct)
    {
        var mirrorPath = Path.Combine(_mirrorRoot, RepoHash(repoUrl) + ".git");

        if (!Directory.Exists(mirrorPath))
        {
            var clone = await _git.RunAsync(null, ct, "clone", "--mirror", repoUrl, mirrorPath);
            if (!clone.Success)
            {
                throw new InvalidOperationException($"git clone --mirror failed: {clone.StdErr}");
            }
        }
        else
        {
            var fetch = await _git.RunAsync(mirrorPath, ct, "fetch", "--prune");
            if (!fetch.Success)
            {
                _logger.LogWarning("git fetch failed for {Repo}: {Err}", repoUrl, fetch.StdErr);
            }
        }

        return mirrorPath;
    }

    private async Task<IReadOnlyList<string>> DiffPathsAsync(string mirrorPath, string oldSha, string newSha, CancellationToken ct)
    {
        var diff = await _git.RunAsync(mirrorPath, ct, "diff", "--name-only", oldSha, newSha);
        if (!diff.Success)
        {
            return [];
        }

        return diff.StdOut
            .Split('\n', StringSplitOptions.RemoveEmptyEntries)
            .Select(p => p.Trim())
            .Where(p => p.Length > 0)
            .ToList();
    }

    private async Task DelayAsync(CancellationToken ct)
    {
        try
        {
            await Task.Delay(_pollInterval, ct);
        }
        catch (OperationCanceledException)
        {
            // Shutting down.
        }
    }

    private static string RepoHash(string repoUrl)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(repoUrl));
        return Convert.ToHexStringLower(bytes)[..16];
    }
}
