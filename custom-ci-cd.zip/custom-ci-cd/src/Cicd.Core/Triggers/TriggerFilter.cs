using Cicd.Core.Common;

namespace Cicd.Core.Triggers;

/// <summary>
/// Branch- and path-glob matching for trigger events.
/// </summary>
public static class TriggerFilter
{
    /// <summary>Empty patterns means "any".</summary>
    public static bool BranchMatches(IReadOnlyList<string> branchGlobs, string branch)
    {
        if (branchGlobs.Count == 0)
        {
            return true;
        }

        return GlobMatcher.IsMatchAny(branchGlobs, branch);
    }

    /// <summary>Empty path globs means "any". Otherwise at least one changed path must match.</summary>
    public static bool PathsMatch(IReadOnlyList<string> pathGlobs, IReadOnlyList<string> changedPaths)
    {
        if (pathGlobs.Count == 0)
        {
            return true;
        }

        return changedPaths.Any(path => GlobMatcher.IsMatchAny(pathGlobs, path));
    }
}
