using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using System.Threading.Channels;
using Cicd.Core.Common;
using Cicd.Core.Definition;
using Cicd.Core.Execution;
using Microsoft.Extensions.Logging;

namespace Cicd.Core.Triggers;

/// <summary>
/// Watches local directories with <see cref="FileSystemWatcher"/>, filters by glob patterns, and
/// coalesces bursts within the configured debounce window before emitting a single event per
/// pipeline (synthetic branch <c>local</c>, SHA <c>working-tree</c>).
/// </summary>
public sealed class FileWatchTriggerSource : ITriggerSource
{
    private readonly IPipelineCatalog _catalog;
    private readonly ILogger<FileWatchTriggerSource> _logger;

    public FileWatchTriggerSource(IPipelineCatalog catalog, ILogger<FileWatchTriggerSource> logger)
    {
        _catalog = catalog;
        _logger = logger;
    }

    public string On => "fileWatch";

    public async IAsyncEnumerable<TriggerEvent> WatchAsync([EnumeratorCancellation] CancellationToken ct)
    {
        var channel = Channel.CreateUnbounded<TriggerEvent>();
        var watchers = new List<FileSystemWatcher>();
        var pending = new ConcurrentDictionary<Guid, PendingDebounce>();

        try
        {
            var entries = await _catalog.ListAsync(ct);

            foreach (var entry in entries)
            {
                foreach (var watch in entry.Triggers.OfType<FileWatchTriggerDefinition>())
                {
                    SetUpWatchers(entry, watch, channel.Writer, watchers, pending);
                }
            }

            if (watchers.Count == 0)
            {
                // Nothing to watch; idle until canceled.
                await IdleUntilCanceledAsync(ct);
                yield break;
            }

            await foreach (var ev in channel.Reader.ReadAllAsync(ct))
            {
                yield return ev;
            }
        }
        finally
        {
            foreach (var watcher in watchers)
            {
                watcher.Dispose();
            }

            foreach (var debounce in pending.Values)
            {
                debounce.Timer?.Dispose();
            }
        }
    }

    private void SetUpWatchers(
        CatalogEntry entry,
        FileWatchTriggerDefinition watch,
        ChannelWriter<TriggerEvent> writer,
        List<FileSystemWatcher> watchers,
        ConcurrentDictionary<Guid, PendingDebounce> pending)
    {
        foreach (var directory in watch.Directories)
        {
            var fullPath = Path.GetFullPath(directory);
            if (!Directory.Exists(fullPath))
            {
                _logger.LogWarning("Watch directory '{Dir}' does not exist", fullPath);
                continue;
            }

            var watcher = new FileSystemWatcher(fullPath)
            {
                IncludeSubdirectories = true,
                EnableRaisingEvents = true,
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName
            };

            void OnChanged(object _, FileSystemEventArgs args)
            {
                var relative = Path.GetRelativePath(fullPath, args.FullPath).Replace('\\', '/');
                if (watch.Patterns.Count > 0 && !GlobMatcher.IsMatchAny(watch.Patterns, relative))
                {
                    return;
                }

                Debounce(entry, watch, relative, writer, pending);
            }

            watcher.Changed += OnChanged;
            watcher.Created += OnChanged;
            watcher.Deleted += OnChanged;
            watcher.Renamed += (_, args) => OnChanged(watcher, args);

            watchers.Add(watcher);
        }
    }

    private static void Debounce(
        CatalogEntry entry,
        FileWatchTriggerDefinition watch,
        string changedPath,
        ChannelWriter<TriggerEvent> writer,
        ConcurrentDictionary<Guid, PendingDebounce> pending)
    {
        var state = pending.GetOrAdd(entry.PipelineId.Value, _ => new PendingDebounce());
        lock (state.Gate)
        {
            state.Paths.Add(changedPath);
            state.Timer ??= new Timer(_ =>
            {
                List<string> paths;
                lock (state.Gate)
                {
                    paths = [.. state.Paths];
                    state.Paths.Clear();
                }

                writer.TryWrite(new TriggerEvent(
                    entry.PipelineId,
                    "fileWatch",
                    "local",
                    "working-tree",
                    paths,
                    new Dictionary<string, string>()));
            }, null, Timeout.Infinite, Timeout.Infinite);

            state.Timer.Change(watch.Debounce, Timeout.InfiniteTimeSpan);
        }
    }

    private static async Task IdleUntilCanceledAsync(CancellationToken ct)
    {
        try
        {
            await Task.Delay(Timeout.Infinite, ct);
        }
        catch (OperationCanceledException)
        {
            // Shutting down.
        }
    }

    private sealed class PendingDebounce
    {
        public object Gate { get; } = new();
        public HashSet<string> Paths { get; } = new(StringComparer.Ordinal);
        public Timer? Timer { get; set; }
    }
}
