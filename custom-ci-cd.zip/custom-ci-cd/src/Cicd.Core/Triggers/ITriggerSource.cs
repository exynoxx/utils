using Cicd.Core.Definition;
using Cicd.Core.Domain;
using Cicd.Core.Execution;

namespace Cicd.Core.Triggers;

/// <summary>
/// A source of trigger events. Hosted alongside others; emitted events are filtered and handed
/// to the run scheduler.
/// </summary>
public interface ITriggerSource
{
    /// <summary>"push" | "schedule" | "fileWatch" | "manual".</summary>
    string On { get; }

    IAsyncEnumerable<TriggerEvent> WatchAsync(CancellationToken ct);
}

/// <summary>A registered pipeline together with its parsed trigger definitions.</summary>
public sealed record CatalogEntry(
    PipelineId PipelineId,
    string? RepoUrl,
    string DefaultBranch,
    IReadOnlyList<TriggerDefinition> Triggers);

/// <summary>
/// Lists registered pipelines and their trigger definitions, for the trigger sources to watch.
/// </summary>
public interface IPipelineCatalog
{
    Task<IReadOnlyList<CatalogEntry>> ListAsync(CancellationToken ct);
}
