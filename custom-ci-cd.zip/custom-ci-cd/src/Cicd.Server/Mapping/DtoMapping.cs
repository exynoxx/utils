using Cicd.Contracts;
using Cicd.Core.Domain;
using Cicd.Core.Secrets;
using Cicd.Core.Storage;
using Cicd.Infrastructure.Persistence;

namespace Cicd.Server.Mapping;

/// <summary>
/// Maps Core domain records to the wire DTOs in <see cref="Cicd.Contracts"/>. Enum values are
/// mapped by name (the contract enums mirror the domain enums).
/// </summary>
public static class DtoMapping
{
    public static PipelineDto ToDto(this Pipeline pipeline)
    {
        return new PipelineDto(
            pipeline.Id.Value,
            pipeline.Name,
            pipeline.RepoUrl,
            pipeline.RawYaml is not null,
            pipeline.CreatedAt);
    }

    public static PipelineDetailDto ToDetailDto(this Pipeline pipeline)
    {
        return new PipelineDetailDto(
            pipeline.Id.Value,
            pipeline.Name,
            pipeline.RepoUrl,
            pipeline.RawYaml is not null,
            pipeline.CreatedAt,
            pipeline.RawYaml);
    }

    public static RunDto ToDto(this Run run)
    {
        return new RunDto(
            run.Id.Value,
            run.PipelineId.Value,
            run.TriggerOn,
            run.Branch,
            run.CommitSha,
            ToRunStatusDto(run.Status),
            run.CreatedAt,
            run.StartedAt,
            run.FinishedAt);
    }

    public static RunDetailDto ToDetailDto(this Run run, IReadOnlyList<JobDto> jobs)
    {
        return new RunDetailDto(
            run.Id.Value,
            run.PipelineId.Value,
            run.TriggerOn,
            run.Branch,
            run.CommitSha,
            ToRunStatusDto(run.Status),
            run.CreatedAt,
            run.StartedAt,
            run.FinishedAt,
            jobs);
    }

    public static JobDto ToDto(this Job job, IReadOnlyList<StepDto> steps)
    {
        return new JobDto(
            job.Id.Value,
            job.RunId.Value,
            job.Name,
            job.Image ?? string.Empty,
            job.Needs,
            ToJobStatusDto(job.Status),
            job.Attempt,
            job.StartedAt,
            job.FinishedAt,
            steps);
    }

    public static StepDto ToDto(this StepRecord step)
    {
        return new StepDto(
            step.Ordinal,
            step.Name,
            ToStepStatusDto(step.Status),
            step.ExitCode,
            step.StartedAt,
            step.FinishedAt);
    }

    public static ArtifactDto ToDto(this ArtifactRecord artifact)
    {
        return new ArtifactDto(
            artifact.Id.Value,
            artifact.RunId.Value,
            artifact.JobId.Value,
            artifact.Name,
            artifact.SizeBytes,
            artifact.ExpiresAt,
            artifact.CreatedAt);
    }

    public static SecretDto ToDto(this SecretInfo secret)
    {
        return new SecretDto(secret.Name, secret.Scope.ToLowerInvariant(), secret.PipelineId?.Value);
    }

    public static ApiTokenDto ToDto(this ApiTokenInfo token)
    {
        return new ApiTokenDto(token.Id, token.Name, token.CreatedAt, token.LastUsedAt);
    }

    private static RunStatusDto ToRunStatusDto(RunStatus status)
    {
        return Enum.Parse<RunStatusDto>(status.ToString());
    }

    private static JobStatusDto ToJobStatusDto(JobStatus status)
    {
        return Enum.Parse<JobStatusDto>(status.ToString());
    }

    private static StepStatusDto ToStepStatusDto(StepStatus status)
    {
        return Enum.Parse<StepStatusDto>(status.ToString());
    }
}
