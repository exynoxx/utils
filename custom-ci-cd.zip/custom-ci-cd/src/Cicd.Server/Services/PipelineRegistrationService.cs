using Cicd.Core.Definition;
using Cicd.Core.Domain;
using Cicd.Core.Storage;
using Cicd.Infrastructure.Glue;

namespace Cicd.Server.Services;

/// <summary>
/// The outcome of resolving a registration/update request into a stored pipeline shape. Either a
/// successful <see cref="Pipeline"/> projection or a list of parse/validation errors.
/// </summary>
public sealed record PipelineResolution(
    bool Success,
    string? Name,
    string? RepoUrl,
    string? RawYaml,
    IReadOnlyList<ParseError> Errors)
{
    public static PipelineResolution Failed(IReadOnlyList<ParseError> errors)
    {
        return new PipelineResolution(false, null, null, null, errors);
    }

    public static PipelineResolution Ok(string name, string? repoUrl, string? rawYaml)
    {
        return new PipelineResolution(true, name, repoUrl, rawYaml, []);
    }
}

/// <summary>
/// Resolves a pipeline registration/update request into the canonical stored form (name, repoUrl,
/// rawYaml snapshot). Handles three shapes:
/// <list type="bullet">
/// <item>Inline <c>yaml</c>: parsed/validated; stored as <c>RawYaml</c>.</item>
/// <item><c>repoUrl</c> pointing at a real git remote: a bare mirror is created/refreshed and
/// <c>.pipeline.yml</c> is read from HEAD as the stored snapshot (RepoUrl is retained).</item>
/// <item>Local path (<c>file://</c> or an existing absolute directory): normalized to the
/// <c>file://</c> convention; <c>yaml</c> is required unless <c>&lt;dir&gt;/.pipeline.yml</c> exists.</item>
/// </list>
/// </summary>
public sealed class PipelineRegistrationService
{
    private const string PipelineFile = ".pipeline.yml";

    private readonly IPipelineParser _parser;
    private readonly GitMirror _mirror;

    public PipelineRegistrationService(IPipelineParser parser, GitMirror mirror)
    {
        _parser = parser;
        _mirror = mirror;
    }

    public async Task<PipelineResolution> ResolveAsync(
        string? requestedName,
        string? repoUrl,
        string? yaml,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(repoUrl) && string.IsNullOrWhiteSpace(yaml))
        {
            return PipelineResolution.Failed(
                [new ParseError("At least one of 'repoUrl' or 'yaml' is required.", null, null)]);
        }

        var normalizedRepoUrl = NormalizeRepoUrl(repoUrl);

        // Inline YAML takes precedence as the source of truth.
        if (!string.IsNullOrWhiteSpace(yaml))
        {
            return Validate(yaml, requestedName, normalizedRepoUrl);
        }

        // Local-path pipeline without inline yaml: read .pipeline.yml from disk.
        if (IsLocalPath(normalizedRepoUrl, out var localDir))
        {
            var pipelinePath = Path.Combine(localDir, PipelineFile);
            if (!File.Exists(pipelinePath))
            {
                return PipelineResolution.Failed(
                    [new ParseError($"No '{PipelineFile}' found in '{localDir}' and no inline yaml was provided.", null, null)]);
            }

            var localYaml = await File.ReadAllTextAsync(pipelinePath, ct);
            return Validate(localYaml, requestedName, normalizedRepoUrl);
        }

        // Repo-backed pipeline: mirror the repo and read .pipeline.yml from HEAD.
        try
        {
            await _mirror.EnsureMirrorAsync(normalizedRepoUrl!, ct);
            var repoYaml = await _mirror.ShowFileAsync(normalizedRepoUrl!, "HEAD", PipelineFile, ct);
            if (repoYaml is null)
            {
                return PipelineResolution.Failed(
                    [new ParseError($"'{PipelineFile}' not found at HEAD in {normalizedRepoUrl}.", null, null)]);
            }

            return Validate(repoYaml, requestedName, normalizedRepoUrl);
        }
        catch (Exception ex)
        {
            return PipelineResolution.Failed(
                [new ParseError($"Failed to read '{PipelineFile}' from {normalizedRepoUrl}: {ex.Message}", null, null)]);
        }
    }

    private PipelineResolution Validate(string yaml, string? requestedName, string? repoUrl)
    {
        var result = _parser.Parse(yaml);
        if (!result.Success || result.Definition is null)
        {
            return PipelineResolution.Failed(result.Errors);
        }

        var name = !string.IsNullOrWhiteSpace(requestedName) ? requestedName! : result.Definition.Name;
        return PipelineResolution.Ok(name, repoUrl, yaml);
    }

    private static string? NormalizeRepoUrl(string? repoUrl)
    {
        if (string.IsNullOrWhiteSpace(repoUrl))
        {
            return null;
        }

        var trimmed = repoUrl.Trim();
        if (trimmed.StartsWith("file://", StringComparison.OrdinalIgnoreCase))
        {
            return trimmed;
        }

        // An existing absolute local directory is normalized to the file:// convention.
        if (Path.IsPathRooted(trimmed) && Directory.Exists(trimmed))
        {
            return "file://" + trimmed;
        }

        return trimmed;
    }

    private static bool IsLocalPath(string? repoUrl, out string localDir)
    {
        localDir = string.Empty;
        if (repoUrl is null || !repoUrl.StartsWith("file://", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        localDir = repoUrl["file://".Length..];
        return true;
    }
}
