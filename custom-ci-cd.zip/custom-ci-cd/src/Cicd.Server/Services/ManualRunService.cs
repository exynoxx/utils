using Cicd.Core.Domain;
using Cicd.Core.Execution;
using Cicd.Core.Triggers;
using Cicd.Infrastructure.Glue;

namespace Cicd.Server.Services;

/// <summary>Resolved coordinates for a manual run, or an error message to surface as a 400.</summary>
public sealed record ManualRunTarget(string? Branch, string? CommitSha, string? Error)
{
    public bool Success => Error is null;
}

/// <summary>
/// Resolves the branch and commit SHA for a manual run trigger:
/// <list type="bullet">
/// <item>Repo-backed pipelines: branch defaults to <c>main</c>; the SHA is resolved from the bare
/// mirror's branch head (the mirror is created/fetched first).</item>
/// <item>Local-path / standalone pipelines: branch <c>local</c>, SHA <c>working-tree</c>.</item>
/// </list>
/// </summary>
public sealed class ManualRunService
{
    private const string DefaultBranch = "main";

    private readonly GitMirror _mirror;
    private readonly GitCli _git;

    public ManualRunService(GitMirror mirror, GitCli git)
    {
        _mirror = mirror;
        _git = git;
    }

    public async Task<ManualRunTarget> ResolveAsync(
        Pipeline pipeline,
        string? requestedBranch,
        CancellationToken ct)
    {
        if (IsRepoBacked(pipeline.RepoUrl))
        {
            var branch = string.IsNullOrWhiteSpace(requestedBranch) ? DefaultBranch : requestedBranch!.Trim();
            try
            {
                await _mirror.EnsureMirrorAsync(pipeline.RepoUrl!, ct);
                var mirrorPath = _mirror.MirrorPath(pipeline.RepoUrl!);

                // Refresh so a freshly pushed branch head resolves.
                await _git.RunAsync(mirrorPath, ct, "fetch", "--prune", "origin");

                var revParse = await _git.RunAsync(mirrorPath, ct, "rev-parse", $"refs/heads/{branch}");
                if (!revParse.Success)
                {
                    return new ManualRunTarget(null, null,
                        $"Could not resolve branch '{branch}' in {pipeline.RepoUrl}: {revParse.StdErr.Trim()}");
                }

                var sha = revParse.StdOut.Trim();
                if (string.IsNullOrWhiteSpace(sha))
                {
                    return new ManualRunTarget(null, null, $"Branch '{branch}' resolved to an empty SHA.");
                }

                return new ManualRunTarget(branch, sha, null);
            }
            catch (Exception ex)
            {
                return new ManualRunTarget(null, null,
                    $"Failed to resolve branch '{branch}' in {pipeline.RepoUrl}: {ex.Message}");
            }
        }

        // Local-path or pure standalone pipeline.
        var localBranch = string.IsNullOrWhiteSpace(requestedBranch) ? "local" : requestedBranch!.Trim();
        return new ManualRunTarget(localBranch, "working-tree", null);
    }

    /// <summary>A repo-backed pipeline has a real remote URL (not the local <c>file://</c> convention).</summary>
    private static bool IsRepoBacked(string? repoUrl)
    {
        return !string.IsNullOrWhiteSpace(repoUrl)
            && !repoUrl.StartsWith("file://", StringComparison.OrdinalIgnoreCase);
    }
}
