using System.Text.Json.Serialization;
using Cicd.Core.Execution;
using Cicd.Infrastructure.DependencyInjection;
using Cicd.Server.Auth;
using Cicd.Server.Endpoints;
using Cicd.Server.HostedServices;
using Cicd.Server.Services;

var builder = WebApplication.CreateBuilder(args);

// Listen on 8080 by default (overridable via ASPNETCORE_URLS).
builder.WebHost.UseUrls(builder.Configuration["ASPNETCORE_URLS"] ?? "http://0.0.0.0:8080");

// JSON: web defaults (camelCase) + string enums, matching Cicd.Contracts / the CLI client.
builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
});

builder.Services.AddProblemDetails();

// Infrastructure: persistence, queue, stores, secrets, Docker executor, Core glue.
builder.Services.AddCicdInfrastructure(builder.Configuration);

// Core singletons not registered by Infrastructure.
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<ICancellationRegistry, CancellationRegistry>();
builder.Services.AddSingleton<IRunScheduler, RunScheduler>();
builder.Services.AddSingleton<WorkerCoordinator>();

// Server-side application services.
builder.Services.AddSingleton<ServerReadiness>();
builder.Services.AddSingleton<PipelineRegistrationService>();
builder.Services.AddSingleton<ManualRunService>();

// Hosted services: startup init runs first; then the worker pool, lease reaper and triggers.
builder.Services.AddHostedService<StartupInitializer>();
builder.Services.AddHostedService<WorkerPoolService>();
builder.Services.AddHostedService<LeaseReaperService>();
builder.Services.AddHostedService<TriggerService>();

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();

// Token auth for /api (anonymous: /api/healthz and non-/api static assets).
app.UseMiddleware<TokenAuthMiddleware>();

// REST API under /api.
var api = app.MapGroup("/api");
HealthEndpoints.Map(api);
PipelineEndpoints.Map(api);
RunEndpoints.Map(api);
LogEndpoints.Map(api);
ArtifactEndpoints.Map(api);
SecretEndpoints.Map(api);
TokenEndpoints.Map(api);

// SPA: serve the built React app and fall back to index.html for client-side routes,
// but never for /api paths.
app.UseDefaultFiles();
app.UseStaticFiles();

// Client-side routing fallback. Unknown /api routes return 404 (ProblemDetails) instead of the SPA.
app.MapFallback(async context =>
{
    if (context.Request.Path.StartsWithSegments("/api", StringComparison.OrdinalIgnoreCase))
    {
        context.Response.StatusCode = StatusCodes.Status404NotFound;
        return;
    }

    context.Response.ContentType = "text/html";
    await context.Response.SendFileAsync(Path.Combine(app.Environment.WebRootPath ?? "wwwroot", "index.html"));
});

app.Run();
