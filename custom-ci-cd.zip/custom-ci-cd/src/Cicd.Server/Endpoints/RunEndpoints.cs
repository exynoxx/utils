using Cicd.Contracts;
using Cicd.Core.Domain;
using Cicd.Core.Execution;
using Cicd.Core.Storage;
using Cicd.Infrastructure.Persistence;
using Cicd.Server.Mapping;
using Microsoft.EntityFrameworkCore;

namespace Cicd.Server.Endpoints;

/// <summary>Run listing, detail (DAG), cancellation, and per-job detail.</summary>
public static class RunEndpoints
{
    public static void Map(RouteGroupBuilder group)
    {
        var runs = group.MapGroup("/runs");

        runs.MapGet("/", ListRecentAsync);
        runs.MapGet("/{runId:guid}", GetAsync);
        runs.MapPost("/{runId:guid}/cancel", CancelAsync);
        runs.MapGet("/{runId:guid}/jobs/{jobId:guid}", GetJobAsync);
    }

    private static async Task<IResult> ListRecentAsync(
        IDbContextFactory<CicdDbContext> contextFactory,
        IRunRepository runRepository,
        int? limit,
        CancellationToken ct)
    {
        var resolvedLimit = limit is > 0 ? limit.Value : 20;

        await using var db = await contextFactory.CreateDbContextAsync(ct);
        var total = await db.Runs.CountAsync(ct);
        var ids = await db.Runs
            .AsNoTracking()
            .OrderByDescending(r => r.CreatedAt)
            .Take(resolvedLimit)
            .Select(r => r.Id)
            .ToListAsync(ct);

        var items = new List<RunDto>(ids.Count);
        foreach (var id in ids)
        {
            var run = await runRepository.GetAsync(new RunId(id), ct);
            if (run is not null)
            {
                items.Add(run.ToDto());
            }
        }

        return Results.Ok(new PagedResult<RunDto>(items, total, 1, resolvedLimit));
    }

    private static async Task<IResult> GetAsync(
        Guid runId,
        IRunRepository runs,
        IJobRepository jobs,
        IStepRepository steps,
        CancellationToken ct)
    {
        var run = await runs.GetAsync(new RunId(runId), ct);
        if (run is null)
        {
            return NotFound("Run", runId);
        }

        var jobRecords = await jobs.ListByRunAsync(new RunId(runId), ct);
        var jobDtos = new List<JobDto>(jobRecords.Count);
        foreach (var job in jobRecords)
        {
            var stepRecords = await steps.ListByJobAsync(job.Id, ct);
            var stepDtos = stepRecords.Select(s => s.ToDto()).ToList();
            jobDtos.Add(job.ToDto(stepDtos));
        }

        return Results.Ok(run.ToDetailDto(jobDtos));
    }

    private static async Task<IResult> CancelAsync(
        Guid runId,
        IRunRepository runs,
        IJobRepository jobs,
        ICancellationRegistry cancellation,
        IDbContextFactory<CicdDbContext> contextFactory,
        CancellationToken ct)
    {
        var run = await runs.GetAsync(new RunId(runId), ct);
        if (run is null)
        {
            return NotFound("Run", runId);
        }

        // Signal any running workers for this run to abort.
        cancellation.Cancel(run.Id);

        // Mark not-yet-claimed jobs (Pending/Queued) Canceled directly; running jobs are canceled
        // by their workers via the cancellation token and will report Canceled on completion.
        var pending = JobStatus.Pending.ToString();
        var queued = JobStatus.Queued.ToString();
        var canceled = JobStatus.Canceled.ToString();
        var now = DateTimeOffset.UtcNow;

        await using var db = await contextFactory.CreateDbContextAsync(ct);
        await db.Jobs
            .Where(j => j.RunId == runId && (j.Status == pending || j.Status == queued))
            .ExecuteUpdateAsync(s => s
                .SetProperty(j => j.Status, canceled)
                .SetProperty(j => j.FinishedAt, now), ct);

        // If no jobs remain running, finalize the run as Canceled now.
        var running = JobStatus.Running.ToString();
        var stillRunning = await db.Jobs.AnyAsync(j => j.RunId == runId && j.Status == running, ct);
        if (!stillRunning && !RunStateMachine.IsTerminal(run.Status))
        {
            await runs.UpdateStatusAsync(run.Id, RunStatus.Canceled, run.StartedAt, now, ct);
        }

        return Results.StatusCode(StatusCodes.Status202Accepted);
    }

    private static async Task<IResult> GetJobAsync(
        Guid runId,
        Guid jobId,
        IJobRepository jobs,
        IStepRepository steps,
        CancellationToken ct)
    {
        var job = await jobs.GetAsync(new JobId(jobId), ct);
        if (job is null || job.RunId.Value != runId)
        {
            return NotFound("Job", jobId);
        }

        var stepRecords = await steps.ListByJobAsync(job.Id, ct);
        var stepDtos = stepRecords.Select(s => s.ToDto()).ToList();
        return Results.Ok(job.ToDto(stepDtos));
    }

    private static IResult NotFound(string entity, Guid id)
    {
        return Results.Problem(detail: $"{entity} '{id}' was not found.", title: "Not found", statusCode: StatusCodes.Status404NotFound);
    }
}
