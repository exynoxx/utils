using Cicd.Contracts;
using Cicd.Core.Domain;
using Cicd.Core.Secrets;
using Cicd.Server.Mapping;

namespace Cicd.Server.Endpoints;

/// <summary>Secret listing (names/scopes only) and write-only set/delete.</summary>
public static class SecretEndpoints
{
    public static void Map(RouteGroupBuilder group)
    {
        var secrets = group.MapGroup("/secrets");

        secrets.MapGet("/", ListAsync);
        secrets.MapPut("/{name}", SetAsync);
        secrets.MapDelete("/{name}", DeleteAsync);
    }

    private static async Task<IResult> ListAsync(ISecretStore store, CancellationToken ct)
    {
        var infos = await store.ListAsync(ct);
        return Results.Ok(infos.Select(s => s.ToDto()).ToList());
    }

    private static async Task<IResult> SetAsync(
        string name,
        SetSecretRequest request,
        ISecretStore store,
        CancellationToken ct)
    {
        if (!TryNormalizeScope(request.Scope, out var scope))
        {
            return InvalidScope(request.Scope);
        }

        PipelineId? pipelineId = null;
        if (scope == "pipeline")
        {
            if (request.PipelineId is null || request.PipelineId == Guid.Empty)
            {
                return Results.Problem(detail: "A pipelineId is required for pipeline-scoped secrets.", title: "Invalid request", statusCode: StatusCodes.Status400BadRequest);
            }

            pipelineId = new PipelineId(request.PipelineId.Value);
        }

        await store.SetAsync(name, scope, pipelineId, request.Value, ct);
        return Results.NoContent();
    }

    private static async Task<IResult> DeleteAsync(
        string name,
        string? scope,
        Guid? pipelineId,
        ISecretStore store,
        CancellationToken ct)
    {
        if (!TryNormalizeScope(scope ?? "global", out var normalizedScope))
        {
            return InvalidScope(scope);
        }

        PipelineId? id = null;
        if (normalizedScope == "pipeline")
        {
            if (pipelineId is null || pipelineId == Guid.Empty)
            {
                return Results.Problem(detail: "A pipelineId is required to delete a pipeline-scoped secret.", title: "Invalid request", statusCode: StatusCodes.Status400BadRequest);
            }

            id = new PipelineId(pipelineId.Value);
        }

        await store.DeleteAsync(name, normalizedScope, id, ct);
        return Results.NoContent();
    }

    private static bool TryNormalizeScope(string scope, out string normalized)
    {
        normalized = (scope ?? string.Empty).Trim().ToLowerInvariant();
        return normalized is "global" or "pipeline";
    }

    private static IResult InvalidScope(string? scope)
    {
        return Results.Problem(
            detail: $"Invalid scope '{scope}'. Expected 'global' or 'pipeline'.",
            title: "Invalid scope",
            statusCode: StatusCodes.Status400BadRequest);
    }
}
