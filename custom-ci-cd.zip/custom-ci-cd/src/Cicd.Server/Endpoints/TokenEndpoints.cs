using Cicd.Contracts;
using Cicd.Infrastructure.Persistence;
using Cicd.Server.Mapping;

namespace Cicd.Server.Endpoints;

/// <summary>API token management. Raw token values are returned only once, at creation.</summary>
public static class TokenEndpoints
{
    public static void Map(RouteGroupBuilder group)
    {
        var tokens = group.MapGroup("/tokens");

        tokens.MapGet("/", ListAsync);
        tokens.MapPost("/", CreateAsync);
        tokens.MapDelete("/{tokenId:guid}", DeleteAsync);
    }

    private static async Task<IResult> ListAsync(IApiTokenStore store, CancellationToken ct)
    {
        var infos = await store.ListAsync(ct);
        return Results.Ok(infos.Select(t => t.ToDto()).ToList());
    }

    private static async Task<IResult> CreateAsync(CreateTokenRequest request, IApiTokenStore store, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
        {
            return Results.Problem(detail: "A token name is required.", title: "Invalid request", statusCode: StatusCodes.Status400BadRequest);
        }

        var (id, rawToken) = await store.CreateAsync(request.Name.Trim(), ct);
        return Results.Json(new CreateTokenResponse(id, rawToken), statusCode: StatusCodes.Status201Created);
    }

    private static async Task<IResult> DeleteAsync(Guid tokenId, IApiTokenStore store, CancellationToken ct)
    {
        await store.DeleteAsync(tokenId, ct);
        return Results.NoContent();
    }
}
