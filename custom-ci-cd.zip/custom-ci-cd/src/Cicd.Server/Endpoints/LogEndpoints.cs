using System.Text;
using System.Threading.Channels;
using Cicd.Core.Domain;
using Cicd.Core.Storage;
using Cicd.Infrastructure.Stores;

namespace Cicd.Server.Endpoints;

/// <summary>Plain-text log retrieval and SSE live tailing for a job.</summary>
public static class LogEndpoints
{
    private static readonly TimeSpan HeartbeatInterval = TimeSpan.FromSeconds(15);
    private static readonly TimeSpan JobPollInterval = TimeSpan.FromSeconds(2);

    public static void Map(RouteGroupBuilder group)
    {
        var jobLogs = group.MapGroup("/runs/{runId:guid}/jobs/{jobId:guid}/logs");

        jobLogs.MapGet("/", GetLogsAsync);
        jobLogs.MapGet("/stream", StreamLogsAsync);
    }

    private static async Task<IResult> GetLogsAsync(
        Guid runId,
        Guid jobId,
        long? fromOffset,
        IJobRepository jobs,
        FileSystemLogStore logStore,
        CancellationToken ct)
    {
        var job = await jobs.GetAsync(new JobId(jobId), ct);
        if (job is null || job.RunId.Value != runId)
        {
            return NotFound("Job", jobId);
        }

        // Ensure the store can resolve the on-disk path even after a restart.
        logStore.Register(new JobId(jobId), new RunId(runId));

        var stream = logStore.OpenRead(new JobId(jobId), fromOffset ?? 0);
        return Results.Stream(stream, "text/plain; charset=utf-8");
    }

    private static async Task StreamLogsAsync(
        HttpContext context,
        Guid runId,
        Guid jobId,
        long? fromOffset,
        IJobRepository jobs,
        FileSystemLogStore logStore,
        ILogBroker broker)
    {
        var ct = context.RequestAborted;

        var job = await jobs.GetAsync(new JobId(jobId), ct);
        if (job is null || job.RunId.Value != runId)
        {
            context.Response.StatusCode = StatusCodes.Status404NotFound;
            return;
        }

        var jobIdValue = new JobId(jobId);
        logStore.Register(jobIdValue, new RunId(runId));

        context.Response.Headers["Content-Type"] = "text/event-stream";
        context.Response.Headers["Cache-Control"] = "no-cache";
        context.Response.Headers["X-Accel-Buffering"] = "no";

        var startOffset = ResolveStartOffset(context.Request, fromOffset);

        // Subscribe to the broker FIRST so no live chunk is missed while we replay the file.
        var channel = Channel.CreateUnbounded<LogChunk>();
        using var subscription = broker.Subscribe(jobIdValue, channel.Writer);

        // Replay persisted bytes from the start offset.
        var offset = await ReplayFromFileAsync(context, logStore, jobIdValue, startOffset, ct);

        var heartbeat = DateTimeOffset.UtcNow;
        var lastJobCheck = DateTimeOffset.UtcNow;

        while (!ct.IsCancellationRequested)
        {
            LogChunk chunk;
            try
            {
                using var pollCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
                pollCts.CancelAfter(TimeSpan.FromSeconds(1));
                chunk = await channel.Reader.ReadAsync(pollCts.Token);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (OperationCanceledException)
            {
                // Poll timeout: send heartbeat and check terminal status, then continue.
                if (DateTimeOffset.UtcNow - heartbeat >= HeartbeatInterval)
                {
                    await WriteRawAsync(context, ": ping\n\n", ct);
                    heartbeat = DateTimeOffset.UtcNow;
                }

                if (DateTimeOffset.UtcNow - lastJobCheck >= JobPollInterval)
                {
                    lastJobCheck = DateTimeOffset.UtcNow;
                    if (await IsTerminalAsync(jobs, jobIdValue, ct))
                    {
                        // Drain any remaining file bytes, then end.
                        offset = await ReplayFromFileAsync(context, logStore, jobIdValue, offset, ct);
                        await WriteRawAsync(context, "event: end\ndata: done\n\n", ct);
                        return;
                    }
                }

                continue;
            }
            catch (ChannelClosedException)
            {
                break;
            }

            // Skip chunks fully below our current offset to avoid duplicates with the replay.
            var chunkEnd = chunk.Offset + chunk.Data.Length;
            if (chunkEnd <= offset)
            {
                continue;
            }

            var data = chunk.Data;
            if (chunk.Offset < offset)
            {
                // Partial overlap: emit only the unseen tail.
                var skip = (int)(offset - chunk.Offset);
                data = chunk.Data[skip..];
            }

            await WriteSseDataAsync(context, chunkEnd, Encoding.UTF8.GetString(data.Span), ct);
            offset = chunkEnd;
        }

        // Connection closed or broker completed: flush remaining bytes and end.
        offset = await ReplayFromFileAsync(context, logStore, jobIdValue, offset, ct);
        if (!ct.IsCancellationRequested)
        {
            await WriteRawAsync(context, "event: end\ndata: done\n\n", ct);
        }
    }

    private static long ResolveStartOffset(HttpRequest request, long? fromOffset)
    {
        if (request.Headers.TryGetValue("Last-Event-ID", out var lastEventId)
            && long.TryParse(lastEventId.ToString(), out var parsed)
            && parsed >= 0)
        {
            return parsed;
        }

        return fromOffset is > 0 ? fromOffset.Value : 0;
    }

    private static async Task<long> ReplayFromFileAsync(
        HttpContext context,
        FileSystemLogStore logStore,
        JobId jobId,
        long fromOffset,
        CancellationToken ct)
    {
        var size = await logStore.GetSizeAsync(jobId, ct);
        if (size <= fromOffset)
        {
            return fromOffset;
        }

        await using var stream = logStore.OpenRead(jobId, fromOffset);
        using var reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: false);
        var content = await reader.ReadToEndAsync(ct);
        var bytes = Encoding.UTF8.GetByteCount(content);
        var endOffset = fromOffset + bytes;

        await WriteSseDataAsync(context, endOffset, content, ct);
        return endOffset;
    }

    private static async Task WriteSseDataAsync(HttpContext context, long id, string payload, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(payload))
        {
            return;
        }

        var builder = new StringBuilder();
        builder.Append("id: ").Append(id).Append('\n');

        // SSE: each line of the payload becomes its own `data:` field within one message.
        var lines = payload.Replace("\r\n", "\n").Split('\n');
        foreach (var line in lines)
        {
            builder.Append("data: ").Append(line).Append('\n');
        }

        builder.Append('\n');
        await WriteRawAsync(context, builder.ToString(), ct);
    }

    private static async Task WriteRawAsync(HttpContext context, string text, CancellationToken ct)
    {
        var bytes = Encoding.UTF8.GetBytes(text);
        await context.Response.Body.WriteAsync(bytes, ct);
        await context.Response.Body.FlushAsync(ct);
    }

    private static async Task<bool> IsTerminalAsync(IJobRepository jobs, JobId jobId, CancellationToken ct)
    {
        var job = await jobs.GetAsync(jobId, ct);
        return job is not null && RunStateMachine.IsTerminal(job.Status);
    }

    private static IResult NotFound(string entity, Guid id)
    {
        return Results.Problem(detail: $"{entity} '{id}' was not found.", title: "Not found", statusCode: StatusCodes.Status404NotFound);
    }
}
