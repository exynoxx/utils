namespace Cicd.Server.Endpoints;

/// <summary>Anonymous liveness probe.</summary>
public static class HealthEndpoints
{
    public static void Map(RouteGroupBuilder group)
    {
        group.MapGet("/healthz", () => Results.Text("ok"));
    }
}
