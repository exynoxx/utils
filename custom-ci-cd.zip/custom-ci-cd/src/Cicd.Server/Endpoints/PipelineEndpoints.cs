using Cicd.Contracts;
using Cicd.Core.Definition;
using Cicd.Core.Domain;
using Cicd.Core.Execution;
using Cicd.Core.Storage;
using Cicd.Server.Mapping;
using Cicd.Server.Services;

namespace Cicd.Server.Endpoints;

/// <summary>Pipeline CRUD, validation, and run creation/history endpoints.</summary>
public static class PipelineEndpoints
{
    public static void Map(RouteGroupBuilder group)
    {
        var pipelines = group.MapGroup("/pipelines");

        pipelines.MapGet("/", ListAsync);
        pipelines.MapPost("/", RegisterAsync);
        pipelines.MapGet("/{pipelineId:guid}", GetAsync);
        pipelines.MapPut("/{pipelineId:guid}", UpdateAsync);
        pipelines.MapDelete("/{pipelineId:guid}", DeleteAsync);
        pipelines.MapPost("/validate", ValidateAsync);
        pipelines.MapPost("/{pipelineId:guid}/validate", ValidateByIdAsync);
        pipelines.MapPost("/{pipelineId:guid}/runs", CreateRunAsync);
        pipelines.MapGet("/{pipelineId:guid}/runs", ListRunsAsync);
    }

    private static async Task<IResult> ListAsync(
        IPipelineRepository repository,
        int? page,
        int? pageSize,
        CancellationToken ct)
    {
        var resolvedPage = page is > 0 ? page.Value : 1;
        var resolvedSize = pageSize is > 0 ? pageSize.Value : 100;
        var skip = (resolvedPage - 1) * resolvedSize;

        var result = await repository.ListAsync(skip, resolvedSize, ct);
        var items = result.Items.Select(p => p.ToDto()).ToList();
        return Results.Ok(new PagedResult<PipelineDto>(items, result.TotalCount, resolvedPage, resolvedSize));
    }

    private static async Task<IResult> RegisterAsync(
        RegisterPipelineRequest request,
        PipelineRegistrationService registration,
        IPipelineRepository repository,
        CancellationToken ct)
    {
        var resolution = await registration.ResolveAsync(request.Name, request.RepoUrl, request.Yaml, ct);
        if (!resolution.Success)
        {
            return ValidationProblem(resolution.Errors);
        }

        var pipeline = new Pipeline
        {
            Id = PipelineId.New(),
            Name = resolution.Name!,
            RepoUrl = resolution.RepoUrl,
            RawYaml = resolution.RawYaml,
            CreatedAt = DateTimeOffset.UtcNow
        };

        var created = await repository.CreateAsync(pipeline, ct);
        return Results.Created($"/api/pipelines/{created.Id.Value}", created.ToDetailDto());
    }

    private static async Task<IResult> GetAsync(Guid pipelineId, IPipelineRepository repository, CancellationToken ct)
    {
        var pipeline = await repository.GetAsync(new PipelineId(pipelineId), ct);
        return pipeline is null
            ? NotFound("Pipeline", pipelineId)
            : Results.Ok(pipeline.ToDetailDto());
    }

    private static async Task<IResult> UpdateAsync(
        Guid pipelineId,
        UpdatePipelineRequest request,
        PipelineRegistrationService registration,
        IPipelineRepository repository,
        CancellationToken ct)
    {
        var existing = await repository.GetAsync(new PipelineId(pipelineId), ct);
        if (existing is null)
        {
            return NotFound("Pipeline", pipelineId);
        }

        // Fall back to the existing values when a field is not supplied.
        var repoUrl = request.RepoUrl ?? existing.RepoUrl;
        var resolution = await registration.ResolveAsync(request.Name ?? existing.Name, repoUrl, request.Yaml, ct);
        if (!resolution.Success)
        {
            return ValidationProblem(resolution.Errors);
        }

        var updated = existing with
        {
            Name = resolution.Name!,
            RepoUrl = resolution.RepoUrl,
            RawYaml = resolution.RawYaml
        };

        var saved = await repository.UpdateAsync(updated, ct);
        return Results.Ok(saved.ToDetailDto());
    }

    private static async Task<IResult> DeleteAsync(Guid pipelineId, IPipelineRepository repository, CancellationToken ct)
    {
        var existing = await repository.GetAsync(new PipelineId(pipelineId), ct);
        if (existing is null)
        {
            return NotFound("Pipeline", pipelineId);
        }

        await repository.DeleteAsync(new PipelineId(pipelineId), ct);
        return Results.NoContent();
    }

    private static IResult ValidateAsync(ValidateRequest request, IPipelineParser parser)
    {
        return Results.Ok(ValidateYaml(request.Yaml, parser));
    }

    private static async Task<IResult> ValidateByIdAsync(
        Guid pipelineId,
        ValidateRequest request,
        IPipelineParser parser,
        IPipelineRepository repository,
        CancellationToken ct)
    {
        var existing = await repository.GetAsync(new PipelineId(pipelineId), ct);
        if (existing is null)
        {
            return NotFound("Pipeline", pipelineId);
        }

        return Results.Ok(ValidateYaml(request.Yaml, parser));
    }

    private static async Task<IResult> CreateRunAsync(
        Guid pipelineId,
        CreateRunRequest request,
        IPipelineRepository repository,
        IPipelineParser parser,
        ManualRunService manualRun,
        IRunScheduler scheduler,
        IRunRepository runs,
        CancellationToken ct)
    {
        var pipeline = await repository.GetAsync(new PipelineId(pipelineId), ct);
        if (pipeline is null)
        {
            return NotFound("Pipeline", pipelineId);
        }

        // Validate the stored YAML parses before creating a run.
        if (pipeline.RawYaml is not null)
        {
            var parse = parser.Parse(pipeline.RawYaml);
            if (!parse.Success)
            {
                return ValidationProblem(parse.Errors);
            }
        }

        var target = await manualRun.ResolveAsync(pipeline, request.Branch, ct);
        if (!target.Success)
        {
            return Results.Problem(detail: target.Error, statusCode: StatusCodes.Status400BadRequest);
        }

        var inputs = request.Inputs is null
            ? new Dictionary<string, string>()
            : new Dictionary<string, string>(request.Inputs);

        var ev = new TriggerEvent(
            pipeline.Id,
            "manual",
            target.Branch!,
            target.CommitSha!,
            [],
            inputs);

        RunId runId;
        try
        {
            runId = await scheduler.CreateRunAsync(pipeline.Id, ev, ct);
        }
        catch (Exception ex)
        {
            return Results.Problem(detail: ex.Message, statusCode: StatusCodes.Status400BadRequest);
        }

        var run = await runs.GetAsync(runId, ct);
        if (run is null)
        {
            return Results.Problem(detail: "Run was created but could not be loaded.", statusCode: 500);
        }

        return Results.Json(run.ToDto(), statusCode: StatusCodes.Status202Accepted);
    }

    private static async Task<IResult> ListRunsAsync(
        Guid pipelineId,
        IPipelineRepository repository,
        IRunRepository runs,
        int? page,
        int? pageSize,
        CancellationToken ct)
    {
        var existing = await repository.GetAsync(new PipelineId(pipelineId), ct);
        if (existing is null)
        {
            return NotFound("Pipeline", pipelineId);
        }

        var resolvedPage = page is > 0 ? page.Value : 1;
        var resolvedSize = pageSize is > 0 ? pageSize.Value : 100;
        var skip = (resolvedPage - 1) * resolvedSize;

        var result = await runs.ListByPipelineAsync(new PipelineId(pipelineId), skip, resolvedSize, ct);
        var items = result.Items.Select(r => r.ToDto()).ToList();
        return Results.Ok(new PagedResult<RunDto>(items, result.TotalCount, resolvedPage, resolvedSize));
    }

    private static ValidationResultDto ValidateYaml(string yaml, IPipelineParser parser)
    {
        var result = parser.Parse(yaml);
        var errors = result.Errors
            .Select(e => new ParseErrorDto(e.Message, e.Line, e.Column))
            .ToList();
        return new ValidationResultDto(result.Success, errors);
    }

    private static IResult ValidationProblem(IReadOnlyList<ParseError> errors)
    {
        var detail = errors.Count > 0
            ? string.Join("; ", errors.Select(FormatError))
            : "The pipeline definition is invalid.";
        return Results.Problem(detail: detail, title: "Invalid pipeline definition", statusCode: StatusCodes.Status400BadRequest);
    }

    private static string FormatError(ParseError error)
    {
        if (error.Line is null)
        {
            return error.Message;
        }

        return error.Column is null
            ? $"line {error.Line}: {error.Message}"
            : $"line {error.Line}, col {error.Column}: {error.Message}";
    }

    private static IResult NotFound(string entity, Guid id)
    {
        return Results.Problem(detail: $"{entity} '{id}' was not found.", title: "Not found", statusCode: StatusCodes.Status404NotFound);
    }
}
