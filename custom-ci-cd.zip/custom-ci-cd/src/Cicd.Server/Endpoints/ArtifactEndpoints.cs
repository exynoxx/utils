using Cicd.Core.Domain;
using Cicd.Core.Storage;
using Cicd.Server.Mapping;

namespace Cicd.Server.Endpoints;

/// <summary>Artifact listing per run and archive download.</summary>
public static class ArtifactEndpoints
{
    public static void Map(RouteGroupBuilder group)
    {
        group.MapGet("/runs/{runId:guid}/artifacts", ListAsync);
        group.MapGet("/artifacts/{artifactId:guid}/download", DownloadAsync);
    }

    private static async Task<IResult> ListAsync(
        Guid runId,
        IArtifactRepository artifacts,
        CancellationToken ct)
    {
        var records = await artifacts.ListByRunAsync(new RunId(runId), ct);
        var dtos = records.Select(a => a.ToDto()).ToList();
        return Results.Ok(dtos);
    }

    private static async Task<IResult> DownloadAsync(
        Guid artifactId,
        IArtifactRepository artifacts,
        IArtifactStore store,
        CancellationToken ct)
    {
        var record = await artifacts.GetAsync(new ArtifactId(artifactId), ct);
        if (record is null)
        {
            return Results.Problem(detail: $"Artifact '{artifactId}' was not found.", title: "Not found", statusCode: StatusCodes.Status404NotFound);
        }

        if (!File.Exists(record.Path))
        {
            return Results.Problem(detail: "The artifact archive is no longer available.", title: "Gone", statusCode: StatusCodes.Status410Gone);
        }

        var stream = store.OpenRead(record.Path);
        var fileName = $"{record.Name}.tar.gz";
        return Results.Stream(stream, "application/gzip", fileName);
    }
}
