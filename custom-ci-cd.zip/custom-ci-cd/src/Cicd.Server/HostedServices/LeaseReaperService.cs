using Cicd.Infrastructure.Persistence;

namespace Cicd.Server.HostedServices;

/// <summary>
/// Hosts the Infrastructure <see cref="LeaseReaper"/>, which periodically requeues jobs whose
/// worker lease has expired (crash recovery).
/// </summary>
public sealed class LeaseReaperService : BackgroundService
{
    private readonly LeaseReaper _reaper;
    private readonly ServerReadiness _readiness;

    public LeaseReaperService(LeaseReaper reaper, ServerReadiness readiness)
    {
        _reaper = reaper;
        _readiness = readiness;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await _readiness.WaitAsync(stoppingToken);
            await _reaper.RunAsync(stoppingToken);
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Normal shutdown.
        }
    }
}
