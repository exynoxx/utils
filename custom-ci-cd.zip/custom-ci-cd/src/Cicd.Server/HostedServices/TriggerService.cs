using Cicd.Core.Execution;
using Cicd.Core.Storage;
using Cicd.Core.Triggers;
using Cicd.Infrastructure.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Cicd.Server.HostedServices;

/// <summary>
/// Runs the trigger sources (push polling, schedule cron, fileWatch) concurrently. Each emitted
/// <see cref="TriggerEvent"/> is filtered by the source itself and handed to the run scheduler.
/// Failures handling a single event are caught and logged so one bad pipeline cannot stall the
/// others.
/// </summary>
public sealed class TriggerService : BackgroundService
{
    private readonly IPipelineCatalog _catalog;
    private readonly IRepoBranchStateStore _branchState;
    private readonly GitCli _git;
    private readonly IRunScheduler _scheduler;
    private readonly TimeProvider _clock;
    private readonly CicdOptions _options;
    private readonly ServerReadiness _readiness;
    private readonly ILoggerFactory _loggerFactory;
    private readonly ILogger<TriggerService> _logger;

    public TriggerService(
        IPipelineCatalog catalog,
        IRepoBranchStateStore branchState,
        GitCli git,
        IRunScheduler scheduler,
        TimeProvider clock,
        IOptions<CicdOptions> options,
        ServerReadiness readiness,
        ILoggerFactory loggerFactory,
        ILogger<TriggerService> logger)
    {
        _catalog = catalog;
        _branchState = branchState;
        _git = git;
        _scheduler = scheduler;
        _clock = clock;
        _options = options.Value;
        _readiness = readiness;
        _loggerFactory = loggerFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await _readiness.WaitAsync(stoppingToken);
        }
        catch (OperationCanceledException)
        {
            return;
        }

        var sources = BuildSources();
        var loops = sources.Select(source => ConsumeAsync(source, stoppingToken)).ToArray();

        try
        {
            await Task.WhenAll(loops);
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Normal shutdown.
        }
    }

    private IReadOnlyList<ITriggerSource> BuildSources()
    {
        var push = new PushTriggerSource(
            _options.EffectiveMirrorRoot,
            TimeSpan.FromSeconds(_options.GitPollIntervalSeconds),
            _catalog,
            _branchState,
            _git,
            _loggerFactory.CreateLogger<PushTriggerSource>());

        var schedule = new ScheduleTriggerSource(
            _catalog,
            _clock,
            _loggerFactory.CreateLogger<ScheduleTriggerSource>());

        var fileWatch = new FileWatchTriggerSource(
            _catalog,
            _loggerFactory.CreateLogger<FileWatchTriggerSource>());

        return [push, schedule, fileWatch];
    }

    private async Task ConsumeAsync(ITriggerSource source, CancellationToken ct)
    {
        _logger.LogInformation("Trigger source '{On}' started", source.On);
        try
        {
            await foreach (var ev in source.WatchAsync(ct))
            {
                await HandleEventAsync(source, ev, ct);
            }
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // Normal shutdown.
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Trigger source '{On}' terminated unexpectedly", source.On);
        }
    }

    private async Task HandleEventAsync(ITriggerSource source, TriggerEvent ev, CancellationToken ct)
    {
        try
        {
            var runId = await _scheduler.CreateRunAsync(ev.PipelineId, ev, ct);
            _logger.LogInformation(
                "Trigger '{On}' created run {RunId} for pipeline {PipelineId} ({Branch}@{Sha})",
                source.On, runId, ev.PipelineId, ev.Branch, ev.CommitSha);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to create run from '{On}' event for pipeline {PipelineId}",
                source.On, ev.PipelineId);
        }
    }
}
