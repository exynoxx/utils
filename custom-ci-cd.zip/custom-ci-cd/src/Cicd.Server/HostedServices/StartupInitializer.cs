using Cicd.Infrastructure.DependencyInjection;
using Cicd.Infrastructure.Persistence;
using Microsoft.Extensions.Options;

namespace Cicd.Server.HostedServices;

/// <summary>
/// One-shot startup work, run before the background services begin processing:
/// <list type="number">
/// <item>Ensures the data directories exist.</item>
/// <item>Initializes the database schema (with a short retry loop so the server tolerates Postgres
/// still starting up under docker compose).</item>
/// <item>Creates the bootstrap admin token if no tokens exist yet, logging it prominently once.</item>
/// </list>
/// </summary>
public sealed class StartupInitializer : IHostedService
{
    private const int MaxDbAttempts = 30;
    private static readonly TimeSpan RetryDelay = TimeSpan.FromSeconds(2);

    private readonly DatabaseInitializer _databaseInitializer;
    private readonly IApiTokenStore _tokenStore;
    private readonly IConfiguration _configuration;
    private readonly CicdOptions _options;
    private readonly ServerReadiness _readiness;
    private readonly ILogger<StartupInitializer> _logger;

    private Task? _initTask;

    public StartupInitializer(
        DatabaseInitializer databaseInitializer,
        IApiTokenStore tokenStore,
        IConfiguration configuration,
        IOptions<CicdOptions> options,
        ServerReadiness readiness,
        ILogger<StartupInitializer> logger)
    {
        _databaseInitializer = databaseInitializer;
        _tokenStore = tokenStore;
        _configuration = configuration;
        _options = options.Value;
        _readiness = readiness;
        _logger = logger;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        // Run initialization in the background so Kestrel can start listening immediately
        // (keeping /api/healthz available while Postgres is still starting under compose).
        _initTask = Task.Run(() => InitializeAsync(cancellationToken), cancellationToken);
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }

    private async Task InitializeAsync(CancellationToken ct)
    {
        try
        {
            EnsureDataDirectories();
            await InitializeDatabaseWithRetryAsync(ct);
            await EnsureBootstrapTokenAsync(ct);
            _readiness.MarkReady();
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            // Shutting down before initialization completed.
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Startup initialization failed; workers and triggers will not start");
        }
    }

    private void EnsureDataDirectories()
    {
        foreach (var dir in new[]
                 {
                     _options.DataRoot,
                     _options.EffectiveLogRoot,
                     _options.EffectiveCacheRoot,
                     _options.EffectiveArtifactRoot,
                     _options.EffectiveMirrorRoot
                 })
        {
            try
            {
                Directory.CreateDirectory(dir);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not create data directory {Dir}", dir);
            }
        }
    }

    private async Task InitializeDatabaseWithRetryAsync(CancellationToken ct)
    {
        for (var attempt = 1; attempt <= MaxDbAttempts; attempt++)
        {
            try
            {
                await _databaseInitializer.InitializeDatabaseAsync(ct);
                _logger.LogInformation("Database schema is ready");
                return;
            }
            catch (Exception ex) when (attempt < MaxDbAttempts)
            {
                _logger.LogWarning(
                    "Database not ready (attempt {Attempt}/{Max}): {Message}. Retrying in {Delay}s...",
                    attempt, MaxDbAttempts, ex.Message, RetryDelay.TotalSeconds);
                await Task.Delay(RetryDelay, ct);
            }
        }

        // Final attempt: let the exception propagate so startup fails loudly.
        await _databaseInitializer.InitializeDatabaseAsync(ct);
    }

    private async Task EnsureBootstrapTokenAsync(CancellationToken ct)
    {
        var existing = await _tokenStore.ListAsync(ct);
        if (existing.Count > 0)
        {
            return;
        }

        var configured = _configuration["Cicd:BootstrapToken"];
        string rawToken;
        if (!string.IsNullOrWhiteSpace(configured))
        {
            rawToken = configured;
            await _tokenStore.CreateBootstrapAsync("bootstrap-admin", rawToken, ct);
        }
        else
        {
            var (_, generated) = await _tokenStore.CreateAsync("bootstrap-admin", ct);
            rawToken = generated;
        }

        _logger.LogWarning(
            "==================================================================\n" +
            "  CICD BOOTSTRAP ADMIN TOKEN (shown once):\n\n    {Token}\n\n" +
            "  Configure the CLI:  cicd config set-server http://localhost:8080 --token {Token}\n" +
            "==================================================================",
            rawToken, rawToken);
    }
}
