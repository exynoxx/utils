namespace Cicd.Server.HostedServices;

/// <summary>
/// A readiness gate set once startup initialization (schema + bootstrap token) has completed.
/// The worker pool and trigger service await this before they begin processing, while Kestrel is
/// free to start listening immediately (so <c>/api/healthz</c> is available during DB startup).
/// </summary>
public sealed class ServerReadiness
{
    private readonly TaskCompletionSource _ready =
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    public Task WaitAsync(CancellationToken ct)
    {
        return _ready.Task.WaitAsync(ct);
    }

    public void MarkReady()
    {
        _ready.TrySetResult();
    }
}
