using Cicd.Core.Execution;
using Cicd.Infrastructure.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Cicd.Server.HostedServices;

/// <summary>
/// Hosts the Core <see cref="WorkerCoordinator"/>, spawning N in-process worker loops that claim,
/// execute and complete jobs. N comes from <c>Cicd:WorkerCount</c>.
/// </summary>
public sealed class WorkerPoolService : BackgroundService
{
    private readonly WorkerCoordinator _coordinator;
    private readonly CicdOptions _options;
    private readonly ServerReadiness _readiness;
    private readonly ILogger<WorkerPoolService> _logger;

    public WorkerPoolService(
        WorkerCoordinator coordinator,
        IOptions<CicdOptions> options,
        ServerReadiness readiness,
        ILogger<WorkerPoolService> logger)
    {
        _coordinator = coordinator;
        _options = options.Value;
        _readiness = readiness;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await _readiness.WaitAsync(stoppingToken);
        }
        catch (OperationCanceledException)
        {
            return;
        }

        _logger.LogInformation("Starting {Count} worker(s)", _options.WorkerCount);
        try
        {
            await _coordinator.RunWorkersAsync(_options.WorkerCount, stoppingToken);
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Normal shutdown.
        }
    }
}
