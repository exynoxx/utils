using Cicd.Infrastructure.Persistence;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Primitives;

namespace Cicd.Server.Auth;

/// <summary>
/// Guards every <c>/api</c> route with an API token, validated by hash against
/// <see cref="IApiTokenStore"/>. Tokens may be presented as an <c>Authorization: Bearer</c> header
/// or an <c>?access_token=</c> query parameter (the latter is needed by browser
/// <c>EventSource</c> log streaming and artifact download links, which cannot set headers).
///
/// Anonymous routes: <c>/api/healthz</c> and any non-<c>/api</c> path (the SPA and static assets).
/// </summary>
public sealed class TokenAuthMiddleware
{
    private const string ApiPrefix = "/api";

    private readonly RequestDelegate _next;

    public TokenAuthMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context, IApiTokenStore tokenStore)
    {
        var path = context.Request.Path;

        // Only /api routes are protected; everything else (SPA) is anonymous.
        if (!path.StartsWithSegments(ApiPrefix, StringComparison.OrdinalIgnoreCase))
        {
            await _next(context);
            return;
        }

        // Health check is anonymous so liveness probes work without a token.
        if (path.StartsWithSegments("/api/healthz", StringComparison.OrdinalIgnoreCase))
        {
            await _next(context);
            return;
        }

        var token = ExtractToken(context.Request);
        if (string.IsNullOrWhiteSpace(token))
        {
            await WriteUnauthorizedAsync(context, "A bearer token is required.");
            return;
        }

        var name = await tokenStore.ValidateAsync(token, context.RequestAborted);
        if (name is null)
        {
            await WriteUnauthorizedAsync(context, "The provided token is invalid.");
            return;
        }

        await _next(context);
    }

    private static string? ExtractToken(HttpRequest request)
    {
        if (request.Headers.TryGetValue("Authorization", out StringValues authorization))
        {
            var value = authorization.ToString();
            const string prefix = "Bearer ";
            if (value.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                return value[prefix.Length..].Trim();
            }
        }

        if (request.Query.TryGetValue("access_token", out StringValues accessToken))
        {
            return accessToken.ToString();
        }

        return null;
    }

    private static async Task WriteUnauthorizedAsync(HttpContext context, string detail)
    {
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        context.Response.ContentType = "application/problem+json";
        await context.Response.WriteAsJsonAsync(new
        {
            type = "https://tools.ietf.org/html/rfc9110#section-15.5.2",
            title = "Unauthorized",
            status = StatusCodes.Status401Unauthorized,
            detail,
            instance = context.Request.GetEncodedPathAndQuery()
        });
    }
}
