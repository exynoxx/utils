using System.Text.Json.Serialization;

namespace Cicd.Contracts;

[JsonConverter(typeof(JsonStringEnumConverter<RunStatusDto>))]
public enum RunStatusDto
{
    Queued,
    Running,
    Succeeded,
    Failed,
    Canceled
}

[JsonConverter(typeof(JsonStringEnumConverter<JobStatusDto>))]
public enum JobStatusDto
{
    Pending,
    Queued,
    Running,
    Succeeded,
    Failed,
    Skipped,
    Canceled
}

[JsonConverter(typeof(JsonStringEnumConverter<StepStatusDto>))]
public enum StepStatusDto
{
    Pending,
    Running,
    Succeeded,
    Failed,
    Skipped
}
