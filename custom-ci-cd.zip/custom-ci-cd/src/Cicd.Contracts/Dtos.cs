namespace Cicd.Contracts;

public sealed record PipelineDto(
    Guid Id,
    string Name,
    string? RepoUrl,
    bool HasRawYaml,
    DateTimeOffset CreatedAt);

public sealed record PipelineDetailDto(
    Guid Id,
    string Name,
    string? RepoUrl,
    bool HasRawYaml,
    DateTimeOffset CreatedAt,
    string? RawYaml);

public sealed record RegisterPipelineRequest(
    string? Name,
    string? RepoUrl,
    string? Yaml);

public sealed record UpdatePipelineRequest(
    string? Name,
    string? RepoUrl,
    string? Yaml);

public sealed record ValidateRequest(string Yaml);

public sealed record ValidationResultDto(
    bool IsValid,
    IReadOnlyList<ParseErrorDto> Errors);

public sealed record ParseErrorDto(
    string Message,
    int? Line,
    int? Column);

public sealed record CreateRunRequest(
    string? Branch,
    IReadOnlyDictionary<string, string>? Inputs);

public sealed record RunDto(
    Guid Id,
    Guid PipelineId,
    string TriggerOn,
    string Branch,
    string CommitSha,
    RunStatusDto Status,
    DateTimeOffset CreatedAt,
    DateTimeOffset? StartedAt,
    DateTimeOffset? FinishedAt);

public sealed record RunDetailDto(
    Guid Id,
    Guid PipelineId,
    string TriggerOn,
    string Branch,
    string CommitSha,
    RunStatusDto Status,
    DateTimeOffset CreatedAt,
    DateTimeOffset? StartedAt,
    DateTimeOffset? FinishedAt,
    IReadOnlyList<JobDto> Jobs);

public sealed record JobDto(
    Guid Id,
    Guid RunId,
    string Name,
    string Image,
    IReadOnlyList<string> Needs,
    JobStatusDto Status,
    int Attempt,
    DateTimeOffset? StartedAt,
    DateTimeOffset? FinishedAt,
    IReadOnlyList<StepDto> Steps);

public sealed record StepDto(
    int Ordinal,
    string Name,
    StepStatusDto Status,
    int? ExitCode,
    DateTimeOffset? StartedAt,
    DateTimeOffset? FinishedAt);

public sealed record ArtifactDto(
    Guid Id,
    Guid RunId,
    Guid JobId,
    string Name,
    long SizeBytes,
    DateTimeOffset? ExpiresAt,
    DateTimeOffset CreatedAt);

public sealed record SecretDto(
    string Name,
    string Scope,
    Guid? PipelineId);

public sealed record SetSecretRequest(
    string Value,
    string Scope,
    Guid? PipelineId);

public sealed record ApiTokenDto(
    Guid Id,
    string Name,
    DateTimeOffset CreatedAt,
    DateTimeOffset? LastUsedAt);

public sealed record CreateTokenRequest(string Name);

public sealed record CreateTokenResponse(Guid Id, string Token);

public sealed record PagedResult<T>(
    IReadOnlyList<T> Items,
    int Total,
    int Page,
    int PageSize);
