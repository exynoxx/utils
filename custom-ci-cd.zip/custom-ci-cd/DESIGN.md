# Cicd — Local-Hostable CI/CD Tool: Design

A greenfield, self-hostable CI/CD system.

**Stack decisions (locked in):**
- C# / .NET (LTS), ASP.NET Core server
- Docker containers per job from day one (`executor: docker`; the executor field keeps the door open for `shell`, remote agents, etc.)
- PostgreSQL for state (queue via `FOR UPDATE SKIP LOCKED`), filesystem for logs/caches/artifacts
- Single node, N parallel in-process workers (configurable), abstracted so remote agents can come later
- Triggers v1: push (git polling), fileWatch, manual; schedule (cron) in Phase 2; pluggable for webhooks later
- Extensibility: everything bottoms out in "run arbitrary commands in an arbitrary image"; built-in step types and YAML step templates are sugar on top
- Web UI (React + Vite SPA) + REST API + CLI; API-first, UI and CLI both consume the REST API
- No unit tests / test projects in this codebase

---

## 1. YAML Pipeline Schema

### 1.1 Locations
- **In-repo**: `.pipeline.yml` at repo root (additional pipelines under `.pipelines/*.yml`) — read from the checked-out commit by push triggers.
- **Standalone**: a pipeline file registered directly with the server (file-watch dev loops, ad-hoc pipelines). Stored in Postgres.
- **Templates**: `.pipelines/templates/*.yml` in-repo, or server-registered library entries. Referenced by `uses:`.

### 1.2 Top-level schema

```yaml
# .pipeline.yml
version: 1
name: backend            # optional; defaults to file/repo name

# A "step" is just: an executor + a command + I/O contract.
# Nothing in the engine knows what "deploy" means.

triggers:
  - on: push             # detected via git polling (webhook later, same event)
    branches: [main, "release/*"]
    paths: ["src/**", "*.csproj"]     # changed-file globs; empty = any
  - on: schedule
    cron: "0 3 * * *"
  - on: fileWatch        # local dev loop
    directories: ["./src"]
    patterns: ["**/*.cs"]
    debounce: 800ms
  - on: manual           # button / API call
    inputs:
      target: { type: enum, values: [staging, prod] }

# Global defaults, overridable per-job
defaults:
  executor: docker
  image: alpine:3.20
  timeout: 30m

variables:               # plain (non-secret) env, available to all jobs
  BUILD_CONFIG: Release

jobs:
  build:
    image: golang:1.23
    cache:
      key: "go-${{ hash('go.sum') }}"
      restoreKeys: ["go-"]            # prefix fallback
      paths: [/go/pkg/mod]
    steps:
      - run: go build -o app ./...
    artifacts:
      paths: [app]
      expire: 7d

  test:
    needs: [build]       # DAG edge; artifacts of needed jobs auto-restored
    parallel:            # fan-out, results fan back in
      matrix:
        suite: [unit, integration, e2e]
    steps:
      - run: go test ./... -run ${{ matrix.suite }}
```

### 1.3 Field reference

**Pipeline**: `version` (required, `1`), `name` (optional), `triggers[]`, `defaults{}`, `variables{}`, `jobs{}`.

**Triggers** (`on:` discriminator):
- `on: push` — `branches[]` (globs), `paths[]` (changed-file globs). Detected by git polling in v1; a webhook later emits the same event.
- `on: schedule` — `cron` (5-field cron expression).
- `on: fileWatch` — `directories[]`, `patterns[]`, `debounce` (duration).
- `on: manual` — optional typed `inputs{}`: `{ type: string|enum|bool, values?, default?, required? }`; available as `${{ inputs.NAME }}`.

**Defaults** (`defaults:`): `executor` (`docker` in v1; field exists so `shell`/remote executors slot in later), `image`, `timeout`. Every job-level field here is overridable per job.

**Job** (`jobs.<id>`):
- `executor`, `image` — from `defaults` unless overridden. `image` required once defaults+job are merged (for `docker`).
- `steps[]` (required, run sequentially in a shared workspace volume).
- `needs[]` — job IDs that must succeed first (forms the DAG). Artifacts of `needs` jobs are auto-restored into the workspace.
- `if` — condition expression (1.6).
- `env{}` — overrides pipeline `variables`.
- `cache` — `{key, restoreKeys[], paths[]}` (or a list of these for multiple caches).
- `artifacts` — `{paths[], expire?}` declarative publish block; tarred after steps succeed.
- `timeout` — duration string (`30m`, `2h`); `retries` — int.
- `parallel.matrix{}` — fan-out (1.7). `services[]` — Phase 3 sidecars (1.8).

**Durations**: human strings everywhere — `800ms`, `30s`, `30m`, `2h`, `7d` — parsed by one small duration parser.

**Step** — four shapes, all bottoming out in "run commands in a container":
1. Shell string: `- run: go build ./...` (uses job `image`).
2. Shell object: `{ name, run, image?, env?, workdir?, if? }` — per-step image override.
3. Typed built-in: `uses: <type>` + `with:` (1.4).
4. Template invocation: `uses: ./.pipelines/templates/x.yml` + `with:` (1.5).

**Decision**: `uses:` is one keyword for both built-ins and templates — built-in registry resolved first, then templates. Anything unanticipated falls back to a raw `run:` step.

### 1.4 Built-in step types (expanders, not subsystems)

| `uses:` | `with:` inputs | Expands to |
|---|---|---|
| `cache/restore` | `key, restoreKeys, paths` | tar restore from server cache store (job `cache:` block is sugar for restore+save around steps) |
| `cache/save` | `key, paths` | tar + store |
| `artifact/upload` | `name, paths, expire?` | explicit upload mid-job (job `artifacts:` block is sugar for this after last step) |
| `artifact/download` | `name, [job]` | explicit fetch (auto-restore via `needs` covers the common case) |
| `nuget/auth` | `feedUrl, usernameSecret?, passwordSecret` | writes `NuGet.Config` with credentials from secrets |
| `npm/auth` | `registry, tokenSecret` | writes `.npmrc` |
| `checkout` | `ref?, submodules?` | git clone/checkout (auto-injected as step 0 for push pipelines unless disabled) |

Authenticated feed bottoms out in shell + secrets — `nuget/auth` is sugar for:

```yaml
- run: |
    cat > NuGet.Config <<'EOF'
    <configuration><packageSources>
      <add key="Private" value="https://pkgs.example.com/_packaging/Feed/nuget/v3/index.json"/>
    </packageSources><packageSourceCredentials><Private>
      <add key="Username" value="user"/>
      <add key="ClearTextPassword" value="$FEED_PAT"/>
    </Private></packageSourceCredentials></configuration>
    EOF
  env:
    FEED_PAT: ${{ secrets.FEED_PAT }}
```

### 1.5 Reusable templates

Definition — `.pipelines/templates/dotnet-restore.yml`:
```yaml
version: 1
kind: stepTemplate
name: dotnet-restore-cached
inputs:
  lockGlob:  { type: string, default: "**/packages.lock.json" }
  feedUrl:   { type: string, required: true }
  patSecret: { type: string, required: true }
steps:
  - uses: cache/restore
    with:
      key: "nuget-${{ hash(inputs.lockGlob) }}"
      restoreKeys: ["nuget-"]
      paths: [/workspace/.nuget]
  - uses: nuget/auth
    with: { feedUrl: "${{ inputs.feedUrl }}", passwordSecret: "${{ inputs.patSecret }}" }
  - run: dotnet restore
  - uses: cache/save
    with: { key: "nuget-${{ hash(inputs.lockGlob) }}", paths: [/workspace/.nuget] }
```

Usage:
```yaml
steps:
  - uses: ./.pipelines/templates/dotnet-restore.yml
    with:
      feedUrl: "https://pkgs.example.com/.../index.json"
      patSecret: AZDO_PAT
  - run: dotnet build -c Release --no-restore
```

Resolution: recursive expansion at parse time, depth limit 10, cycle detection; `${{ inputs.* }}` substituted into expanded steps. Templates produce **steps only**, never jobs (the DAG stays owned by the pipeline). Template `inputs` share the typed-inputs shape used by `on: manual`.

### 1.6 Expression language (`${{ }}` and `if:`) — deliberately minimal
- Identifiers: `branch`, `event` (`push`|`schedule`|`fileWatch`|`manual`), `status.<jobId>` (`success`|`failed`|`skipped`), `vars.<NAME>`, `inputs.<NAME>` (manual-trigger or template inputs), `matrix.<key>`, `secrets.<NAME>` (presence only in `if:`; value only in `env:`/`with:`).
- Operators: `==`, `!=`, `&&`, `||`, `!`, parentheses, string literals.
- Functions: `hash(glob, ...)` — content hash of matching files.
- Implemented as a tiny hand-written recursive-descent parser + evaluator. No general scripting.

### 1.7 Parallel fan-out (matrix)
```yaml
test:
  needs: [build]
  parallel:
    matrix:
      suite: [unit, integration, e2e]
      dotnet: ["8.0", "9.0"]      # multiple axes = cross product
  image: "mcr.microsoft.com/dotnet/sdk:${{ matrix.dotnet }}"
  steps:
    - run: dotnet test --filter Category=${{ matrix.suite }}
```
Expands to one job per combination (`test (suite=unit, dotnet=8.0)` …) before DAG scheduling; results fan back in — dependents of `test` wait for all expansions. Phase 3.

### 1.8 Services / sidecars (Phase 3)
```yaml
integration:
  image: mcr.microsoft.com/dotnet/sdk:9.0
  services:
    - name: db
      image: postgres:16
      env: { POSTGRES_PASSWORD: test }
```
Worker starts sidecars on a per-job Docker network, injects hostnames, tears down after.

### 1.9 Secrets
- Referenced as `${{ secrets.NAME }}` in `env:` values and `with:` inputs.
- Stored in Postgres, encrypted at rest (AES-GCM, master key from `CICD_MASTER_KEY`). Scopes: global + per-pipeline.
- Injected as env vars only for steps that reference them.
- **Masking**: every secret value registered with the log pipeline; writer replaces occurrences with `***` before persisting/streaming.

### 1.10 Example — dotnet build/test with private feed + cache

```yaml
# .pipeline.yml
version: 1
name: backend
triggers:
  - on: push
    branches: [main, "feature/*"]
    paths: ["src/**"]
  - on: manual
variables: { BUILD_CONFIG: Release }
defaults:
  executor: docker
  image: mcr.microsoft.com/dotnet/sdk:9.0
  timeout: 25m
jobs:
  build:
    env: { NUGET_PACKAGES: /workspace/.nuget }
    steps:
      - uses: ./.pipelines/templates/dotnet-restore.yml
        with:
          feedUrl: "https://pkgs.example.com/.../index.json"
          patSecret: AZDO_PAT
      - run: dotnet build -c $BUILD_CONFIG --no-restore
    artifacts:
      paths: ["**/bin/Release/**"]
      expire: 7d
  test:
    needs: [build]       # build artifacts auto-restored
    steps:
      - run: dotnet test -c $BUILD_CONFIG --no-build --logger trx
    artifacts:
      paths: ["**/TestResults/**"]
      expire: 14d
```

### 1.11 Example — docker build + push + k8s deploy (k8s is just a step)

```yaml
version: 1
name: ship
triggers:
  - on: push
    branches: [main]
  - on: manual
    inputs:
      target: { type: enum, values: [staging, prod], default: staging }
variables: { IMAGE: registry.example.com/app }
jobs:
  image:
    image: docker:27-cli          # talks to mounted docker socket
    steps:
      - uses: checkout
      - run: docker build -t $IMAGE:$CICD_SHORT_SHA .
      - run: echo "$REG_PASS" | docker login registry.example.com -u "$REG_USER" --password-stdin
        env:
          REG_USER: ${{ secrets.REGISTRY_USER }}
          REG_PASS: ${{ secrets.REGISTRY_PASS }}
      - run: docker push $IMAGE:$CICD_SHORT_SHA
  deploy:
    image: alpine/helm:3.16        # k8s deploy = a step running a helm image, no special subsystem
    needs: [image]
    if: "branch == 'main' || inputs.target == 'prod'"
    steps:
      - uses: checkout
      - run: |
          mkdir -p ~/.kube && echo "$KUBECONFIG_B64" | base64 -d > ~/.kube/config
          helm upgrade --install app ./chart --set image.tag=$CICD_SHORT_SHA
        env:
          KUBECONFIG_B64: ${{ secrets.KUBECONFIG_B64 }}
```

### 1.12 Example — file-watch dev loop

```yaml
version: 1
name: dev-loop
triggers:
  - on: fileWatch
    directories: ["."]
    patterns: ["**/*.cs", "**/*.csproj"]
    debounce: 600ms
defaults:
  executor: docker
  image: mcr.microsoft.com/dotnet/sdk:9.0
  timeout: 5m
jobs:
  quick:
    steps:
      # No git checkout: worker copies the watched local dir into the workspace volume.
      - run: dotnet build -c Debug
      - run: dotnet test --filter Category=Fast --no-build
```

### 1.13 Built-in env vars (every step)
`CICD_RUN_ID`, `CICD_JOB_ID`, `CICD_PIPELINE`, `CICD_BRANCH`, `CICD_SHA`, `CICD_SHORT_SHA`, `CICD_EVENT`, `CICD_WORKSPACE` (= `/workspace`).

---

## 2. Solution / Project Structure

**Web UI: React + Vite SPA** served as static assets by ASP.NET Core — live log streaming and an interactive DAG view need a real SPA; keeps the server strictly API-first.

```
custom-ci-cd/
  Cicd.sln
  Directory.Build.props          # LangVersion, Nullable=enable, ImplicitUsings
  docker-compose.yml
  Dockerfile
  src/
    Cicd.Core/                   # domain + application logic; no ASP.NET/EF leakage
      Domain/                    # records, value IDs, state machines
      Definition/                # YAML model + parser + validator + template expander + expr eval
      Execution/                 # scheduler, worker pool, executor abstraction
      Triggers/                  # ITriggerSource + implementations
      Storage/                   # repository/log/cache/artifact interfaces
      Secrets/                   # encryption + secret resolver + log masking
    Cicd.Infrastructure/         # EF Core (Npgsql) repos, filesystem stores, Docker.DotNet runtime
    Cicd.Contracts/              # shared DTOs for REST (Server + Cli)
    Cicd.Server/                 # ASP.NET Core: minimal API endpoints, SSE, hosted services, wwwroot
    Cicd.Cli/                    # System.CommandLine CLI, references Cicd.Contracts only
  web/                           # React + Vite SPA (built into Cicd.Server/wwwroot on publish)
```

Dependency direction: `Server → Infrastructure → Core`; `Server/Infrastructure → Contracts`; `Cli → Contracts` only (pure REST client). `Core` depends only on BCL + YamlDotNet.

---

## 3. Core Domain & Execution Model

### 3.1 Value-type identifiers
```csharp
public abstract record NonEmptyGuidValue
{
    public Guid Value { get; init; }
    protected NonEmptyGuidValue(Guid value)
    {
        if (value == Guid.Empty) { throw new ArgumentException("Guid must not be empty."); }
        Value = value;
    }
}
public sealed record PipelineId(Guid Value) : NonEmptyGuidValue(Value);
public sealed record RunId(Guid Value)      : NonEmptyGuidValue(Value);
public sealed record JobId(Guid Value)      : NonEmptyGuidValue(Value);
public sealed record StepId(Guid Value)     : NonEmptyGuidValue(Value);
public sealed record WorkerId(Guid Value)   : NonEmptyGuidValue(Value);
public sealed record SecretId(Guid Value)   : NonEmptyGuidValue(Value);
public sealed record ArtifactId(Guid Value) : NonEmptyGuidValue(Value);
```

### 3.2 Domain records & state machines
```csharp
public enum RunStatus  { Queued, Running, Succeeded, Failed, Canceled }
public enum JobStatus  { Pending, Queued, Running, Succeeded, Failed, Skipped, Canceled }
public enum StepStatus { Pending, Running, Succeeded, Failed, Skipped }
```
- Run: `Queued → Running → {Succeeded|Failed|Canceled}`.
- Job: `Pending → Queued → Running → {Succeeded|Failed|Skipped|Canceled}` (Skipped when `if` false or upstream `needs` failed).
- Step: `Pending → Running → {Succeeded|Failed|Skipped}`.
- Transitions validated centrally (`RunStateMachine.CanTransition(from, to)`).
- `Pipeline`, `Run`, `Job` are immutable records with `init` props (Id, status, timestamps, `Job.Needs`, `Job.Attempt/MaxRetries/Timeout`, `Job.ClaimedBy`).
- Steps persisted lightweight (status + exit code + log offset); full step definition lives in the parsed `JobDefinition`.

### 3.3 Definition layer
```csharp
public sealed record PipelineDefinition   // immutable, post-validation, post-template-expansion
{
    public required int Version { get; init; }
    public required string Name { get; init; }
    public required IReadOnlyList<TriggerDefinition> Triggers { get; init; }
    public required JobDefaults Defaults { get; init; }
    public required IReadOnlyDictionary<string, string> Variables { get; init; }
    public required IReadOnlyDictionary<string, JobDefinition> Jobs { get; init; }
}

public interface IPipelineParser
{
    ParseResult Parse(string yaml);
}
public sealed record ParseResult(PipelineDefinition? Definition, IReadOnlyList<ParseError> Errors);
public sealed record ParseError(string Message, int? Line, int? Column);
```
YamlDotNet with a custom deserializer; capture `Mark` (line/col) to attach line numbers to validation errors. Validation passes: schema/required fields, defaults merge (job image present for docker executor), DAG acyclicity, template existence + required inputs, expression syntax, duration parsing.

### 3.4 Scheduler
```csharp
public interface IRunScheduler
{
    Task<RunId> CreateRunAsync(PipelineId pipelineId, TriggerEvent ev, CancellationToken ct);
    // Expands parallel.matrix, materializes Run + Jobs from the DAG;
    // jobs with no unmet needs → Queued, rest → Pending.
    Task OnJobFinishedAsync(JobId jobId, JobStatus result, CancellationToken ct);
    // Re-evaluates dependents: enqueue newly satisfied, skip those whose needs failed, finish run if terminal.
}
```
Run = Succeeded iff all non-skipped jobs succeeded; Failed if any job failed (after retries).

### 3.5 Executor abstraction (the seam for future remote agents)
```csharp
public interface IJobQueue                 // Postgres-backed; FOR UPDATE SKIP LOCKED
{
    Task EnqueueAsync(JobId jobId, CancellationToken ct);
    Task<ClaimedJob?> ClaimNextAsync(WorkerId worker, CancellationToken ct);
    Task CompleteAsync(JobId jobId, JobStatus status, CancellationToken ct);
    Task<bool> RenewLeaseAsync(JobId jobId, WorkerId worker, CancellationToken ct);  // heartbeat
}

public interface IJobExecutor              // keyed by the YAML `executor:` field
{
    string Type { get; }                   // "docker" (v1); "shell", remote agents later
    Task<JobResult> ExecuteAsync(JobExecutionContext context, CancellationToken ct);
}
```
**Docker access: Docker.DotNet** (typed daemon API) — reliable stdout/stderr demuxing and exit codes, no CLI parsing. `docker build/push` *inside* jobs is user pipeline content via a mounted socket + `docker:cli` image, not our runtime.

### 3.6 Worker pool
`WorkerPool : BackgroundService` hosted in Cicd.Server. Spawns N loop tasks (N from `Cicd:WorkerCount`). Each loop: claim (SKIP LOCKED) → build `JobExecutionContext` (definition slice, env, resolved secrets) → resolve `IJobExecutor` by the job's `executor` → `ExecuteAsync` with timeout (linked CTS) + periodic lease renewal → complete + `OnJobFinishedAsync`. Crash recovery: lease expiry reaper requeues abandoned jobs.

### 3.7 Job execution flow (DockerJobExecutor)
1. Create Docker named volume `cicd-ws-<jobId>` mounted at `/workspace` (shared by all steps).
2. Source: push pipelines → checkout (clone/fetch + checkout SHA); fileWatch → copy watched local dir into volume.
3. Cache restore: exact `key`, then `restoreKeys` prefix; untar into `paths`.
4. Auto-restore artifacts of `needs` jobs into the workspace.
5. Steps: per step, container from step image (default job image), mount workspace, set env (variables + job env + step env + secrets + `CICD_*`), run via `sh -c`. Stream demuxed output through the masking log writer. Non-zero exit → step Failed → job Failed.
6. Cache save: tar declared `paths` → store under `key`.
7. Artifacts: tar `artifacts.paths` → store with `expire` retention.
8. Teardown: remove containers + workspace volume (configurable retain-on-failure for debugging).
9. Report `JobResult(status, exitCode, durations)`.

### 3.8 Logs
- Storage: filesystem `<logRoot>/<runId>/<jobId>.log`, byte offset tracked in DB (`jobs.log_size`).
- Live fan-out: `ILogBroker` — in-memory `Channel<LogChunk>` per job. New subscribers replay file from offset, then attach live (no gap).
- Masking: `SecretMasker` holds active secret values per job; replaces substrings with `***` before persist + fan-out.

### 3.9 Cache & artifact stores
- Cache layout: `<cacheRoot>/<sha256(key)>.tar.zst`; restore-keys = prefix scan, newest match.
- Artifact layout: `<artifactRoot>/<runId>/<jobId>/<name>.tar.zst` + DB row (with `expires_at` from `expire:`); downloadable via API; GC reaper deletes expired.

### 3.10 Cancellation / timeout / retries
- Cancel: `POST /runs/{id}/cancel` sets flag; workers kill containers, mark Canceled.
- Timeout: per-job linked CTS from the `timeout` duration; on fire kill container, mark Failed (timeout).
- Retries: on failure with `Attempt < MaxRetries`, scheduler re-enqueues a fresh attempt (fresh workspace).

---

## 4. Triggers Subsystem

```csharp
public interface ITriggerSource
{
    string On { get; }                                     // "push" | "schedule" | "fileWatch" | "manual"
    IAsyncEnumerable<TriggerEvent> WatchAsync(CancellationToken ct);
}
public sealed record TriggerEvent(
    PipelineId PipelineId,
    string On,
    string Branch,
    string CommitSha,
    IReadOnlyList<string> ChangedPaths,
    IReadOnlyDictionary<string, string> Inputs);           // manual-trigger inputs
```
`TriggerHostedService` (BackgroundService) runs all sources; events filtered (branch globs, path globs) then handed to `IRunScheduler.CreateRunAsync`.

- **PushTrigger (git polling)**: bare mirror per repo under `<mirrorRoot>/<repoHash>.git`; `git fetch` on interval; compares per-branch SHAs vs `repo_branch_state`; `git diff --name-only old new` for path filters. A webhook endpoint later emits the same `push` event.
- **ScheduleTrigger**: cron evaluation loop (Cronos library); fires `TriggerEvent` with the pipeline's default branch head. Phase 2.
- **FileWatchTrigger**: `FileSystemWatcher` per directory; glob filter; debounce (coalesce bursts within `debounce`); synthetic branch `local`, SHA `working-tree`.
- **ManualTrigger**: API/CLI/UI constructs a `TriggerEvent` directly, validating typed `inputs` against the trigger definition.
- Pluggability: sources discovered via DI; webhook is a future drop-in with no scheduler changes.

---

## 5. REST API + Realtime

**Minimal APIs** grouped via `MapGroup`, organized in static endpoint classes (`RunEndpoints.Map(app)`).
**AuthN v1**: per-user API tokens (`api_tokens` table, bearer header, hashed at rest); bootstrap admin token from config; endpoint filter guards everything except SPA assets and `/healthz`.

```
GET    /api/healthz
GET    /api/pipelines
POST   /api/pipelines
GET    /api/pipelines/{pipelineId:guid}
PUT    /api/pipelines/{pipelineId:guid}
DELETE /api/pipelines/{pipelineId:guid}
POST   /api/pipelines/{pipelineId:guid}/validate    # parse-only, line-numbered errors
POST   /api/pipelines/{pipelineId:guid}/runs        # manual trigger {branch?, inputs?}
GET    /api/pipelines/{pipelineId:guid}/runs        # history (paged)
GET    /api/runs/{runId:guid}                       # run + jobs (DAG)
POST   /api/runs/{runId:guid}/cancel
GET    /api/runs/{runId:guid}/jobs/{jobId:guid}
GET    /api/runs/{runId:guid}/jobs/{jobId:guid}/logs           # full / from-offset
GET    /api/runs/{runId:guid}/jobs/{jobId:guid}/logs/stream    # SSE live tail
GET    /api/runs/{runId:guid}/artifacts
GET    /api/artifacts/{artifactId:guid}/download
GET    /api/secrets                                 # names + scope only, never values
PUT    /api/secrets/{name}
DELETE /api/secrets/{name}
POST   /api/tokens   GET /api/tokens   DELETE /api/tokens/{tokenId:guid}
```

**Realtime: SSE** for log tailing — one-way text stream over plain HTTP, auto-reconnect with `Last-Event-ID` mapping to byte offset. WebSocket reserved for future bidirectional needs.

DTOs in `Cicd.Contracts` (`RunDto`, `JobDto`, `PipelineDto`, `LogChunkDto`, `CreateRunRequest`, `SetSecretRequest`) — shared by Server + Cli.

---

## 6. Web UI (v1 scope)

1. **Pipelines** — list, register (paste YAML or repo URL), validate with line-numbered errors, delete.
2. **Runs** — per-pipeline history with status badges + "Run now" (branch picker + typed manual inputs form).
3. **Run detail** — job DAG view (nodes colored by status, edges from `needs`) + live log panel (SSE, auto-scroll, `***` masking), cancel button.
4. **Secrets** — list names/scopes, set/update (write-only value field), delete.

React + Vite; DAG via dagre + SVG; built into `Cicd.Server/wwwroot` with SPA fallback. Token in localStorage, sent as bearer.

---

## 7. CLI

**System.CommandLine** (first-party, async, good help). Thin REST client over `Cicd.Contracts`.

```
cicd config set-server <url> --token <token>      # ~/.cicd/config.json
cicd pipelines list
cicd pipelines register <file.yml> [--repo <url>]
cicd pipelines validate <file.yml>
cicd run <pipelineNameOrId> [--branch <b>] [--input k=v]
cicd status [<runId>]
cicd logs <runId> [--job <name>] [--follow]       # --follow consumes SSE
cicd history <pipelineNameOrId> [--limit N]
cicd secrets set <name> [--scope global|<pipeline>]   # hidden-input prompt
cicd secrets list
cicd cancel <runId>
```

---

## 8. Deploying the Tool Itself

```yaml
# docker-compose.yml
services:
  postgres:
    image: postgres:16
    environment: { POSTGRES_DB: cicd, POSTGRES_PASSWORD: cicd }
    volumes: ["pgdata:/var/lib/postgresql/data"]
  server:
    build: .
    depends_on: [postgres]
    environment:
      ConnectionStrings__Db: "Host=postgres;Database=cicd;Username=postgres;Password=cicd"
      CICD_MASTER_KEY: "${CICD_MASTER_KEY}"
      Cicd__WorkerCount: "4"
    ports: ["8080:8080"]
    volumes:
      - "/var/run/docker.sock:/var/run/docker.sock"   # docker-out-of-docker
      - "cicd-data:/data"                              # logs, caches, artifacts, mirrors
volumes: { pgdata: {}, cicd-data: {} }
```

> **Security tradeoff**: mounting the host docker socket gives the server — and any pipeline — effective root on the host. Acceptable for a single-node trusted self-hosted tool; run on an isolated host. Mitigation path: rootless docker / future remote agents via the `IJobExecutor` seam.

Dev: `dotnet run --project src/Cicd.Server` against local Postgres + host docker socket; SPA via `npm run dev` proxying the API. EF Core migrations applied on startup.

---

## 9. Postgres Tables

```
pipelines(id uuid pk, name text, repo_url text null, raw_yaml text null, created_at timestamptz)
runs(id uuid pk, pipeline_id uuid fk, trigger_on text, branch text, commit_sha text,
     inputs jsonb null, status text, created_at, started_at null, finished_at null)
jobs(id uuid pk, run_id uuid fk, name text, executor text, image text, needs jsonb,
     matrix jsonb null, status text, attempt int, max_retries int, timeout_seconds int,
     claimed_by uuid null, claimed_at null, lease_expires_at null,
     log_size bigint default 0, started_at null, finished_at null)   -- INDEX(status), INDEX(run_id)
   -- claim: SELECT ... WHERE status='Queued' ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1
steps(id uuid pk, job_id uuid fk, ordinal int, name text, status text,
      exit_code int null, started_at null, finished_at null)
secrets(id uuid pk, name text, scope text, pipeline_id uuid null,
        ciphertext bytea, nonce bytea, created_at, UNIQUE(name, scope, pipeline_id))
artifacts(id uuid pk, run_id uuid fk, job_id uuid fk, name text, path text,
          size_bytes bigint, expires_at timestamptz null, created_at)
cache_entries(id uuid pk, key text, path text, size_bytes bigint, created_at, last_used_at)  -- INDEX(key)
repo_branch_state(repo_url text, branch text, last_sha text, PRIMARY KEY(repo_url, branch))
api_tokens(id uuid pk, name text, token_hash bytea, created_at, last_used_at null)
```

---

## 10. Phased Roadmap

**Phase 1 — MVP (runnable end-to-end):**
1. Solution + 5 projects + `Directory.Build.props`.
2. Domain records + value IDs + state machines.
3. YAML parse → `PipelineDefinition` (jobs, shell steps, `needs`, `defaults`, env, variables, durations) with line-numbered validation + DAG check. (No templates/matrix/services yet.)
4. EF Core + Postgres: pipelines/runs/jobs/steps + migrations; `IJobQueue` with SKIP LOCKED.
5. Scheduler + `WorkerPool` (N workers) + `DockerJobExecutor` (workspace volume, sequential steps, exit codes).
6. Filesystem log store + SSE live tail + `ILogBroker`.
7. Minimal API: pipelines register/list, manual trigger, run/job get, logs stream, cancel; bootstrap admin token.
8. CLI: `config`, `pipelines register/list`, `run`, `status`, `logs --follow`, `cancel`.
9. `docker-compose.yml` + `Dockerfile` + README.

**Phase 2 — Triggers, reuse, state-sharing:**
10. `ITriggerSource` + PushTrigger (git polling) + FileWatchTrigger + ScheduleTrigger (cron) + formalized ManualTrigger with typed inputs.
11. Caching (`ICacheStore`, `cache:` block + `cache/restore|save` steps, restore-keys, `hash()`).
12. Artifacts (`IArtifactStore`, `artifacts:` block, `needs` auto-restore, `expire` retention, download API).
13. Secrets: encrypted store, `${{ secrets.* }}` resolution, env injection, log masking, API + CLI.
14. Built-in step registry: `nuget/auth`, `npm/auth`, `checkout`.
15. Templates: `kind: stepTemplate`, `uses:` resolution, typed input substitution, cycle guard.
16. `if:` expression language + job skip semantics.
17. Retries, timeouts, lease reaper / crash recovery.

**Phase 3 — UI + breadth:**
18. React + Vite SPA (pipelines, runs, run detail DAG + live logs, secrets, manual-inputs form).
19. `parallel.matrix` fan-out; services/sidecars; k8s deploy examples (docs).
20. Webhook trigger (drop-in `ITriggerSource`).
21. Hardening: artifact/cache retention GC, tokens UI, retain-workspace-on-failure debug option.

**Forward-compat for distributed agents**: `IJobQueue` + `IJobExecutor` are the only execution seams. A remote agent later is a process calling the same claim/complete API over HTTP running its own `DockerJobExecutor` — no rearchitecting. The YAML `executor:` field already names the abstraction.
