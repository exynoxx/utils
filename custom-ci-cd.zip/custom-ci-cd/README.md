# Cicd — a local-hostable CI/CD tool

Cicd is a single-node, self-hostable CI/CD system. Pipelines are defined in YAML, each job runs in
its own Docker container, and state lives in PostgreSQL. It ships an HTTP REST API, a React SPA, and
a CLI — the SPA and CLI are both thin clients over the API.

See [`DESIGN.md`](./DESIGN.md) for the full design; this README is the operator's quick start.

## What you get

- YAML pipelines: shell + built-in steps, `needs` DAG, matrix fan-out, caches, artifacts, secrets.
- Triggers: `push` (git polling), `schedule` (cron), `fileWatch` (local dev loop), `manual`.
- Docker-per-job execution, N in-process workers, Postgres-backed job queue, live log streaming (SSE).
- Token-authenticated API; per-pipeline and global encrypted secrets.

## Quick start (Docker Compose)

Prerequisites: Docker + Docker Compose, and the `cicd` CLI (`dotnet run --project src/Cicd.Cli`
or a published build).

1. **Set the required environment variables.** `CICD_MASTER_KEY` encrypts secrets at rest;
   `CICD_HOST_DATA_ROOT` must be the *absolute host path* of the `./data` bind mount so the Docker
   daemon can bind job workspaces correctly.

   ```bash
   export CICD_MASTER_KEY="$(openssl rand -base64 32)"
   export CICD_HOST_DATA_ROOT="$PWD/data"
   ```

2. **Start it.**

   ```bash
   docker compose up --build
   ```

3. **Grab the bootstrap admin token** — printed once, prominently, in the server logs on first start:

   ```
   ==================================================================
     CICD BOOTSTRAP ADMIN TOKEN (shown once):

       <a-long-random-token>
   ...
   ```

   (To pin it instead, set `Cicd__BootstrapToken` in `docker-compose.yml` / your `.env`.)

4. **Point the CLI at the server.**

   ```bash
   cicd config set-server http://localhost:8080 --token <the-token>
   ```

5. **Register, run, and tail the smoke-test pipeline.**

   ```bash
   cicd pipelines register examples/hello.yml
   cicd run hello
   cicd logs <runId> --follow
   ```

   Or with plain `curl`:

   ```bash
   TOKEN=<the-token>
   curl -s -H "Authorization: Bearer $TOKEN" \
        -H 'Content-Type: application/json' \
        -d "{\"yaml\": $(jq -Rs . < examples/hello.yml)}" \
        http://localhost:8080/api/pipelines
   ```

The web UI is served at <http://localhost:8080> (paste the token into the UI; it is stored in
`localStorage` and sent as a bearer token).

## docker-compose environment variables

| Variable | Required | Purpose |
|---|---|---|
| `CICD_MASTER_KEY` | **yes** | AES-GCM master key for secret encryption. Compose refuses to start without it. |
| `CICD_HOST_DATA_ROOT` | recommended | Absolute host path of the `./data` bind mount. Defaults to `./data`; set to `$PWD/data` so the Docker daemon resolves job-workspace bind mounts correctly. |
| `CICD_BOOTSTRAP_TOKEN` | optional | Pin the bootstrap admin token (otherwise generated and logged once). Wire via the commented `Cicd__BootstrapToken` line in `docker-compose.yml`. |
| `Cicd__WorkerCount` | optional | Parallel in-process workers (default 4 in compose). |

> The `./data` directory is a **host bind mount**, not a named Docker volume, on purpose: the host
> path of a named volume is not directly bind-mountable into sibling job containers, so the server
> needs a real host path (`CICD_HOST_DATA_ROOT`) to mount job workspaces.

## CLI usage

```
cicd config set-server <url> --token <token>      # ~/.cicd/config.json
cicd pipelines list
cicd pipelines register <file.yml> [--repo <url>]  # inline yaml, repo-backed, or local path
cicd pipelines validate <file.yml>
cicd run <pipelineNameOrId> [--branch <b>] [--input k=v]
cicd status [<runId>]
cicd logs <runId> [--job <name>] [--follow]        # --follow consumes the SSE stream
cicd history <pipelineNameOrId> [--limit N]
cicd secrets set <name> [--scope global|<pipeline>]
cicd secrets list
cicd cancel <runId>
```

## YAML reference (summary)

A pipeline is `version: 1`, an optional `name`, `triggers[]`, `defaults{}`, `variables{}`, and
`jobs{}`. A job has `image`, `steps[]`, optional `needs[]`, `if`, `env`, `cache`, `artifacts`,
`timeout`, `retries`, and `parallel.matrix`. Steps are a shell string (`run:`), a shell object
(`{ name, run, image?, env?, workdir?, if? }`), a built-in (`uses: cache/restore|cache/save|
artifact/upload|artifact/download|nuget/auth|npm/auth|checkout`), or a template invocation
(`uses: ./path/to/template.yml`). Expressions use `${{ }}` with `branch`, `event`, `status.<job>`,
`vars.*`, `inputs.*`, `matrix.*`, `secrets.*` and the `hash(glob)` function. Built-in env vars in
every step: `CICD_RUN_ID`, `CICD_JOB_ID`, `CICD_PIPELINE`, `CICD_BRANCH`, `CICD_SHA`,
`CICD_SHORT_SHA`, `CICD_EVENT`, `CICD_WORKSPACE`. Full reference: [`DESIGN.md`](./DESIGN.md) §1.

### Examples (`examples/`)

| File | Shape | Register as |
|---|---|---|
| `hello.yml` | minimal manual standalone (smoke test) | inline yaml |
| `dotnet-build.yml` | build/test + private feed + cache + template | repo-backed (`--repo <git url>`) |
| `ship-k8s.yml` | docker build/push + helm deploy | repo-backed |
| `dev-loop.yml` | fileWatch dev loop | local path (`--repo file:///abs/dir`) |

## Development

Run Postgres locally (or `docker compose up postgres`), then:

```bash
export CICD_MASTER_KEY="dev-key-not-for-production"
dotnet run --project src/Cicd.Server      # API + SPA on http://localhost:8080
```

The connection string defaults to `Host=localhost;Database=cicd;Username=postgres;Password=cicd`
(`ConnectionStrings:Db` in `appsettings.json`). The schema is created on startup; DB init retries
for a while so it tolerates Postgres still booting.

Front end with hot reload (proxies `/api` to `:8080`):

```bash
cd web && npm install && npm run dev
```

`npm run build` writes the production SPA into `src/Cicd.Server/wwwroot`, which the server serves
with an SPA fallback. The Docker image builds the SPA automatically (Dockerfile stage 1).

## Security note

The server mounts the host Docker socket (`/var/run/docker.sock`) so it can run a container per
job. This gives the server — and therefore any pipeline it runs — effectively root on the host.
This is an accepted trade-off for a single-node, trusted, self-hosted tool: **run it on an isolated
host and only register pipelines you trust.** The `IJobExecutor` seam leaves the door open to
rootless Docker or remote agents later.
