import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, ApiError } from '../api';
import type { PipelineDetailDto, RunDto } from '../api';
import { StatusBadge } from '../components/StatusBadge';
import { formatDateTime, formatDuration, shortSha } from '../util';

interface InputRow {
  key: string;
  value: string;
}

// Per-pipeline run history (auto-refresh) + "Run now" form.
export function RunsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [pipeline, setPipeline] = useState<PipelineDetailDto | null>(null);
  const [runs, setRuns] = useState<RunDto[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [branch, setBranch] = useState('');
  const [inputs, setInputs] = useState<InputRow[]>([{ key: '', value: '' }]);
  const [busy, setBusy] = useState(false);

  const loadRuns = useCallback(async () => {
    if (!id) {
      return;
    }
    try {
      const paged = await api.listPipelineRuns(id);
      setRuns(paged.items);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to load runs');
    }
  }, [id]);

  useEffect(() => {
    if (!id) {
      return;
    }
    api
      .getPipeline(id)
      .then(setPipeline)
      .catch((e) => setError(e instanceof ApiError ? e.message : 'Failed to load pipeline'));
  }, [id]);

  // Auto-refresh run history every 3s.
  const loadRef = useRef(loadRuns);
  loadRef.current = loadRuns;
  useEffect(() => {
    void loadRef.current();
    const t = setInterval(() => void loadRef.current(), 3000);
    return () => clearInterval(t);
  }, [id]);

  function setInput(i: number, patch: Partial<InputRow>) {
    setInputs((rows) => rows.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  }

  function addInputRow() {
    setInputs((rows) => [...rows, { key: '', value: '' }]);
  }

  function removeInputRow(i: number) {
    setInputs((rows) => rows.filter((_, idx) => idx !== i));
  }

  async function runNow(e: React.FormEvent) {
    e.preventDefault();
    if (!id) {
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const inputMap: Record<string, string> = {};
      for (const row of inputs) {
        const k = row.key.trim();
        if (k) {
          inputMap[k] = row.value;
        }
      }
      const run = await api.createRun(id, {
        branch: branch.trim() || undefined,
        inputs: Object.keys(inputMap).length ? inputMap : undefined,
      });
      navigate(`/runs/${run.id}`);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to start run');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>
          <Link to="/" className="crumb">
            Pipelines
          </Link>{' '}
          / {pipeline?.name ?? 'Runs'}
        </h1>
        <button onClick={() => setShowForm((s) => !s)}>Run now</button>
      </div>

      {error && <div className="error-banner">{error}</div>}

      {showForm && (
        <form className="form run-form" onSubmit={runNow}>
          <label>
            Branch
            <input
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              placeholder="main"
            />
          </label>
          <div className="inputs-block">
            <span className="inputs-label">Inputs</span>
            {inputs.map((row, i) => (
              <div key={i} className="input-row">
                <input
                  placeholder="key"
                  value={row.key}
                  onChange={(e) => setInput(i, { key: e.target.value })}
                />
                <input
                  placeholder="value"
                  value={row.value}
                  onChange={(e) => setInput(i, { value: e.target.value })}
                />
                <button type="button" className="danger" onClick={() => removeInputRow(i)}>
                  ×
                </button>
              </div>
            ))}
            <button type="button" onClick={addInputRow}>
              + Add input
            </button>
          </div>
          <div className="form-actions">
            <button type="submit" disabled={busy}>
              Start run
            </button>
          </div>
        </form>
      )}

      <table className="table">
        <thead>
          <tr>
            <th>Status</th>
            <th>Branch</th>
            <th>Commit</th>
            <th>Trigger</th>
            <th>Started</th>
            <th>Duration</th>
          </tr>
        </thead>
        <tbody>
          {runs.map((r) => (
            <tr key={r.id} className="clickable" onClick={() => navigate(`/runs/${r.id}`)}>
              <td>
                <StatusBadge status={r.status} />
              </td>
              <td>{r.branch}</td>
              <td className="mono">{shortSha(r.commitSha)}</td>
              <td>{r.triggerOn}</td>
              <td>{formatDateTime(r.startedAt)}</td>
              <td>{formatDuration(r.startedAt, r.finishedAt)}</td>
            </tr>
          ))}
          {runs.length === 0 && (
            <tr>
              <td colSpan={6} className="empty">
                No runs yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
