import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ApiError } from '../api';
import type { PipelineDto, ValidateResult } from '../api';
import { formatDateTime } from '../util';

// Pipelines list + register form with YAML validation.
export function PipelinesPage() {
  const [pipelines, setPipelines] = useState<PipelineDto[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [repoUrl, setRepoUrl] = useState('');
  const [yaml, setYaml] = useState('');
  const [validation, setValidation] = useState<ValidateResult | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      setPipelines(await api.listPipelines());
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to load pipelines');
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function validate() {
    setError(null);
    try {
      setValidation(await api.validateYaml(yaml));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Validation failed');
    }
  }

  async function register(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api.createPipeline({
        name: name.trim() || undefined,
        repoUrl: repoUrl.trim() || undefined,
        yaml: yaml.trim() || undefined,
      });
      setName('');
      setRepoUrl('');
      setYaml('');
      setValidation(null);
      await load();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to register pipeline');
    } finally {
      setBusy(false);
    }
  }

  async function remove(p: PipelineDto) {
    if (!confirm(`Delete pipeline "${p.name}"?`)) {
      return;
    }
    try {
      await api.deletePipeline(p.id);
      await load();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to delete pipeline');
    }
  }

  return (
    <div className="page">
      <h1>Pipelines</h1>
      {error && <div className="error-banner">{error}</div>}

      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Repository</th>
            <th>Created</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {pipelines.map((p) => (
            <tr key={p.id}>
              <td>
                <Link to={`/pipelines/${p.id}`}>{p.name}</Link>
              </td>
              <td className="mono">{p.repoUrl || (p.hasRawYaml ? '(inline YAML)' : '-')}</td>
              <td>{formatDateTime(p.createdAt)}</td>
              <td className="row-actions">
                <button className="danger" onClick={() => remove(p)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
          {pipelines.length === 0 && (
            <tr>
              <td colSpan={4} className="empty">
                No pipelines yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <h2>Register pipeline</h2>
      <form className="form" onSubmit={register}>
        <label>
          Name
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="backend" />
        </label>
        <label>
          Repository URL
          <input
            value={repoUrl}
            onChange={(e) => setRepoUrl(e.target.value)}
            placeholder="https://github.com/org/repo.git"
          />
        </label>
        <label>
          Or paste YAML
          <textarea
            className="mono"
            rows={12}
            value={yaml}
            onChange={(e) => {
              setYaml(e.target.value);
              setValidation(null);
            }}
            placeholder="version: 1&#10;jobs:&#10;  build:&#10;    image: alpine:3.20&#10;    steps:&#10;      - run: echo hi"
          />
        </label>

        {validation && (
          <div className={validation.isValid ? 'validate-ok' : 'validate-errors'}>
            {validation.isValid ? (
              'YAML is valid.'
            ) : (
              <ul>
                {validation.errors.map((err, i) => (
                  <li key={i} className="mono">
                    {err.line != null ? `line ${err.line}` : ''}
                    {err.column != null ? `:${err.column}` : ''}
                    {err.line != null ? ' — ' : ''}
                    {err.message}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        <div className="form-actions">
          <button type="button" onClick={validate} disabled={!yaml.trim()}>
            Validate
          </button>
          <button type="submit" disabled={busy || (!repoUrl.trim() && !yaml.trim())}>
            Register
          </button>
        </div>
      </form>
    </div>
  );
}
