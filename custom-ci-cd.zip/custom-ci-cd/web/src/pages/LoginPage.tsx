import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { setToken } from '../api';

// Token entry. Stores the token in localStorage and routes to the app.
export function LoginPage() {
  const [token, setTokenInput] = useState('');
  const navigate = useNavigate();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = token.trim();
    if (!trimmed) {
      return;
    }
    setToken(trimmed);
    navigate('/');
  }

  return (
    <div className="login">
      <form className="login-card" onSubmit={submit}>
        <h1>Cicd</h1>
        <p className="muted">Enter your API token to continue.</p>
        <input
          type="password"
          placeholder="API token"
          value={token}
          onChange={(e) => setTokenInput(e.target.value)}
          autoFocus
        />
        <button type="submit" disabled={!token.trim()}>
          Sign in
        </button>
      </form>
    </div>
  );
}
