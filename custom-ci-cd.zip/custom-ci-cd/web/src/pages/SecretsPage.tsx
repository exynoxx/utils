import { useEffect, useState } from 'react';
import { api, ApiError } from '../api';
import type { PipelineDto, SecretDto, SecretScope } from '../api';

// Secrets list + write-only set/update form + delete.
export function SecretsPage() {
  const [secrets, setSecrets] = useState<SecretDto[]>([]);
  const [pipelines, setPipelines] = useState<PipelineDto[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [value, setValue] = useState('');
  const [scope, setScope] = useState<SecretScope>('global');
  const [pipelineId, setPipelineId] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const [s, p] = await Promise.all([api.listSecrets(), api.listPipelines()]);
      setSecrets(s);
      setPipelines(p);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to load secrets');
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api.setSecret(name.trim(), {
        value,
        scope,
        pipelineId: scope === 'pipeline' ? pipelineId || undefined : undefined,
      });
      setName('');
      setValue('');
      await load();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to save secret');
    } finally {
      setBusy(false);
    }
  }

  async function remove(s: SecretDto) {
    if (!confirm(`Delete secret "${s.name}" (${s.scope})?`)) {
      return;
    }
    try {
      await api.deleteSecret(s.name, s.scope, s.pipelineId);
      await load();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to delete secret');
    }
  }

  function pipelineName(pid: string | null | undefined): string {
    if (!pid) {
      return '';
    }
    return pipelines.find((p) => p.id === pid)?.name ?? pid;
  }

  const canSave =
    name.trim() !== '' &&
    value !== '' &&
    (scope === 'global' || pipelineId !== '');

  return (
    <div className="page">
      <h1>Secrets</h1>
      {error && <div className="error-banner">{error}</div>}

      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Scope</th>
            <th>Pipeline</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {secrets.map((s) => (
            <tr key={`${s.name}:${s.scope}:${s.pipelineId ?? ''}`}>
              <td className="mono">{s.name}</td>
              <td>{s.scope}</td>
              <td>{pipelineName(s.pipelineId) || '-'}</td>
              <td className="row-actions">
                <button className="danger" onClick={() => remove(s)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
          {secrets.length === 0 && (
            <tr>
              <td colSpan={4} className="empty">
                No secrets.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <h2>Set / update secret</h2>
      <form className="form" onSubmit={save}>
        <label>
          Name
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="AZDO_PAT" />
        </label>
        <label>
          Value
          <input
            type="password"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="(write-only)"
          />
        </label>
        <label>
          Scope
          <select value={scope} onChange={(e) => setScope(e.target.value as SecretScope)}>
            <option value="global">Global</option>
            <option value="pipeline">Pipeline</option>
          </select>
        </label>
        {scope === 'pipeline' && (
          <label>
            Pipeline
            <select value={pipelineId} onChange={(e) => setPipelineId(e.target.value)}>
              <option value="">Select pipeline…</option>
              {pipelines.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>
        )}
        <div className="form-actions">
          <button type="submit" disabled={busy || !canSave}>
            Save
          </button>
        </div>
      </form>
    </div>
  );
}
