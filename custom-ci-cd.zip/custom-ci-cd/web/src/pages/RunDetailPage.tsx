import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, ApiError } from '../api';
import type { ArtifactDto, JobDto, RunDetailDto } from '../api';
import { StatusBadge } from '../components/StatusBadge';
import { DagView } from '../components/DagView';
import { LogViewer } from '../components/LogViewer';
import { formatDuration, isRunTerminal } from '../util';

function formatBytes(n: number): string {
  if (n < 1024) {
    return `${n} B`;
  }
  if (n < 1024 * 1024) {
    return `${(n / 1024).toFixed(1)} KB`;
  }
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

// Run detail: header + DAG + selected job's steps & live log + artifacts.
export function RunDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [run, setRun] = useState<RunDetailDto | null>(null);
  const [artifacts, setArtifacts] = useState<ArtifactDto[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!id) {
      return;
    }
    try {
      const detail = await api.getRun(id);
      setRun(detail);
      // Default-select the first job once loaded.
      setSelectedJobId((cur) => cur ?? detail.jobs[0]?.id ?? null);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to load run');
    }
  }, [id]);

  // Poll run JSON every 2s while not terminal. Once terminal, stop polling.
  const loadRef = useRef(load);
  loadRef.current = load;
  const terminal = run != null && isRunTerminal(run.status);
  useEffect(() => {
    void loadRef.current();
    if (terminal) {
      return;
    }
    const t = setInterval(() => {
      void loadRef.current();
    }, 2000);
    return () => clearInterval(t);
  }, [id, terminal]);

  useEffect(() => {
    if (!id || !run || !isRunTerminal(run.status)) {
      return;
    }
    api
      .listArtifacts(id)
      .then(setArtifacts)
      .catch(() => {
        /* artifacts optional */
      });
  }, [id, run]);

  if (error) {
    return (
      <div className="page">
        <div className="error-banner">{error}</div>
      </div>
    );
  }
  if (!run) {
    return (
      <div className="page">
        <div className="empty">Loading…</div>
      </div>
    );
  }

  const selectedJob: JobDto | undefined = run.jobs.find((j) => j.id === selectedJobId);
  const running = run.status === 'Running' || run.status === 'Queued';

  async function cancel() {
    if (!id) {
      return;
    }
    try {
      await api.cancelRun(id);
      await load();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Failed to cancel run');
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>
          <Link to={`/pipelines/${run.pipelineId}`} className="crumb">
            Runs
          </Link>{' '}
          / Run
        </h1>
        {running && (
          <button className="danger" onClick={cancel}>
            Cancel
          </button>
        )}
      </div>

      <div className="run-meta">
        <StatusBadge status={run.status} />
        <span>
          <strong>Branch:</strong> {run.branch}
        </span>
        <span>
          <strong>Trigger:</strong> {run.triggerOn}
        </span>
        <span>
          <strong>Duration:</strong> {formatDuration(run.startedAt, run.finishedAt)}
        </span>
      </div>

      <div className="run-body">
        <div className="dag-panel">
          <DagView
            jobs={run.jobs}
            selectedJobId={selectedJobId}
            onSelect={setSelectedJobId}
          />
        </div>

        <div className="job-panel">
          {selectedJob ? (
            <>
              <div className="job-header">
                <h2>{selectedJob.name}</h2>
                <StatusBadge status={selectedJob.status} />
              </div>
              <div className="job-sub mono">
                {selectedJob.image}
                {selectedJob.attempt > 1 && ` · attempt ${selectedJob.attempt}`}
              </div>

              <table className="table steps-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Step</th>
                    <th>Status</th>
                    <th>Exit</th>
                    <th>Duration</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedJob.steps.map((s) => (
                    <tr key={s.ordinal}>
                      <td>{s.ordinal}</td>
                      <td>{s.name}</td>
                      <td>
                        <StatusBadge status={s.status} />
                      </td>
                      <td className="mono">{s.exitCode ?? '-'}</td>
                      <td>{formatDuration(s.startedAt, s.finishedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <LogViewer
                key={selectedJob.id}
                runId={run.id}
                jobId={selectedJob.id}
                jobStatus={selectedJob.status}
              />
            </>
          ) : (
            <div className="empty">Select a job in the graph.</div>
          )}
        </div>
      </div>

      {artifacts.length > 0 && (
        <div className="artifacts">
          <h2>Artifacts</h2>
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Size</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {artifacts.map((a) => (
                <tr key={a.id}>
                  <td className="mono">{a.name}</td>
                  <td>{formatBytes(a.sizeBytes)}</td>
                  <td className="row-actions">
                    <a href={api.artifactDownloadUrl(a.id)} download>
                      Download
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
