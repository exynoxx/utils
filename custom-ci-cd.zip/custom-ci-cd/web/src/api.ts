// Typed REST client + fetch wrapper for the Cicd API.
// Token is stored in localStorage under `cicd_token` and sent as a bearer header.
// Native EventSource cannot set headers, so the SSE endpoint receives the token
// as an `?access_token=` query param (the server must accept it there too).

export const TOKEN_KEY = 'cicd_token';

// ---- Domain types (JSON is camelCase; enums are PascalCase strings) -------

export type RunStatus = 'Queued' | 'Running' | 'Succeeded' | 'Failed' | 'Canceled';
export type JobStatus =
  | 'Pending'
  | 'Queued'
  | 'Running'
  | 'Succeeded'
  | 'Failed'
  | 'Skipped'
  | 'Canceled';
export type StepStatus = 'Pending' | 'Running' | 'Succeeded' | 'Failed' | 'Skipped';

export interface PipelineDto {
  id: string;
  name: string;
  repoUrl?: string | null;
  hasRawYaml: boolean;
  createdAt: string;
}

export interface PipelineDetailDto extends PipelineDto {
  rawYaml?: string | null;
}

export interface RunDto {
  id: string;
  pipelineId: string;
  triggerOn: string;
  branch: string;
  commitSha: string;
  status: RunStatus;
  createdAt: string;
  startedAt?: string | null;
  finishedAt?: string | null;
}

export interface StepDto {
  ordinal: number;
  name: string;
  status: StepStatus;
  exitCode?: number | null;
  startedAt?: string | null;
  finishedAt?: string | null;
}

export interface JobDto {
  id: string;
  runId: string;
  name: string;
  image: string;
  needs: string[];
  status: JobStatus;
  attempt: number;
  startedAt?: string | null;
  finishedAt?: string | null;
  steps: StepDto[];
}

export interface RunDetailDto extends RunDto {
  jobs: JobDto[];
}

export interface ArtifactDto {
  id: string;
  runId: string;
  jobId: string;
  name: string;
  sizeBytes: number;
  expiresAt?: string | null;
  createdAt: string;
}

export type SecretScope = 'global' | 'pipeline';

export interface SecretDto {
  name: string;
  scope: SecretScope;
  pipelineId?: string | null;
}

export interface ValidateError {
  message: string;
  line?: number | null;
  column?: number | null;
}

export interface ValidateResult {
  isValid: boolean;
  errors: ValidateError[];
}

export interface Paged<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface CreatePipelineRequest {
  name?: string;
  repoUrl?: string;
  yaml?: string;
}

export interface CreateRunRequest {
  branch?: string;
  inputs?: Record<string, string>;
}

export interface SetSecretRequest {
  value: string;
  scope: SecretScope;
  pipelineId?: string | null;
}

// ---- Token helpers --------------------------------------------------------

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

// ---- Fetch wrapper --------------------------------------------------------

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const token = getToken();
  const headers = new Headers(init?.headers);
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  if (init?.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(`/api${path}`, { ...init, headers });

  if (res.status === 401) {
    clearToken();
    if (location.pathname !== '/login') {
      location.assign('/login');
    }
    throw new ApiError(401, 'Unauthorized');
  }

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new ApiError(res.status, text || `${res.status} ${res.statusText}`);
  }

  if (res.status === 204) {
    return undefined as T;
  }

  const contentType = res.headers.get('Content-Type') ?? '';
  if (contentType.includes('application/json')) {
    return (await res.json()) as T;
  }
  return (await res.text()) as unknown as T;
}

// ---- Pipelines ------------------------------------------------------------

export const api = {
  listPipelines: () =>
    request<Paged<PipelineDto>>('/pipelines?page=1&pageSize=100').then((p) => p.items),

  getPipeline: (id: string) => request<PipelineDetailDto>(`/pipelines/${id}`),

  createPipeline: (body: CreatePipelineRequest) =>
    request<PipelineDetailDto>('/pipelines', { method: 'POST', body: JSON.stringify(body) }),

  updatePipeline: (id: string, body: CreatePipelineRequest) =>
    request<void>(`/pipelines/${id}`, { method: 'PUT', body: JSON.stringify(body) }),

  deletePipeline: (id: string) => request<void>(`/pipelines/${id}`, { method: 'DELETE' }),

  validateYaml: (yaml: string) =>
    request<ValidateResult>('/pipelines/validate', {
      method: 'POST',
      body: JSON.stringify({ yaml }),
    }),

  // ---- Runs ---------------------------------------------------------------

  createRun: (pipelineId: string, body: CreateRunRequest) =>
    request<RunDto>(`/pipelines/${pipelineId}/runs`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  listPipelineRuns: (pipelineId: string, page = 1, pageSize = 25) =>
    request<Paged<RunDto>>(
      `/pipelines/${pipelineId}/runs?page=${page}&pageSize=${pageSize}`,
    ),

  listRecentRuns: (limit = 20) =>
    request<Paged<RunDto>>(`/runs?limit=${limit}`).then((p) => p.items),

  getRun: (id: string) => request<RunDetailDto>(`/runs/${id}`),

  cancelRun: (id: string) => request<void>(`/runs/${id}/cancel`, { method: 'POST' }),

  // ---- Logs ---------------------------------------------------------------

  getJobLog: (runId: string, jobId: string) =>
    request<string>(`/runs/${runId}/jobs/${jobId}/logs`),

  // Builds the SSE stream URL. Token is passed as a query param because native
  // EventSource cannot attach an Authorization header.
  logStreamUrl: (runId: string, jobId: string): string => {
    const token = getToken();
    const base = `/api/runs/${runId}/jobs/${jobId}/logs/stream`;
    return token ? `${base}?access_token=${encodeURIComponent(token)}` : base;
  },

  // ---- Artifacts ----------------------------------------------------------

  listArtifacts: (runId: string) => request<ArtifactDto[]>(`/runs/${runId}/artifacts`),

  artifactDownloadUrl: (artifactId: string): string => {
    const token = getToken();
    const base = `/api/artifacts/${artifactId}/download`;
    return token ? `${base}?access_token=${encodeURIComponent(token)}` : base;
  },

  // ---- Secrets ------------------------------------------------------------

  listSecrets: () => request<SecretDto[]>('/secrets'),

  setSecret: (name: string, body: SetSecretRequest) =>
    request<void>(`/secrets/${encodeURIComponent(name)}`, {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  deleteSecret: (name: string, scope: SecretScope, pipelineId?: string | null) => {
    const params = new URLSearchParams({ scope });
    if (pipelineId) {
      params.set('pipelineId', pipelineId);
    }
    return request<void>(`/secrets/${encodeURIComponent(name)}?${params.toString()}`, {
      method: 'DELETE',
    });
  },
};
