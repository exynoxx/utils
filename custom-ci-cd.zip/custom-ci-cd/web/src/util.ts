// Small formatting helpers shared across pages.

export function shortSha(sha: string | null | undefined): string {
  if (!sha) {
    return '';
  }
  return sha.length > 7 ? sha.slice(0, 7) : sha;
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) {
    return '-';
  }
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) {
    return '-';
  }
  return d.toLocaleString();
}

// Duration between two timestamps (or from start to now if not finished).
export function formatDuration(
  start: string | null | undefined,
  end: string | null | undefined,
): string {
  if (!start) {
    return '-';
  }
  const startMs = new Date(start).getTime();
  const endMs = end ? new Date(end).getTime() : Date.now();
  if (Number.isNaN(startMs) || Number.isNaN(endMs)) {
    return '-';
  }
  let secs = Math.max(0, Math.round((endMs - startMs) / 1000));
  if (secs < 60) {
    return `${secs}s`;
  }
  const mins = Math.floor(secs / 60);
  secs = secs % 60;
  if (mins < 60) {
    return `${mins}m ${secs}s`;
  }
  const hours = Math.floor(mins / 60);
  return `${hours}h ${mins % 60}m`;
}

const TERMINAL_RUN = new Set(['Succeeded', 'Failed', 'Canceled']);
const TERMINAL_JOB = new Set(['Succeeded', 'Failed', 'Skipped', 'Canceled']);

export function isRunTerminal(status: string): boolean {
  return TERMINAL_RUN.has(status);
}

export function isJobTerminal(status: string): boolean {
  return TERMINAL_JOB.has(status);
}
