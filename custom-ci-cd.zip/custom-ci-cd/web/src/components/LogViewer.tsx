import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { api } from '../api';
import { isJobTerminal } from '../util';

interface LogViewerProps {
  runId: string;
  jobId: string;
  jobStatus: string;
}

// Shows a job's log. While the job is running it attaches an EventSource to the
// SSE stream endpoint and appends `data:` lines live. When the job is terminal
// it does a plain GET of the full log. Auto-scrolls to the bottom while pinned.
export function LogViewer({ runId, jobId, jobStatus }: LogViewerProps) {
  const [text, setText] = useState('');
  const [pinned, setPinned] = useState(true);
  const [streaming, setStreaming] = useState(false);
  const preRef = useRef<HTMLPreElement>(null);
  const pinnedRef = useRef(pinned);
  pinnedRef.current = pinned;

  const terminal = isJobTerminal(jobStatus);

  // Reset when switching jobs.
  useEffect(() => {
    setText('');
  }, [runId, jobId]);

  useEffect(() => {
    let cancelled = false;

    if (terminal) {
      setStreaming(false);
      api
        .getJobLog(runId, jobId)
        .then((full) => {
          if (!cancelled) {
            setText(full);
          }
        })
        .catch(() => {
          /* job may have no log yet */
        });
      return () => {
        cancelled = true;
      };
    }

    // Running (or pending): live tail via SSE. The stream replays from offset 0
    // then attaches live, so we replace local text on (re)connect start.
    setText('');
    setStreaming(true);
    const es = new EventSource(api.logStreamUrl(runId, jobId));

    es.onmessage = (ev) => {
      if (!cancelled) {
        setText((prev) => prev + ev.data + '\n');
      }
    };
    es.addEventListener('end', () => {
      es.close();
      setStreaming(false);
    });
    es.onerror = () => {
      // EventSource auto-reconnects; nothing to do, but stop the indicator if
      // the connection is fully closed.
      if (es.readyState === EventSource.CLOSED) {
        setStreaming(false);
      }
    };

    return () => {
      cancelled = true;
      es.close();
    };
  }, [runId, jobId, terminal]);

  // Auto-scroll to bottom when pinned and content changes.
  useLayoutEffect(() => {
    if (pinnedRef.current && preRef.current) {
      preRef.current.scrollTop = preRef.current.scrollHeight;
    }
  }, [text]);

  function onScroll() {
    const el = preRef.current;
    if (!el) {
      return;
    }
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 24;
    if (atBottom !== pinnedRef.current) {
      setPinned(atBottom);
    }
  }

  return (
    <div className="logviewer">
      <div className="logviewer-toolbar">
        <span className="logviewer-title">
          Logs {streaming && <span className="streaming-dot" title="streaming" />}
        </span>
        <label className="pin-toggle">
          <input
            type="checkbox"
            checked={pinned}
            onChange={(e) => setPinned(e.target.checked)}
          />
          Pin to bottom
        </label>
      </div>
      <pre ref={preRef} className="logpanel" onScroll={onScroll}>
        {text || (terminal ? '(no output)' : 'Waiting for output...')}
      </pre>
    </div>
  );
}
