import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { clearToken } from '../api';

// App shell: left sidebar nav + main content outlet.
export function Layout() {
  const navigate = useNavigate();

  function logout() {
    clearToken();
    navigate('/login');
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">Cicd</div>
        <nav>
          <NavLink to="/" end>
            Pipelines
          </NavLink>
          <NavLink to="/secrets">Secrets</NavLink>
        </nav>
        <button className="logout" onClick={logout}>
          Log out
        </button>
      </aside>
      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
