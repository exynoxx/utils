import { useMemo } from 'react';
import dagre from '@dagrejs/dagre';
import type { JobDto } from '../api';

interface DagViewProps {
  jobs: JobDto[];
  selectedJobId: string | null;
  onSelect: (jobId: string) => void;
}

interface NodeLayout {
  job: JobDto;
  x: number;
  y: number;
  width: number;
  height: number;
}

interface EdgeLayout {
  points: { x: number; y: number }[];
}

const NODE_WIDTH = 160;
const NODE_HEIGHT = 44;

// Lays out the job DAG with dagre and renders it as an SVG. Edges are drawn
// from each job to the jobs that list it in `needs`. Nodes are colored by
// status via the `node-<status>` CSS class.
export function DagView({ jobs, selectedJobId, onSelect }: DagViewProps) {
  const layout = useMemo(() => buildLayout(jobs), [jobs]);

  if (jobs.length === 0) {
    return <div className="empty">No jobs.</div>;
  }

  return (
    <svg
      className="dag"
      width={layout.width}
      height={layout.height}
      viewBox={`0 0 ${layout.width} ${layout.height}`}
    >
      <defs>
        <marker
          id="arrow"
          viewBox="0 0 10 10"
          refX="9"
          refY="5"
          markerWidth="7"
          markerHeight="7"
          orient="auto-start-reverse"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" className="dag-arrow" />
        </marker>
      </defs>

      {layout.edges.map((edge, i) => (
        <polyline
          key={i}
          className="dag-edge"
          points={edge.points.map((p) => `${p.x},${p.y}`).join(' ')}
          markerEnd="url(#arrow)"
          fill="none"
        />
      ))}

      {layout.nodes.map((n) => {
        const selected = n.job.id === selectedJobId;
        return (
          <g
            key={n.job.id}
            className={`dag-node node-${n.job.status.toLowerCase()}${
              selected ? ' dag-node-selected' : ''
            }`}
            transform={`translate(${n.x - n.width / 2}, ${n.y - n.height / 2})`}
            onClick={() => onSelect(n.job.id)}
          >
            <rect width={n.width} height={n.height} rx={6} ry={6} />
            <text x={n.width / 2} y={n.height / 2} dominantBaseline="middle" textAnchor="middle">
              {n.job.name}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function buildLayout(jobs: JobDto[]): {
  nodes: NodeLayout[];
  edges: EdgeLayout[];
  width: number;
  height: number;
} {
  const g = new dagre.graphlib.Graph();
  g.setGraph({ rankdir: 'LR', nodesep: 30, ranksep: 60, marginx: 16, marginy: 16 });
  g.setDefaultEdgeLabel(() => ({}));

  // jobs are keyed by name in `needs`; map name -> job for edge resolution.
  const byName = new Map(jobs.map((j) => [j.name, j]));

  for (const job of jobs) {
    g.setNode(job.id, { width: NODE_WIDTH, height: NODE_HEIGHT });
  }
  for (const job of jobs) {
    for (const need of job.needs) {
      const upstream = byName.get(need);
      if (upstream) {
        g.setEdge(upstream.id, job.id);
      }
    }
  }

  dagre.layout(g);

  const nodes: NodeLayout[] = jobs.map((job) => {
    const n = g.node(job.id);
    return { job, x: n.x, y: n.y, width: n.width, height: n.height };
  });

  const edges: EdgeLayout[] = g.edges().map((e) => {
    const edge = g.edge(e);
    return { points: edge.points };
  });

  const graph = g.graph();
  return {
    nodes,
    edges,
    width: Math.max(graph.width ?? 0, NODE_WIDTH),
    height: Math.max(graph.height ?? 0, NODE_HEIGHT),
  };
}
