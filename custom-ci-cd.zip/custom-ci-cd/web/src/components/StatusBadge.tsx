interface StatusBadgeProps {
  status: string;
}

// Renders a status string as a colored pill. The class name maps to CSS
// (.badge-running, .badge-succeeded, ...) via lowercased status.
export function StatusBadge({ status }: StatusBadgeProps) {
  const cls = `badge badge-${status.toLowerCase()}`;
  return <span className={cls}>{status}</span>;
}
